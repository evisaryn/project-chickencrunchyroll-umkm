<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo = db();

$editId = get_int('edit');
$edit   = null;
if ($editId > 0) {
    $st = $pdo->prepare('SELECT id, name FROM categories WHERE id = ?');
    $st->execute([$editId]);
    $edit = $st->fetch() ?: null;
    if (!$edit) {
        flash('danger', 'Kategori tidak ditemukan.');
        redirect('admin/categories.php');
    }
}

$categories = $pdo->query(
    'SELECT c.id, c.name, c.slug, c.is_active,
            (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count
     FROM categories c ORDER BY c.id'
)->fetchAll();

$pageTitle  = 'Kategori Produk';
$activePage = 'categories';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Kategori</h2>
    <p>Kelompokkan produk agar mudah difilter di halaman menu.</p>
  </div>
</div>

<section class="panel">
  <div class="panel-head"><h3><?= $edit ? 'Edit Kategori' : 'Tambah Kategori' ?></h3></div>
  <form class="toolbar" method="post" action="<?= e(url('actions/category_action.php')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= $edit ? (int) $edit['id'] : 0 ?>">
    <input class="form-control" type="text" name="name" required minlength="3" maxlength="100"
           placeholder="Nama kategori" value="<?= e($edit ? (string) $edit['name'] : '') ?>" style="max-width:340px">
    <button type="submit" class="btn btn-primary btn-sm" data-once><?= $edit ? 'Simpan' : 'Tambah' ?></button>
    <?php if ($edit): ?><a class="btn btn-outline btn-sm" href="<?= e(url('admin/categories.php')) ?>">Batal</a><?php endif; ?>
  </form>
</section>

<section class="panel">
  <div class="panel-head"><h3>Daftar Kategori</h3></div>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>Nama</th><th>Slug</th><th class="text-right">Produk</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
        <?php foreach ($categories as $c): ?>
          <tr>
            <td><strong><?= e((string) $c['name']) ?></strong></td>
            <td><code><?= e((string) $c['slug']) ?></code></td>
            <td class="text-right"><?= (int) $c['product_count'] ?></td>
            <td>
              <span class="badge <?= (int) $c['is_active'] === 1 ? 'badge-ok' : 'badge-muted' ?>">
                <?= (int) $c['is_active'] === 1 ? 'Aktif' : 'Nonaktif' ?>
              </span>
            </td>
            <td>
              <div class="table-actions">
                <a class="btn btn-outline btn-sm" href="<?= e(url('admin/categories.php?edit=' . (int) $c['id'])) ?>">Edit</a>
                <form method="post" action="<?= e(url('actions/category_action.php')) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                  <button type="submit" class="btn btn-dark btn-sm"><?= (int) $c['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                </form>
                <form method="post" action="<?= e(url('actions/category_action.php')) ?>"
                      data-confirm="Hapus kategori ini?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <p class="form-hint mt-1">
    Menonaktifkan kategori menyembunyikan produk di dalamnya dari halaman Menu. Kategori hanya bisa dihapus jika kosong.
  </p>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>