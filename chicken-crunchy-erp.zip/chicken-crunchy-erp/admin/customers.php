<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stats.php';

require_admin();
$pdo = db();
$me  = current_user();

$tab = get_str('tab', 10);
if ($tab !== 'admins' || !is_superadmin()) {
    $tab = 'customers';
}
$q    = get_str('q', 60);
$page = max(1, get_int('page', 1));

function customers_url(string $tab, string $q, int $page = 1): string
{
    $query = array_filter([
        'tab'  => $tab === 'admins' ? 'admins' : '',
        'q'    => $q,
        'page' => $page > 1 ? (string) $page : '',
    ], static fn ($v) => $v !== '');
    return url('admin/customers.php') . ($query ? '?' . http_build_query($query) : '');
}

$customers  = [];
$admins     = [];
$totalRows  = 0;
$totalPages = 1;

if ($tab === 'customers') {
    $where  = " WHERE u.role = 'customer'";
    $params = [];
    if ($q !== '') {
        $where .= ' AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)';
        $like = '%' . addcslashes($q, '%_\\') . '%';
        array_push($params, $like, $like, $like);
    }

    $st = $pdo->prepare('SELECT COUNT(*) FROM users u' . $where);
    $st->execute($params);
    $totalRows  = (int) $st->fetchColumn();
    $perPage    = 25;
    $totalPages = max(1, (int) ceil($totalRows / $perPage));
    $page       = min($page, $totalPages);
    $offset     = ($page - 1) * $perPage;

    $st = $pdo->prepare(
        "SELECT u.id, u.name, u.email, u.phone, u.is_active, u.created_at,
                (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id AND o.status <> 'cancelled') AS order_count,
                (SELECT COALESCE(SUM(o.total), 0)
                   FROM orders o JOIN payments p ON p.order_id = o.id
                  WHERE o.user_id = u.id AND " . SALE_VALID_SQL . ") AS spent
         FROM users u" . $where
        . ' ORDER BY u.created_at DESC, u.id DESC LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset
    );
    $st->execute($params);
    $customers = $st->fetchAll();
} else {
    $admins = $pdo->query(
        "SELECT id, name, email, role, is_active, created_at FROM users
         WHERE role IN ('admin', 'superadmin') ORDER BY FIELD(role, 'superadmin', 'admin'), name"
    )->fetchAll();
}

// Isi ulang form tambah admin (hanya nama dan email, tidak pernah password)
$old = $_SESSION['admin_old'] ?? null;
unset($_SESSION['admin_old']);
$form = is_array($old) ? $old : ['name' => '', 'email' => ''];

$pageTitle  = 'Pelanggan & Pengguna';
$activePage = 'customers';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Pelanggan &amp; Pengguna</h2>
    <p>Kelola akun pelanggan dan, khusus superadmin, akun admin.</p>
  </div>
</div>

<div class="chips mb-2">
  <a class="chip<?= $tab === 'customers' ? ' active' : '' ?>" href="<?= e(url('admin/customers.php')) ?>">Pelanggan</a>
  <?php if (is_superadmin()): ?>
    <a class="chip<?= $tab === 'admins' ? ' active' : '' ?>" href="<?= e(url('admin/customers.php?tab=admins')) ?>">Akun Admin</a>
  <?php endif; ?>
</div>

<?php if ($tab === 'customers'): ?>
<section class="panel">
  <form class="toolbar" method="get" action="<?= e(url('admin/customers.php')) ?>">
    <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari nama / email / telepon" maxlength="60">
    <button type="submit" class="btn btn-primary btn-sm">Cari</button>
    <?php if ($q !== ''): ?><a class="btn btn-outline btn-sm" href="<?= e(url('admin/customers.php')) ?>">Reset</a><?php endif; ?>
    <span class="spacer"></span>
    <span class="text-muted"><?= $totalRows ?> pelanggan</span>
  </form>

  <?php if (!$customers): ?>
    <p class="text-muted">Belum ada pelanggan<?= $q !== '' ? ' yang cocok' : '' ?>.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr><th>Nama</th><th>Email</th><th>Telepon</th><th>Terdaftar</th>
              <th class="text-right">Pesanan</th><th class="text-right">Total Belanja (lunas)</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($customers as $c): ?>
            <tr>
              <td><strong><?= e((string) $c['name']) ?></strong></td>
              <td><?= e((string) $c['email']) ?></td>
              <td><?= e((string) ($c['phone'] ?? '-')) ?></td>
              <td class="nowrap"><?= e(format_datetime($c['created_at'])) ?></td>
              <td class="text-right"><?= (int) $c['order_count'] ?></td>
              <td class="text-right nowrap"><?= e(rupiah($c['spent'])) ?></td>
              <td>
                <span class="badge <?= (int) $c['is_active'] === 1 ? 'badge-ok' : 'badge-muted' ?>">
                  <?= (int) $c['is_active'] === 1 ? 'Aktif' : 'Nonaktif' ?></span>
              </td>
              <td>
                <form method="post" action="<?= e(url('actions/customer_action.php')) ?>"
                      data-confirm="<?= (int) $c['is_active'] === 1 ? 'Nonaktifkan akun ini? Pelanggan tidak bisa login.' : 'Aktifkan kembali akun ini?' ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                  <input type="hidden" name="tab" value="customers">
                  <button type="submit" class="btn btn-dark btn-sm"><?= (int) $c['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a class="chip" href="<?= e(customers_url('customers', $q, $page - 1)) ?>">&laquo; Sebelumnya</a><?php endif; ?>
        <span class="text-muted">Halaman <?= $page ?> dari <?= $totalPages ?></span>
        <?php if ($page < $totalPages): ?><a class="chip" href="<?= e(customers_url('customers', $q, $page + 1)) ?>">Berikutnya &raquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
  <p class="form-hint mt-1">Akun yang dinonaktifkan langsung dikeluarkan dari sesi login-nya. Riwayat pesanan tetap tersimpan.</p>
</section>

<?php else: ?>
<section class="panel">
  <div class="panel-head"><h3>Tambah Akun Admin</h3></div>
  <form method="post" action="<?= e(url('actions/customer_action.php')) ?>" autocomplete="off">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create_admin">

    <div class="form-grid">
      <div class="form-group">
        <label for="name">Nama Lengkap</label>
        <input class="form-control" type="text" id="name" name="name" required minlength="3" maxlength="100" value="<?= e((string) $form['name']) ?>">
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input class="form-control" type="email" id="email" name="email" required maxlength="150" value="<?= e((string) $form['email']) ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input class="form-control" type="password" id="password" name="password" required minlength="10" autocomplete="new-password">
        <div class="form-hint">Minimal 10 karakter, kombinasi huruf dan angka.</div>
      </div>
      <div class="form-group">
        <label for="password_confirm">Ulangi Password</label>
        <input class="form-control" type="password" id="password_confirm" name="password_confirm" required minlength="10" autocomplete="new-password">
      </div>
    </div>
    <button type="submit" class="btn btn-primary" data-once>Buat Akun Admin</button>
    <p class="form-hint mt-1">Akun baru berperan <strong>admin</strong> (tidak bisa membuka Pengaturan atau mengelola admin lain). Superadmin hanya dibuat lewat command line.</p>
  </form>
</section>

<section class="panel">
  <div class="panel-head"><h3>Daftar Akun Admin</h3></div>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Dibuat</th><th>Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($admins as $a):
            $isSelf  = (int) $a['id'] === (int) $me['id'];
            $isSuper = $a['role'] === 'superadmin'; ?>
          <tr>
            <td><strong><?= e((string) $a['name']) ?></strong><?= $isSelf ? ' <small class="text-muted">(Anda)</small>' : '' ?></td>
            <td><?= e((string) $a['email']) ?></td>
            <td><?= $isSuper ? 'Superadmin' : 'Admin' ?></td>
            <td class="nowrap"><?= e(format_datetime($a['created_at'])) ?></td>
            <td>
              <span class="badge <?= (int) $a['is_active'] === 1 ? 'badge-ok' : 'badge-muted' ?>">
                <?= (int) $a['is_active'] === 1 ? 'Aktif' : 'Nonaktif' ?></span>
            </td>
            <td>
              <?php if (!$isSelf && !$isSuper): ?>
                <form method="post" action="<?= e(url('actions/customer_action.php')) ?>"
                      data-confirm="<?= (int) $a['is_active'] === 1 ? 'Nonaktifkan admin ini?' : 'Aktifkan kembali admin ini?' ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
                  <input type="hidden" name="tab" value="admins">
                  <button type="submit" class="btn btn-dark btn-sm"><?= (int) $a['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <p class="form-hint mt-1">Setiap admin dapat mengganti passwordnya sendiri di menu profil (klik nama di navbar website pelanggan).</p>
</section>
<?php endif; ?>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>