<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/reports.php';

require_admin();

$per    = report_period($_GET);
$export = get_str('export', 10);

/* ---------- Ekspor CSV (sebelum ada output HTML) ---------- */
if ($export !== '') {
    $suffix = str_replace('-', '', $per['start']) . '-' . str_replace('-', '', $per['end']);

    if ($export === 'sales') {
        $daily = report_daily($per);
        $rows  = [];
        foreach ($daily as $r) {
            $rows[] = [$r['date'], $r['trx'], round($r['sales'], 2), round($r['subtotal'], 2),
                       round($r['cost'], 2), round($r['profit'], 2), round($r['restock'], 2)];
        }
        $t = report_totals($daily);
        $rows[] = ['TOTAL', $t['trx'], round($t['sales'], 2), round($t['subtotal'], 2),
                   round($t['cost'], 2), round($t['profit'], 2), round($t['restock'], 2)];
        csv_download(
            'laporan-penjualan-' . $suffix . '.csv',
            ['Tanggal', 'Transaksi', 'Nilai Penjualan', 'Subtotal Produk', 'Modal', 'Laba Kotor', 'Pembelian Restock'],
            $rows
        );
    }

    if ($export === 'products') {
        $rows = [];
        foreach (report_top_products($per, 1000) as $r) {
            $rows[] = ['Produk', $r['name'], (int) $r['qty'], round((float) $r['revenue'], 2)];
        }
        foreach (report_top_variants($per, 1000) as $r) {
            $rows[] = ['Varian ' . addon_group_label((string) $r['grp']), $r['name'], (int) $r['qty'], round((float) $r['revenue'], 2)];
        }
        csv_download('laporan-produk-' . $suffix . '.csv', ['Jenis', 'Nama', 'Jumlah Terjual', 'Nilai'], $rows);
    }

    if ($export === 'orders') {
        $rows = [];
        foreach (report_orders($per, 100000) as $o) {
            $rows[] = [
                $o['order_number'], $o['created_at'], $o['customer_name'],
                payment_method_label((string) $o['payment_method']),
                round((float) $o['subtotal'], 2), round((float) $o['delivery_fee'], 2),
                round((float) $o['total'], 2), round((float) $o['total_cost'], 2),
                round((float) $o['subtotal'] - (float) $o['total_cost'], 2),
                order_status_label((string) $o['status']),
            ];
        }
        csv_download(
            'laporan-transaksi-' . $suffix . '.csv',
            ['No Pesanan', 'Waktu', 'Pelanggan', 'Metode Bayar', 'Subtotal', 'Ongkir', 'Total', 'Modal', 'Laba Kotor', 'Status'],
            $rows
        );
    }

    if ($export === 'restocks') {
        $rows = [];
        foreach (report_restocks($per) as $r) {
            $rows[] = [(int) $r['id'], $r['restock_date'], (string) ($r['supplier_name'] ?? '-'),
                       (int) $r['item_count'], round((float) $r['total_cost'], 2)];
        }
        csv_download('laporan-restock-' . $suffix . '.csv', ['ID', 'Tanggal', 'Pemasok', 'Jumlah Item', 'Total Pembelian'], $rows);
    }
    // Jenis ekspor tidak dikenal: lanjut menampilkan halaman biasa
}

/* ---------- Data halaman ---------- */
$summary  = report_summary($per);
$daily    = report_daily($per);
$totals   = report_totals($daily);
$products = report_top_products($per, 10);
$variants = report_top_variants($per, 10);
$orders   = report_orders($per, 200);
$restocks = report_restocks($per);

$chartPoints = [];
if (count($daily) > 1 && count($daily) <= 62) {
    foreach ($daily as $r) {
        $chartPoints[] = ['label' => date('d/m', strtotime($r['date'])), 'value' => $r['sales'], 'orders' => $r['trx']];
    }
}

$modes = ['daily' => 'Harian', 'weekly' => 'Mingguan', 'monthly' => 'Bulanan', 'range' => 'Rentang Tanggal'];
$fmtPct = static fn (float $v): string => number_format($v, 1, ',', '.') . '%';

$pageTitle  = 'Laporan';
$activePage = 'reports';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head no-print">
  <div>
    <h2>Laporan Penjualan</h2>
    <p>Hanya pesanan lunas dan tidak dibatalkan yang dihitung sebagai penjualan.</p>
  </div>
  <button type="button" class="btn btn-outline" onclick="window.print()">🖨 Cetak / Simpan PDF</button>
</div>

<div class="print-only">
  <h2>Laporan Penjualan <?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?></h2>
  <p><?= e($per['label']) ?> &middot; dicetak <?= e(date('d/m/Y H:i')) ?> WIB</p>
</div>

<section class="panel no-print">
  <div class="chips mb-2">
    <?php foreach ($modes as $m => $lbl): ?>
      <a class="chip<?= $per['mode'] === $m ? ' active' : '' ?>"
         href="<?= e(url('admin/reports.php?period=' . $m)) ?>"><?= e($lbl) ?></a>
    <?php endforeach; ?>
  </div>

  <form class="toolbar" method="get" action="<?= e(url('admin/reports.php')) ?>">
    <input type="hidden" name="period" value="<?= e($per['mode']) ?>">

    <?php if ($per['mode'] === 'daily' || $per['mode'] === 'weekly'): ?>
      <label class="text-muted" for="date"><?= $per['mode'] === 'weekly' ? 'Tanggal dalam minggu' : 'Tanggal' ?></label>
      <input class="form-control" type="date" id="date" name="date" value="<?= e($per['date']) ?>">
    <?php elseif ($per['mode'] === 'monthly'): ?>
      <label class="text-muted" for="month">Bulan</label>
      <input class="form-control" type="month" id="month" name="month" value="<?= e(substr($per['start'], 0, 7)) ?>"
             pattern="20[0-9]{2}-[0-1][0-9]" placeholder="YYYY-MM">
    <?php else: ?>
      <label class="text-muted" for="from">Dari</label>
      <input class="form-control" type="date" id="from" name="from" value="<?= e($per['start']) ?>">
      <label class="text-muted" for="to">Sampai</label>
      <input class="form-control" type="date" id="to" name="to" value="<?= e($per['end']) ?>">
    <?php endif; ?>

    <button type="submit" class="btn btn-primary btn-sm">Tampilkan</button>
  </form>

  <?php if ($per['error']): ?>
    <div class="alert alert-warning"><div><?= e($per['error']) ?> Menampilkan periode bawaan.</div></div>
  <?php endif; ?>

  <div class="toolbar" style="margin-bottom:0">
    <span class="text-muted">Ekspor CSV:</span>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/reports.php?' . report_query($per, ['export' => 'sales']))) ?>">Penjualan per hari</a>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/reports.php?' . report_query($per, ['export' => 'products']))) ?>">Produk &amp; varian</a>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/reports.php?' . report_query($per, ['export' => 'orders']))) ?>">Transaksi</a>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/reports.php?' . report_query($per, ['export' => 'restocks']))) ?>">Restock</a>
  </div>
</section>

<h3 class="mb-2 no-print" style="margin-top:20px"><?= e($per['label']) ?></h3>

<div class="stat-grid">
  <div class="stat-card accent">
    <div class="stat-ico">💰</div>
    <div>
      <div class="stat-label">Nilai Penjualan</div>
      <div class="stat-value"><?= e(rupiah($summary['sales'])) ?></div>
      <div class="stat-sub"><?= (int) $summary['trx'] ?> transaksi lunas</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-ico">📦</div>
    <div>
      <div class="stat-label">Modal (Harga Pokok)</div>
      <div class="stat-value"><?= e(rupiah($summary['cost'])) ?></div>
      <div class="stat-sub">Dari produk yang terjual</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-ico">📈</div>
    <div>
      <div class="stat-label">Laba Kotor</div>
      <div class="stat-value"><?= e(rupiah($summary['profit'])) ?></div>
      <div class="stat-sub">Margin <?= e($fmtPct($summary['margin'])) ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-ico">🚚</div>
    <div>
      <div class="stat-label">Pembelian / Restock</div>
      <div class="stat-value"><?= e(rupiah($summary['restock_total'])) ?></div>
      <div class="stat-sub"><?= (int) $summary['restock_n'] ?> restock</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-ico">🧾</div>
    <div>
      <div class="stat-label">Pesanan Masuk</div>
      <div class="stat-value"><?= (int) $summary['orders_all'] ?></div>
      <div class="stat-sub"><?= (int) $summary['orders_cancel'] ?> dibatalkan &middot; <?= (int) $summary['orders_unpaid'] ?> belum dibayar</div>
    </div>
  </div>
</div>

<div class="<?= $chartPoints ? 'dash-grid' : '' ?>">
  <?php if ($chartPoints): ?>
    <section class="panel">
      <div class="panel-head"><h3>Grafik Nilai Penjualan per Hari</h3></div>
      <div class="chart-box" data-points="<?= e((string) json_encode($chartPoints, JSON_UNESCAPED_UNICODE)) ?>"></div>
    </section>
  <?php endif; ?>

  <section class="panel">
    <div class="panel-head"><h3>Penjualan vs Modal vs Laba</h3></div>
    <div class="kv"><span>Subtotal produk</span><strong><?= e(rupiah($summary['subtotal'])) ?></strong></div>
    <div class="kv"><span>Ongkir</span><strong><?= e(rupiah($summary['delivery'])) ?></strong></div>
    <div class="kv big"><span>Nilai penjualan</span><strong><?= e(rupiah($summary['sales'])) ?></strong></div>
    <div class="kv"><span>Modal</span><strong><?= e(rupiah($summary['cost'])) ?></strong></div>
    <div class="kv big"><span>Laba kotor</span><strong class="text-red"><?= e(rupiah($summary['profit'])) ?></strong></div>
    <p class="form-hint mt-1">Laba kotor = subtotal produk &minus; modal. Ongkir dan biaya operasional tidak dihitung.</p>
  </section>
</div>

<section class="panel">
  <div class="panel-head"><h3>Rincian per Hari</h3></div>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr><th>Tanggal</th><th class="text-right">Transaksi</th><th class="text-right">Nilai Penjualan</th>
            <th class="text-right">Modal</th><th class="text-right">Laba Kotor</th><th class="text-right">Pembelian</th></tr>
      </thead>
      <tbody>
        <?php foreach ($daily as $r): ?>
          <tr>
            <td class="nowrap"><?= e(date('d/m/Y', strtotime($r['date']))) ?></td>
            <td class="text-right"><?= (int) $r['trx'] ?></td>
            <td class="text-right nowrap"><?= e(rupiah($r['sales'])) ?></td>
            <td class="text-right nowrap"><?= e(rupiah($r['cost'])) ?></td>
            <td class="text-right nowrap"><?= e(rupiah($r['profit'])) ?></td>
            <td class="text-right nowrap"><?= e(rupiah($r['restock'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr>
          <td>Total</td>
          <td class="text-right"><?= (int) $totals['trx'] ?></td>
          <td class="text-right nowrap"><?= e(rupiah($totals['sales'])) ?></td>
          <td class="text-right nowrap"><?= e(rupiah($totals['cost'])) ?></td>
          <td class="text-right nowrap"><?= e(rupiah($totals['profit'])) ?></td>
          <td class="text-right nowrap"><?= e(rupiah($totals['restock'])) ?></td>
        </tr>
      </tfoot>
    </table>
  </div>
</section>

<div class="dash-grid even">
  <section class="panel">
    <div class="panel-head"><h3>Produk Terlaris</h3></div>
    <?php if (!$products): ?>
      <p class="text-muted">Belum ada penjualan lunas pada periode ini.</p>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>#</th><th>Produk</th><th class="text-right">Terjual</th><th class="text-right">Nilai</th></tr></thead>
          <tbody>
            <?php foreach ($products as $i => $r): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e((string) $r['name']) ?></td>
                <td class="text-right"><?= (int) $r['qty'] ?></td>
                <td class="text-right nowrap"><?= e(rupiah($r['revenue'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </section>

  <section class="panel">
    <div class="panel-head"><h3>Varian Terlaris</h3></div>
    <?php if (!$variants): ?>
      <p class="text-muted">Belum ada varian terjual pada periode ini.</p>
    <?php else: ?>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>#</th><th>Varian</th><th class="text-right">Dipilih</th><th class="text-right">Nilai</th></tr></thead>
          <tbody>
            <?php foreach ($variants as $i => $r): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e((string) $r['name']) ?><br><small class="text-muted"><?= e(addon_group_label((string) $r['grp'])) ?></small></td>
                <td class="text-right"><?= (int) $r['qty'] ?></td>
                <td class="text-right nowrap"><?= e(rupiah($r['revenue'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="form-hint mt-1">Nilai varian sudah termasuk di nilai produk. Jangan dijumlahkan dengan tabel produk.</p>
    <?php endif; ?>
  </section>
</div>

<section class="panel">
  <div class="panel-head"><h3>Transaksi Lunas</h3></div>
  <?php if (!$orders): ?>
    <p class="text-muted">Tidak ada transaksi lunas pada periode ini.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr><th>No. Pesanan</th><th>Waktu</th><th>Pelanggan</th><th>Bayar</th>
              <th class="text-right">Total</th><th class="text-right">Modal</th><th class="text-right">Laba Kotor</th><th>Status</th></tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $o): ?>
            <tr>
              <td class="nowrap"><a href="<?= e(url('admin/order_detail.php?id=' . (int) $o['id'])) ?>"><?= e((string) $o['order_number']) ?></a></td>
              <td class="nowrap"><?= e(format_datetime($o['created_at'])) ?></td>
              <td><?= e((string) $o['customer_name']) ?></td>
              <td><?= e(payment_method_label((string) $o['payment_method'])) ?></td>
              <td class="text-right nowrap"><?= e(rupiah($o['total'])) ?></td>
              <td class="text-right nowrap"><?= e(rupiah($o['total_cost'])) ?></td>
              <td class="text-right nowrap"><?= e(rupiah((float) $o['subtotal'] - (float) $o['total_cost'])) ?></td>
              <td><span class="badge badge-<?= e((string) $o['status']) ?>"><?= e(order_status_label((string) $o['status'])) ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if ($summary['trx'] > count($orders)): ?>
      <p class="form-hint mt-1">Menampilkan <?= count($orders) ?> dari <?= (int) $summary['trx'] ?> transaksi. Gunakan Ekspor CSV &raquo; Transaksi untuk data lengkap.</p>
    <?php endif; ?>
  <?php endif; ?>
</section>

<section class="panel">
  <div class="panel-head"><h3>Pembelian / Restock</h3></div>
  <?php if (!$restocks): ?>
    <p class="text-muted">Tidak ada restock pada periode ini.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>#</th><th>Tanggal</th><th>Pemasok</th><th class="text-right">Item</th><th class="text-right">Total</th></tr></thead>
        <tbody>
          <?php foreach ($restocks as $r): ?>
            <tr>
              <td><a href="<?= e(url('admin/restocks.php?view=' . (int) $r['id'])) ?>"><?= (int) $r['id'] ?></a></td>
              <td class="nowrap"><?= e(date('d/m/Y', strtotime((string) $r['restock_date']))) ?></td>
              <td><?= e((string) ($r['supplier_name'] ?? '-')) ?></td>
              <td class="text-right"><?= (int) $r['item_count'] ?></td>
              <td class="text-right nowrap"><?= e(rupiah($r['total_cost'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr><td colspan="4">Total pembelian</td><td class="text-right nowrap"><?= e(rupiah($summary['restock_total'])) ?></td></tr>
        </tfoot>
      </table>
    </div>
  <?php endif; ?>
  <p class="form-hint mt-1">Pembelian ditampilkan terpisah dan tidak mengurangi laba kotor, karena harga pokok barang terjual sudah termasuk di Modal.</p>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>