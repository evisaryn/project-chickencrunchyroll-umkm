<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo = db();

$editId = get_int('edit');
$edit   = null;
if ($editId > 0) {
    $st = $pdo->prepare('SELECT id, name, phone, address FROM suppliers WHERE id = ?');
    $st->execute([$editId]);
    $edit = $st->fetch() ?: null;
    if (!$edit) {
        flash('danger', 'Pemasok tidak ditemukan.');
        redirect('admin/suppliers.php');
    }
}

// Isi ulang form jika validasi sebelumnya gagal
$old = $_SESSION['supplier_old'] ?? null;
unset($_SESSION['supplier_old']);
$form = is_array($old) ? $old : ($edit ?? ['name' => '', 'phone' => '', 'address' => '']);

$suppliers = $pdo->query(
    'SELECT s.id, s.name, s.phone, s.address, s.is_active,
            (SELECT COUNT(*) FROM restocks r WHERE r.supplier_id = s.id) AS restock_count
     FROM suppliers s ORDER BY s.is_active DESC, s.name'
)->fetchAll();

$pageTitle  = 'Pemasok';
$activePage = 'suppliers';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Pemasok</h2>
    <p>Daftar pemasok yang dipakai saat mencatat restock.</p>
  </div>
  <a class="btn btn-outline" href="<?= e(url('admin/restocks.php')) ?>">Ke Restock</a>
</div>

<section class="panel">
  <div class="panel-head"><h3><?= $edit ? 'Edit Pemasok' : 'Tambah Pemasok' ?></h3></div>
  <form method="post" action="<?= e(url('actions/supplier_action.php')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= $edit ? (int) $edit['id'] : 0 ?>">

    <div class="form-grid">
      <div class="form-group">
        <label for="name">Nama Pemasok</label>
        <input class="form-control" type="text" id="name" name="name" required minlength="3" maxlength="150"
               value="<?= e((string) $form['name']) ?>">
      </div>
      <div class="form-group">
        <label for="phone">Telepon (opsional)</label>
        <input class="form-control" type="tel" id="phone" name="phone" maxlength="20"
               value="<?= e((string) ($form['phone'] ?? '')) ?>">
      </div>
    </div>
    <div class="form-group">
      <label for="address">Alamat (opsional)</label>
      <textarea class="form-control" id="address" name="address" maxlength="500"><?= e((string) ($form['address'] ?? '')) ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary" data-once><?= $edit ? 'Simpan' : 'Tambah Pemasok' ?></button>
    <?php if ($edit): ?><a class="btn btn-outline" href="<?= e(url('admin/suppliers.php')) ?>">Batal</a><?php endif; ?>
  </form>
</section>

<section class="panel">
  <div class="panel-head"><h3>Daftar Pemasok</h3></div>
  <?php if (!$suppliers): ?>
    <p class="text-muted">Belum ada pemasok.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>Nama</th><th>Telepon</th><th>Alamat</th><th class="text-right">Restock</th><th>Status</th><th>Aksi</th></tr></thead>
        <tbody>
          <?php foreach ($suppliers as $s): ?>
            <tr>
              <td><strong><?= e((string) $s['name']) ?></strong></td>
              <td><?= e((string) ($s['phone'] ?? '-')) ?></td>
              <td><?= e((string) ($s['address'] ?? '-')) ?></td>
              <td class="text-right"><?= (int) $s['restock_count'] ?></td>
              <td>
                <span class="badge <?= (int) $s['is_active'] === 1 ? 'badge-ok' : 'badge-muted' ?>">
                  <?= (int) $s['is_active'] === 1 ? 'Aktif' : 'Nonaktif' ?>
                </span>
              </td>
              <td>
                <div class="table-actions">
                  <a class="btn btn-outline btn-sm" href="<?= e(url('admin/suppliers.php?edit=' . (int) $s['id'])) ?>">Edit</a>
                  <form method="post" action="<?= e(url('actions/supplier_action.php')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
                    <button type="submit" class="btn btn-dark btn-sm"><?= (int) $s['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                  </form>
                  <form method="post" action="<?= e(url('actions/supplier_action.php')) ?>" data-confirm="Hapus pemasok ini?">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>