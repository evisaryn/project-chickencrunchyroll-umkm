<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_superadmin();

$old = $_SESSION['settings_old'] ?? null;
unset($_SESSION['settings_old']);

$keys = ['business_name', 'business_phone', 'business_email', 'business_address',
         'business_hours', 'default_min_stock', 'delivery_fee', 'bank_account'];
$v = [];
foreach ($keys as $k) {
    $v[$k] = is_array($old) && isset($old[$k]) ? (string) $old[$k] : get_setting($k);
}

$statusInfo = [
    ['pending',    'Pesanan baru dari pelanggan.',                    'Belum mengurangi stok',          'Belum dihitung (menunggu lunas)'],
    ['processing', 'Pesanan sedang dibuat.',                          'Stok dikurangi sekali di tahap ini', 'Dihitung jika sudah lunas'],
    ['ready',      'Siap diambil atau dikirim.',                      'Tidak ada perubahan',            'Dihitung jika sudah lunas'],
    ['completed',  'Selesai. Wajib lunas lebih dulu.',                'Tidak ada perubahan',            'Dihitung'],
    ['cancelled',  'Dibatalkan, alasan wajib diisi.',                 'Stok dikembalikan sekali bila sudah dikurangi', 'Tidak dihitung'],
];

$pageTitle  = 'Pengaturan';
$activePage = 'settings';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Pengaturan ERP</h2>
    <p>Profil bisnis, informasi toko, ongkir, dan batas minimum stok. Berlaku langsung di website pelanggan.</p>
  </div>
</div>

<section class="panel">
  <div class="panel-head"><h3>Profil Bisnis &amp; Toko</h3></div>
  <form method="post" action="<?= e(url('actions/settings_action.php')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">

    <div class="form-grid">
      <div class="form-group">
        <label for="business_name">Nama Usaha</label>
        <input class="form-control" type="text" id="business_name" name="business_name" required minlength="3" maxlength="100" value="<?= e($v['business_name']) ?>">
      </div>
      <div class="form-group">
        <label for="business_phone">Telepon / WhatsApp</label>
        <input class="form-control" type="tel" id="business_phone" name="business_phone" required maxlength="20" value="<?= e($v['business_phone']) ?>">
      </div>
      <div class="form-group">
        <label for="business_email">Email Usaha</label>
        <input class="form-control" type="email" id="business_email" name="business_email" required maxlength="150" value="<?= e($v['business_email']) ?>">
      </div>
      <div class="form-group">
        <label for="business_hours">Jam Operasional</label>
        <input class="form-control" type="text" id="business_hours" name="business_hours" required maxlength="100" value="<?= e($v['business_hours']) ?>">
      </div>
    </div>
    <div class="form-group">
      <label for="business_address">Alamat Toko</label>
      <textarea class="form-control" id="business_address" name="business_address" required maxlength="255"><?= e($v['business_address']) ?></textarea>
    </div>

    <div class="form-grid">
      <div class="form-group">
        <label for="default_min_stock">Batas Minimum Stok Bawaan</label>
        <input class="form-control" type="number" id="default_min_stock" name="default_min_stock" min="0" max="100000" step="1" required value="<?= e((string) (int) $v['default_min_stock']) ?>">
        <div class="form-hint">Nilai awal pada form produk baru.</div>
      </div>
      <div class="form-group">
        <label for="bank_account">Rekening Transfer</label>
        <input class="form-control" type="text" id="bank_account" name="bank_account" required maxlength="255" value="<?= e($v['bank_account']) ?>">
        <div class="form-hint">Tampil di checkout. Hanya rekening usaha.</div>
      </div>
    </div>

    <button type="submit" class="btn btn-primary" data-once>Simpan Pengaturan</button>
  </form>
</section>

<section class="panel">
  <div class="panel-head"><h3>Pembayaran QRIS</h3></div>
  <form method="post" action="<?= e(url('actions/settings_action.php')) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save_qris">

    <div class="form-grid">
      <div class="form-group">
        <label for="qris_name">Nama Merchant (tampil di bawah QR)</label>
        <input class="form-control" type="text" id="qris_name" name="qris_name" required maxlength="100"
               value="<?= e(get_setting('qris_name')) ?>">
      </div>
      <div class="form-group">
        <label for="qris_image">Gambar QRIS</label>
        <?php $qrisNow = qris_image_url(); ?>
        <?php if ($qrisNow !== null): ?>
          <img class="img-preview" src="<?= e($qrisNow) ?>" alt="QRIS saat ini" style="height:auto;width:180px">
        <?php else: ?>
          <p class="text-muted">Belum ada QRIS. Metode QRIS tidak tampil di checkout.</p>
        <?php endif; ?>
        <input class="form-control" type="file" id="qris_image" name="qris_image" accept="image/jpeg,image/png,image/webp">
        <div class="form-hint">JPG/PNG/WEBP, maks 2 MB. Pakai QRIS merchant resmi usaha Anda,
          dan pastikan hasil scan bertuliskan nama usaha yang benar.</div>
        <?php if ($qrisNow !== null): ?>
          <label class="mt-1"><input type="checkbox" name="remove_qris" value="1"> Hapus QRIS (nonaktifkan metode ini)</label>
        <?php endif; ?>
      </div>
    </div>
    <button type="submit" class="btn btn-primary" data-once>Simpan QRIS</button>
  </form>
</section>

<section class="panel">
  <div class="panel-head"><h3>Terapkan Batas Minimum ke Semua Produk</h3></div>
  <p class="text-muted mb-2">Mengatur batas minimum <strong>seluruh produk aktif</strong> menjadi nilai bawaan saat ini
    (<strong><?= (int) $v['default_min_stock'] ?></strong>). Simpan pengaturan dulu bila baru mengubah nilainya.</p>
  <form method="post" action="<?= e(url('actions/settings_action.php')) ?>"
        data-confirm="Timpa batas minimum SEMUA produk aktif dengan nilai bawaan?">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="apply_min_stock">
    <button type="submit" class="btn btn-dark" data-once>Terapkan ke Semua Produk</button>
  </form>
</section>

<section class="panel">
  <div class="panel-head"><h3>Status Pesanan (tetap, tidak dapat diubah)</h3></div>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>Status</th><th>Arti</th><th>Efek Stok</th><th>Laporan</th></tr></thead>
      <tbody>
        <?php foreach ($statusInfo as [$s, $meaning, $stock, $report]): ?>
          <tr>
            <td><span class="badge badge-<?= e($s) ?>"><?= e(order_status_label($s)) ?></span></td>
            <td><?= e($meaning) ?></td>
            <td><?= e($stock) ?></td>
            <td><?= e($report) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <p class="form-hint mt-1">Alur: Menunggu &rarr; Diproses &rarr; Siap &rarr; Selesai. Dibatalkan bisa dari tahap mana pun sebelum Selesai.
    Status terhubung ke aturan stok dan pembayaran, sehingga tidak dibuat editable.</p>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>