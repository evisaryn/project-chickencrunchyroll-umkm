<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo     = db();
$orderId = get_int('id');

$st = $pdo->prepare(
    'SELECT o.*, p.status AS pay_status, p.paid_at, p.note AS pay_note, u.email AS customer_email
     FROM orders o
     LEFT JOIN payments p ON p.order_id = o.id
     LEFT JOIN users u ON u.id = o.user_id
     WHERE o.id = ? LIMIT 1'
);
$st->execute([$orderId]);
$order = $st->fetch();

if (!$order) {
    http_response_code(404);
    $pageTitle  = 'Pesanan Tidak Ditemukan';
    $activePage = 'orders';
    require __DIR__ . '/../includes/admin_header.php';
    echo '<div class="panel"><p>Pesanan tidak ditemukan.</p>'
       . '<a class="btn btn-primary mt-2" href="' . e(url('admin/orders.php')) . '">Kembali ke daftar pesanan</a></div>';
    require __DIR__ . '/../includes/admin_footer.php';
    exit;
}

// Item dan varian
$st = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');
$st->execute([$orderId]);
$items = $st->fetchAll();

$addons = [];
if ($items) {
    $itemIds = array_map(static fn ($i) => (int) $i['id'], $items);
    $in = implode(',', array_fill(0, count($itemIds), '?'));
    $st = $pdo->prepare(
        "SELECT order_item_id, addon_name, addon_group FROM order_item_addons
         WHERE order_item_id IN ($in)
         ORDER BY FIELD(addon_group, 'sauce', 'powder', 'filling'), addon_name"
    );
    $st->execute($itemIds);
    foreach ($st->fetchAll() as $a) {
        $addons[(int) $a['order_item_id']][(string) $a['addon_group']][] = (string) $a['addon_name'];
    }
}

// Perubahan stok yang terkait pesanan ini
$st = $pdo->prepare(
    "SELECT m.movement_type, m.quantity, m.stock_before, m.stock_after, m.reference_type,
            m.notes, m.created_at, pr.name AS product_name
     FROM stock_movements m JOIN products pr ON pr.id = m.product_id
     WHERE m.reference_type IN ('order', 'order_cancel') AND m.reference_id = ?
     ORDER BY m.id"
);
$st->execute([$orderId]);
$movements = $st->fetchAll();

/* ---------- Status dan aksi yang tersedia ---------- */
$status    = (string) $order['status'];
$payStatus = (string) ($order['pay_status'] ?? '');
$delivery  = $order['fulfillment'] === 'delivery';

$nextMap = ['pending' => 'processing', 'processing' => 'ready', 'ready' => 'completed'];
$next    = $nextMap[$status] ?? null;

$nextLabels = [
    'processing' => 'Proses Pesanan',
    'ready'      => $delivery ? 'Tandai Siap Dikirim' : 'Tandai Siap Diambil',
    'completed'  => 'Tandai Selesai',
];
$nextHints = [
    'processing' => 'Stok produk dan semua varian akan dikurangi sekarang (hanya sekali).',
    'ready'      => 'Pelanggan akan melihat status siap pada halaman pesanannya.',
    'completed'  => 'Pesanan masuk laporan penjualan jika pembayaran sudah lunas.',
];

$canCancel   = in_array($status, ['pending', 'processing', 'ready'], true);
$canVerify   = $payStatus === 'unpaid' && $status !== 'cancelled';
$canUnverify = $payStatus === 'paid' && !in_array($status, ['cancelled', 'completed'], true);
$needPayment = $next === 'completed' && $payStatus !== 'paid';

$flow       = ['pending', 'processing', 'ready', 'completed'];
$currentIdx = array_search($status, $flow, true);
$grossProfit = (float) $order['subtotal'] - (float) $order['total_cost'];

$actionUrl = url('actions/admin_order_action.php');

$pageTitle  = 'Pesanan ' . $order['order_number'];
$activePage = 'orders';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <p><a href="<?= e(url('admin/orders.php')) ?>">&larr; Semua pesanan</a></p>
      <h2><?= e((string) $order['order_number']) ?>
      <?php if (!empty($order['queue_number'])): ?>
        <span class="queue-chip">
          <?= e(queue_label($order['queue_number'])) ?>
        </span>
      <?php endif; ?></h2>
    <p>Dibuat <?= e(format_datetime($order['created_at'])) ?></p>
  </div>
  <div>
    <span class="badge badge-<?= e($status) ?>"><?= e(order_status_label($status)) ?></span>
    <span class="badge badge-<?= e($payStatus) ?>"><?= e(payment_status_label($payStatus)) ?></span>
  </div>
</div>

<?php if ($status !== 'cancelled'): ?>
      <a class="btn btn-outline btn-sm" href="<?= e(url('admin/receipt.php?id=' . (int) $order['id'])) ?>" target="_blank" rel="noopener">🧾 Cetak Struk</a>
<?php endif; ?>

<?php if ($status === 'cancelled'): ?>
  <div class="alert alert-danger">
    <div><strong>Pesanan dibatalkan.</strong>
      <?php if ($order['cancel_reason']): ?> Alasan: <?= e((string) $order['cancel_reason']) ?><?php endif; ?></div>
  </div>
<?php else: ?>
  <div class="timeline">
    <?php foreach ($flow as $i => $s): ?>
      <div class="step<?= ($currentIdx !== false && $i <= $currentIdx) ? ' done' : '' ?>">
        <?= e($s === 'ready' ? ($delivery ? 'Siap Dikirim' : 'Siap Diambil') : order_status_label($s)) ?>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<div class="detail-grid">
  <div>
    <section class="panel">
      <div class="panel-head"><h3>Item Pesanan</h3></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Item</th><th class="text-right">Jumlah</th><th class="text-right">Harga/porsi</th><th class="text-right">Subtotal</th></tr></thead>
          <tbody>
            <?php foreach ($items as $it): ?>
              <tr>
                <td>
                  <strong><?= e((string) $it['product_name']) ?></strong>
                  <?php foreach ($addons[(int) $it['id']] ?? [] as $group => $names): ?>
                    <br><small class="text-muted"><?= e(addon_group_label((string) $group)) ?>: <?= e(implode(', ', $names)) ?></small>
                  <?php endforeach; ?>
                </td>
                <td class="text-right"><?= (int) $it['quantity'] ?></td>
                <td class="text-right nowrap"><?= e(rupiah((float) $it['unit_price'] + (float) $it['addon_total'])) ?></td>
                <td class="text-right nowrap"><?= e(rupiah($it['line_total'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="mt-2">
        <div class="kv"><span>Subtotal</span><strong><?= e(rupiah($order['subtotal'])) ?></strong></div>
        <div class="kv"><span>Ongkir</span><strong><?= e(rupiah($order['delivery_fee'])) ?></strong></div>
        <div class="kv big"><span>Total</span><strong class="text-red"><?= e(rupiah($order['total'])) ?></strong></div>
        <div class="kv"><span>Modal (harga pokok saat dipesan)</span><strong><?= e(rupiah($order['total_cost'])) ?></strong></div>
        <div class="kv"><span>Laba kotor (subtotal &minus; modal)</span><strong><?= e(rupiah($grossProfit)) ?></strong></div>
      </div>
      <?php if ($order['notes']): ?>
        <p class="mt-2"><strong>Catatan pelanggan:</strong> <?= e((string) $order['notes']) ?></p>
      <?php endif; ?>
    </section>

    <section class="panel">
      <div class="panel-head"><h3>Pelanggan &amp; Pengambilan</h3></div>
      <div class="kv"><span>Nama</span><strong><?= e((string) $order['customer_name']) ?></strong></div>
      <div class="kv"><span>Telepon</span><strong><?= e((string) $order['customer_phone']) ?></strong></div>
      <div class="kv"><span>Email akun</span><strong><?= e((string) ($order['customer_email'] ?? '-')) ?></strong></div>
      <div class="kv"><span>Pengambilan</span><strong><?= e(fulfillment_label((string) $order['fulfillment'])) ?></strong></div>
      <?php if ($delivery): ?>
        <div class="kv"><span>Alamat</span><strong><?= nl2br(e((string) $order['address'])) ?></strong></div>
      <?php endif; ?>
    </section>

    <section class="panel">
      <div class="panel-head"><h3>Riwayat Stok Pesanan Ini</h3></div>
      <?php if (!$movements): ?>
        <p class="text-muted">Belum ada perubahan stok. Stok dikurangi saat pesanan diproses.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Waktu</th><th>Barang</th><th class="text-right">Perubahan</th><th class="text-right">Stok</th><th>Sumber</th></tr></thead>
            <tbody>
              <?php foreach ($movements as $m): $in = $m['movement_type'] === 'in'; ?>
                <tr>
                  <td class="nowrap"><?= e(format_datetime($m['created_at'])) ?></td>
                  <td><?= e((string) $m['product_name']) ?></td>
                  <td class="text-right <?= $in ? 'mov-in' : 'mov-out' ?>"><?= $in ? '+' : '&minus;' ?><?= (int) $m['quantity'] ?></td>
                  <td class="text-right nowrap"><?= (int) $m['stock_before'] ?> &rarr; <?= (int) $m['stock_after'] ?></td>
                  <td><?= e(movement_ref_label((string) $m['reference_type'])) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
  </div>

  <aside>
    <section class="panel">
      <div class="panel-head"><h3>Status Pesanan</h3></div>
      <div class="kv"><span>Status</span><span class="badge badge-<?= e($status) ?>"><?= e(order_status_label($status)) ?></span></div>
      <div class="kv"><span>Stok</span><strong><?= (int) $order['stock_deducted'] === 1 ? 'Sudah dikurangi' : 'Belum dikurangi' ?></strong></div>

      <?php if ($next !== null): ?>
        <div class="action-box">
          <h4>Langkah berikutnya</h4>
          <p class="form-hint mb-2"><?= e($nextHints[$next]) ?></p>
          <?php if ($needPayment): ?>
            <div class="alert alert-warning"><div>Verifikasi pembayaran dulu sebelum menyelesaikan pesanan.</div></div>
          <?php endif; ?>
          <form method="post" action="<?= e($actionUrl) ?>"
                <?= $next === 'processing' ? 'data-confirm="Proses pesanan ini? Stok akan dikurangi."' : '' ?>>
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="advance">
            <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
            <input type="hidden" name="to" value="<?= e($next) ?>">
            <button type="submit" class="btn btn-primary btn-block" data-once <?= $needPayment ? 'disabled' : '' ?>>
              <?= e($nextLabels[$next]) ?></button>
          </form>
        </div>
      <?php endif; ?>
    </section>

    <section class="panel">
      <div class="panel-head"><h3>Pembayaran</h3></div>
      <div class="kv"><span>Metode</span><strong><?= e(payment_method_label((string) $order['payment_method'])) ?></strong></div>
      <div class="kv"><span>Status</span><span class="badge badge-<?= e($payStatus) ?>"><?= e(payment_status_label($payStatus)) ?></span></div>
      <div class="kv"><span>Jumlah</span><strong><?= e(rupiah($order['total'])) ?></strong></div>
      <?php if ($order['paid_at']): ?>
        <div class="kv"><span>Dibayar</span><strong><?= e(format_datetime($order['paid_at'])) ?></strong></div>
      <?php endif; ?>
      <?php if ($order['pay_note']): ?>
        <div class="kv"><span>Catatan</span><strong><?= e((string) $order['pay_note']) ?></strong></div>
      <?php endif; ?>

      <?php if ($order['payment_method'] === 'transfer' && $payStatus === 'unpaid'): ?>
        <p class="form-hint mt-1">Cocokkan dengan mutasi rekening: <?= e(get_setting('bank_account')) ?></p>
      <?php endif; ?>

      <?php if ($order['payment_method'] === 'qris' && $payStatus === 'unpaid'): ?>
        <p class="form-hint mt-1">Cek notifikasi/mutasi QRIS Anda: pastikan <strong><?= e(rupiah($order['total'])) ?></strong>
          sudah masuk, baru tekan Tandai Lunas.</p>
      <?php endif; ?>

      <?php if ($canVerify): ?>
        <div class="action-box">
          <h4>Verifikasi pembayaran</h4>
          <form method="post" action="<?= e($actionUrl) ?>" data-confirm="Tandai pesanan ini sebagai LUNAS?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="mark_paid">
            <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
            <div class="form-group">
              <label for="pay_note">Catatan (opsional)</label>
              <input class="form-control" type="text" id="pay_note" name="note" maxlength="255" placeholder="Contoh: transfer BCA a.n. Budi, 14.32">
              <div class="form-hint">Jangan isi nomor kartu atau data sensitif.</div>
            </div>
            <button type="submit" class="btn btn-primary btn-block" data-once>Tandai Lunas</button>
          </form>
        </div>
      <?php endif; ?>

      <?php if ($canUnverify): ?>
        <form method="post" action="<?= e($actionUrl) ?>" class="mt-2" data-confirm="Batalkan verifikasi pembayaran?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="mark_unpaid">
          <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
          <button type="submit" class="btn btn-outline btn-block btn-sm">Batalkan Verifikasi (salah tandai)</button>
        </form>
      <?php endif; ?>
    </section>

    <?php if ($canCancel): ?>
    <section class="panel">
      <div class="panel-head"><h3>Batalkan Pesanan</h3></div>
      <p class="form-hint mb-2">
        <?= (int) $order['stock_deducted'] === 1
            ? 'Stok yang sudah dikurangi akan dikembalikan otomatis (sekali).'
            : 'Stok belum dikurangi, jadi tidak ada stok yang perlu dikembalikan.' ?>
        <?= $payStatus === 'paid' ? ' Pembayaran akan ditandai "Dikembalikan"; dana harus Anda kembalikan secara manual.' : '' ?>
      </p>
      <form method="post" action="<?= e($actionUrl) ?>" data-confirm="Yakin membatalkan pesanan ini? Tindakan tidak bisa diurungkan.">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="cancel">
        <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
        <div class="form-group">
          <label for="reason">Alasan pembatalan</label>
          <input class="form-control" type="text" id="reason" name="reason" required minlength="3" maxlength="255"
                 placeholder="Contoh: stok habis, pelanggan tidak merespons">
        </div>
        <button type="submit" class="btn btn-danger btn-block" data-once>Batalkan Pesanan</button>
      </form>
    </section>
    <?php endif; ?>
  </aside>
</div>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>