<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stats.php';

require_admin();

$range = (string) ($_GET['range'] ?? 'daily');
if (!in_array($range, ['daily', 'monthly'], true)) {
    $range = 'daily';
}

$stats       = dashboard_stats();
$series      = sales_series($range);
$lowItems    = low_stock_items(6);
$topProducts = top_products(5);
$recent      = recent_orders(8);

$seriesTotal  = array_sum(array_column($series, 'value'));
$seriesOrders = array_sum(array_column($series, 'orders'));
$sc           = $stats['status_counts'];

$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Halo, <?= e(explode(' ', (string) $admin['name'])[0]) ?> 👋</h2>
    <p>Ringkasan bisnis <?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?> per <?= e(date('d/m/Y H:i')) ?> WIB.</p>
  </div>
  <a class="btn btn-primary" href="<?= e(url('admin/orders.php')) ?>">Kelola Pesanan</a>
</div>

<!-- Kartu statistik -->
<div class="stat-grid">
  <div class="stat-card accent">
    <div class="stat-ico">💰</div>
    <div>
      <div class="stat-label">Total Penjualan</div>
      <div class="stat-value"><?= e(rupiah($stats['sales_total'])) ?></div>
      <div class="stat-sub"><?= (int) $stats['sales_trx'] ?> transaksi lunas</div>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-ico">🧾</div>
    <div>
      <div class="stat-label">Pesanan Hari Ini</div>
      <div class="stat-value"><?= (int) $stats['orders_today'] ?></div>
      <div class="stat-sub">Penjualan lunas: <?= e(rupiah($stats['sales_today'])) ?></div>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-ico">🍗</div>
    <div>
      <div class="stat-label">Jumlah Produk</div>
      <div class="stat-value"><?= (int) $stats['products_main'] ?></div>
      <div class="stat-sub">+ <?= (int) $stats['products_addon'] ?> varian (saus, bubuk, filling)</div>
    </div>
  </div>

  <a class="stat-card<?= $stats['low_stock'] > 0 ? ' warn' : '' ?>" href="<?= e(url('admin/inventory.php?filter=low')) ?>" style="color:inherit">
    <div class="stat-ico">⚠️</div>
    <div>
      <div class="stat-label">Stok Menipis</div>
      <div class="stat-value"><?= (int) $stats['low_stock'] ?></div>
      <div class="stat-sub"><?= $stats['low_stock'] > 0 ? 'Perlu restock' : 'Semua stok aman' ?></div>
    </div>
  </a>

  <div class="stat-card">
    <div class="stat-ico">👥</div>
    <div>
      <div class="stat-label">Total Pelanggan</div>
      <div class="stat-value"><?= (int) $stats['customers'] ?></div>
      <div class="stat-sub">Akun pelanggan terdaftar</div>
    </div>
  </div>
</div>

<!-- Grafik dan ringkasan transaksi -->
<div class="dash-grid">
  <section class="panel">
    <div class="panel-head">
      <h3>Grafik Penjualan <?= $range === 'monthly' ? '12 Bulan Terakhir' : '14 Hari Terakhir' ?></h3>
      <div class="chips">
        <a class="chip<?= $range === 'daily' ? ' active' : '' ?>" href="<?= e(url('admin/dashboard.php?range=daily')) ?>">Harian</a>
        <a class="chip<?= $range === 'monthly' ? ' active' : '' ?>" href="<?= e(url('admin/dashboard.php?range=monthly')) ?>">Bulanan</a>
      </div>
    </div>

    <div class="chart-box" id="salesChart" data-points="<?= e((string) json_encode($series, JSON_UNESCAPED_UNICODE)) ?>">
      <noscript><p class="text-muted">Aktifkan JavaScript untuk melihat grafik.</p></noscript>
    </div>
    <p class="chart-caption">
      Periode ini: <strong><?= e(rupiah($seriesTotal)) ?></strong> dari <?= (int) $seriesOrders ?> transaksi lunas.
      Hanya pesanan yang sudah diverifikasi lunas dan tidak dibatalkan yang dihitung.
    </p>
  </section>

  <section class="panel">
    <div class="panel-head"><h3>Ringkasan Transaksi</h3></div>

    <div class="kv"><span>Menunggu</span><strong><?= (int) $sc['pending'] ?></strong></div>
    <div class="kv"><span>Diproses</span><strong><?= (int) $sc['processing'] ?></strong></div>
    <div class="kv"><span>Siap Diambil/Dikirim</span><strong><?= (int) $sc['ready'] ?></strong></div>
    <div class="kv"><span>Selesai</span><strong><?= (int) $sc['completed'] ?></strong></div>
    <div class="kv"><span>Dibatalkan</span><strong><?= (int) $sc['cancelled'] ?></strong></div>
    <div class="kv"><span>Belum dibayar (aktif)</span><strong class="text-red"><?= (int) $stats['unpaid'] ?></strong></div>

    <div class="panel-head" style="margin-top:18px"><h3>Bulan Ini</h3></div>
    <div class="kv"><span>Nilai penjualan</span><strong><?= e(rupiah($stats['sales_month'])) ?></strong></div>
    <div class="kv"><span>Modal</span><strong><?= e(rupiah($stats['cost_month'])) ?></strong></div>
    <div class="kv big"><span>Laba kotor</span><strong class="text-red"><?= e(rupiah($stats['profit_month'])) ?></strong></div>
    <p class="form-hint mt-1">Laba kotor = subtotal produk &minus; modal. Ongkir dan biaya operasional tidak dihitung.</p>
  </section>
</div>

<!-- Stok menipis dan produk terlaris -->
<div class="dash-grid even">
  <section class="panel">
    <div class="panel-head">
      <h3>Stok Menipis</h3>
      <a class="btn btn-outline btn-sm" href="<?= e(url('admin/inventory.php?filter=low')) ?>">Lihat semua</a>
    </div>
    <?php if (!$lowItems): ?>
      <p class="text-muted">Semua stok masih di atas batas minimum. ✅</p>
    <?php else: ?>
      <ul class="mini-list">
        <?php foreach ($lowItems as $it): $out = (int) $it['stock'] <= 0; ?>
          <li>
            <span>
              <?= e($it['name']) ?>
              <span class="sub"><?= $it['product_type'] === 'addon' ? 'Varian' : 'Produk utama' ?> &middot; minimum <?= (int) $it['min_stock'] ?></span>
            </span>
            <span class="badge <?= $out ? 'badge-out' : 'badge-low' ?>"><?= $out ? 'Habis' : 'Sisa ' . (int) $it['stock'] ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

  <section class="panel">
    <div class="panel-head"><h3>Produk Terlaris</h3></div>
    <?php if (!$topProducts): ?>
      <p class="text-muted">Belum ada penjualan lunas.</p>
    <?php else: ?>
      <ul class="mini-list">
        <?php foreach ($topProducts as $i => $tp): ?>
          <li>
            <span>
              <strong>#<?= $i + 1 ?></strong> <?= e($tp['product_name']) ?>
              <span class="sub"><?= e(rupiah($tp['revenue'])) ?></span>
            </span>
            <span class="badge badge-ok"><?= (int) $tp['qty'] ?> terjual</span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</div>

<!-- Pesanan terbaru -->
<section class="panel">
  <div class="panel-head">
    <h3>Pesanan Terbaru</h3>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/orders.php')) ?>">Semua pesanan</a>
  </div>

  <?php if (!$recent): ?>
    <p class="text-muted">Belum ada pesanan masuk.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>No. Pesanan</th><th>Pelanggan</th><th>Tanggal</th>
            <th class="text-right">Total</th><th>Status</th><th>Pembayaran</th><th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent as $o): ?>
            <tr>
              <td class="nowrap"><strong><?= e($o['order_number']) ?></strong></td>
              <td><?= e($o['customer_name']) ?></td>
              <td class="nowrap"><?= e(format_datetime($o['created_at'])) ?></td>
              <td class="text-right nowrap"><?= e(rupiah($o['total'])) ?></td>
              <td><span class="badge badge-<?= e($o['status']) ?>"><?= e(order_status_label($o['status'])) ?></span></td>
              <td><span class="badge badge-<?= e((string) $o['pay_status']) ?>"><?= e(payment_status_label((string) $o['pay_status'])) ?></span></td>
              <td><a class="btn btn-outline btn-sm" href="<?= e(url('admin/order_detail.php?id=' . (int) $o['id'])) ?>">Detail</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>