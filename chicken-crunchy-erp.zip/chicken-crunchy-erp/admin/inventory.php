<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo = db();

/* ---------- Parameter (semua divalidasi) ---------- */
$filter = (string) ($_GET['filter'] ?? '');
if (!in_array($filter, ['low', 'inactive'], true)) { $filter = ''; }
$q      = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 60);
$hp     = get_int('hp');                                  // filter riwayat: produk
$ht     = (string) ($_GET['ht'] ?? '');                   // filter riwayat: in/out
if (!in_array($ht, ['in', 'out'], true)) { $ht = ''; }
$page   = max(1, get_int('page', 1));
$preselect = get_int('product');

function inv_url(string $filter, string $q, int $hp, string $ht, int $page = 1): string
{
    $query = array_filter([
        'filter' => $filter,
        'q'      => $q,
        'hp'     => $hp > 0 ? (string) $hp : '',
        'ht'     => $ht,
        'page'   => $page > 1 ? (string) $page : '',
    ], static fn ($v) => $v !== '');
    return url('admin/inventory.php') . ($query ? '?' . http_build_query($query) : '');
}

/* ---------- Daftar stok ---------- */
$sql = 'SELECT p.id, p.name, p.stock, p.min_stock, p.product_type, p.addon_group, p.is_active,
               c.name AS category_name
        FROM products p JOIN categories c ON c.id = p.category_id WHERE ';
$sql .= $filter === 'inactive'
    ? 'p.is_active = 0'
    : ($filter === 'low' ? 'p.is_active = 1 AND p.stock <= p.min_stock' : 'p.is_active = 1');
$params = [];
if ($q !== '') {
    $sql .= ' AND p.name LIKE ?';
    $params[] = '%' . addcslashes($q, '%_\\') . '%';
}
$sql .= ' ORDER BY (p.stock <= p.min_stock) DESC, p.product_type, p.name';
$st = $pdo->prepare($sql);
$st->execute($params);
$items = $st->fetchAll();

$allProducts = $pdo->query(
    'SELECT id, name, stock, is_active FROM products ORDER BY product_type, name'
)->fetchAll();

/* ---------- Riwayat stok ---------- */
$perPage = 30;
$where   = ' WHERE 1 = 1';
$hParams = [];
if ($hp > 0) { $where .= ' AND m.product_id = ?';    $hParams[] = $hp; }
if ($ht !== '') { $where .= ' AND m.movement_type = ?'; $hParams[] = $ht; }

$st = $pdo->prepare('SELECT COUNT(*) FROM stock_movements m' . $where);
$st->execute($hParams);
$totalRows  = (int) $st->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * $perPage;

// LIMIT/OFFSET adalah integer hasil olahan sendiri, aman disisipkan langsung
$st = $pdo->prepare(
    'SELECT m.*, p.name AS product_name, u.name AS admin_name
     FROM stock_movements m
     JOIN products p ON p.id = m.product_id
     LEFT JOIN users u ON u.id = m.created_by'
    . $where . ' ORDER BY m.id DESC LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset
);
$st->execute($hParams);
$history = $st->fetchAll();

$pageTitle  = 'Inventaris & Stok';
$activePage = 'inventory';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Inventaris</h2>
    <p>Pantau stok, catat barang masuk/keluar, dan lihat riwayat perubahan.</p>
  </div>
  <a class="btn btn-outline" href="<?= e(url('admin/restocks.php')) ?>">Restock dari Pemasok</a>
</div>

<!-- Daftar stok -->
<section class="panel">
  <div class="panel-head">
    <h3>Stok Saat Ini</h3>
    <div class="chips">
      <a class="chip<?= $filter === '' ? ' active' : '' ?>" href="<?= e(inv_url('', $q, $hp, $ht)) ?>">Aktif</a>
      <a class="chip<?= $filter === 'low' ? ' active' : '' ?>" href="<?= e(inv_url('low', $q, $hp, $ht)) ?>">Menipis</a>
      <a class="chip<?= $filter === 'inactive' ? ' active' : '' ?>" href="<?= e(inv_url('inactive', $q, $hp, $ht)) ?>">Nonaktif</a>
    </div>
  </div>

  <form class="toolbar" method="get" action="<?= e(url('admin/inventory.php')) ?>">
    <?php if ($filter !== ''): ?><input type="hidden" name="filter" value="<?= e($filter) ?>"><?php endif; ?>
    <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari barang..." maxlength="60">
    <button type="submit" class="btn btn-primary btn-sm">Cari</button>
    <?php if ($q !== ''): ?><a class="btn btn-outline btn-sm" href="<?= e(inv_url($filter, '', $hp, $ht)) ?>">Reset</a><?php endif; ?>
  </form>

  <?php if (!$items): ?>
    <p class="text-muted">Tidak ada barang yang cocok.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr><th>Barang</th><th>Tipe</th><th class="text-right">Stok</th><th class="text-right">Minimum</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($items as $it):
              $stock = (int) $it['stock'];
              $min   = (int) $it['min_stock'];
              if ($stock <= 0)       { $cls = 'badge-out'; $lbl = 'Habis'; }
              elseif ($stock <= $min) { $cls = 'badge-low'; $lbl = 'Menipis'; }
              else                    { $cls = 'badge-ok';  $lbl = 'Aman'; } ?>
            <tr>
              <td><strong><?= e((string) $it['name']) ?></strong><br><small class="text-muted"><?= e((string) $it['category_name']) ?></small></td>
              <td><?= $it['product_type'] === 'main' ? 'Utama' : e(addon_group_label((string) $it['addon_group'])) ?></td>
              <td class="text-right"><strong><?= $stock ?></strong></td>
              <td class="text-right"><?= $min ?></td>
              <td><span class="badge <?= $cls ?>"><?= $lbl ?></span></td>
              <td>
                <div class="table-actions">
                  <a class="btn btn-outline btn-sm" href="<?= e(url('admin/inventory.php?product=' . (int) $it['id'] . '#adjust')) ?>">Catat Stok</a>
                  <a class="btn btn-outline btn-sm" href="<?= e(inv_url($filter, $q, (int) $it['id'], $ht)) ?>#history">Riwayat</a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<!-- Form barang masuk / keluar -->
<section class="panel" id="adjust">
  <div class="panel-head"><h3>Catat Barang Masuk / Keluar</h3></div>
  <form method="post" action="<?= e(url('actions/stock_action.php')) ?>">
    <?= csrf_field() ?>
    <div class="form-3">
      <div class="form-group">
        <label for="product_id">Barang</label>
        <select class="form-control" id="product_id" name="product_id" required>
          <option value="">-- Pilih barang --</option>
          <?php foreach ($allProducts as $p): ?>
            <option value="<?= (int) $p['id'] ?>" <?= $preselect === (int) $p['id'] ? 'selected' : '' ?>>
              <?= e((string) $p['name']) ?> (stok <?= (int) $p['stock'] ?>)<?= (int) $p['is_active'] === 1 ? '' : ' [nonaktif]' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="movement_type">Jenis</label>
        <select class="form-control" id="movement_type" name="movement_type" required>
          <option value="in">Barang masuk (tambah stok)</option>
          <option value="out">Barang keluar (kurangi stok)</option>
        </select>
      </div>
      <div class="form-group">
        <label for="quantity">Jumlah</label>
        <input class="form-control" type="number" id="quantity" name="quantity" min="1" max="100000" step="1" required>
      </div>
    </div>
    <div class="form-group">
      <label for="notes">Keterangan / Alasan</label>
      <input class="form-control" type="text" id="notes" name="notes" maxlength="255"
             placeholder="Contoh: rusak saat penyimpanan, koreksi hitung fisik">
      <div class="form-hint">Wajib diisi untuk barang keluar. Stok tidak boleh menjadi negatif.
        Untuk pembelian dari pemasok, gunakan menu <a href="<?= e(url('admin/restocks.php')) ?>">Restock</a> agar harga beli tercatat.</div>
    </div>
    <button type="submit" class="btn btn-primary" data-once>Simpan Perubahan Stok</button>
  </form>
</section>

<!-- Riwayat -->
<section class="panel" id="history">
  <div class="panel-head"><h3>Riwayat Perubahan Stok</h3></div>

  <form class="toolbar" method="get" action="<?= e(url('admin/inventory.php')) ?>">
    <?php if ($filter !== ''): ?><input type="hidden" name="filter" value="<?= e($filter) ?>"><?php endif; ?>
    <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>
    <select class="form-control" name="hp">
      <option value="0">Semua barang</option>
      <?php foreach ($allProducts as $p): ?>
        <option value="<?= (int) $p['id'] ?>" <?= $hp === (int) $p['id'] ? 'selected' : '' ?>><?= e((string) $p['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="form-control" name="ht">
      <option value="">Masuk &amp; keluar</option>
      <option value="in"  <?= $ht === 'in'  ? 'selected' : '' ?>>Hanya masuk</option>
      <option value="out" <?= $ht === 'out' ? 'selected' : '' ?>>Hanya keluar</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Terapkan</button>
    <?php if ($hp > 0 || $ht !== ''): ?><a class="btn btn-outline btn-sm" href="<?= e(inv_url($filter, $q, 0, '')) ?>#history">Reset</a><?php endif; ?>
  </form>

  <?php if (!$history): ?>
    <p class="text-muted">Belum ada riwayat perubahan stok.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr><th>Waktu</th><th>Barang</th><th class="text-right">Perubahan</th><th class="text-right">Stok</th><th>Sumber</th><th>Keterangan</th><th>Oleh</th></tr>
        </thead>
        <tbody>
          <?php foreach ($history as $m):
              $in = $m['movement_type'] === 'in'; ?>
            <tr>
              <td class="nowrap"><?= e(format_datetime($m['created_at'])) ?></td>
              <td><?= e((string) $m['product_name']) ?></td>
              <td class="text-right <?= $in ? 'mov-in' : 'mov-out' ?>"><?= $in ? '+' : '&minus;' ?><?= (int) $m['quantity'] ?></td>
              <td class="text-right nowrap"><?= (int) $m['stock_before'] ?> &rarr; <?= (int) $m['stock_after'] ?></td>
              <td class="nowrap">
                <?php if (in_array($m['reference_type'], ['order', 'order_cancel'], true) && $m['reference_id']): ?>
                  <a href="<?= e(url('admin/order_detail.php?id=' . (int) $m['reference_id'])) ?>">
                    <?= e(movement_ref_label((string) $m['reference_type'])) ?> #<?= (int) $m['reference_id'] ?></a>
                <?php elseif ($m['reference_type'] === 'restock' && $m['reference_id']): ?>
                  <?= e(movement_ref_label('restock')) ?> #<?= (int) $m['reference_id'] ?>
                <?php else: ?>
                  <?= e(movement_ref_label((string) $m['reference_type'])) ?>
                <?php endif; ?>
              </td>
              <td><?= e((string) ($m['notes'] ?? '-')) ?></td>
              <td><?= e((string) ($m['admin_name'] ?? '-')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a class="chip" href="<?= e(inv_url($filter, $q, $hp, $ht, $page - 1)) ?>#history">&laquo; Sebelumnya</a><?php endif; ?>
        <span class="text-muted">Halaman <?= $page ?> dari <?= $totalPages ?> (<?= $totalRows ?> catatan)</span>
        <?php if ($page < $totalPages): ?><a class="chip" href="<?= e(inv_url($filter, $q, $hp, $ht, $page + 1)) ?>#history">Berikutnya &raquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>