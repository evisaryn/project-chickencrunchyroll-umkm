<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/receipt.php';

require_admin();
$orderId = get_int('id');

$rcData = receipt_load($orderId); // admin boleh melihat semua pesanan
if ($rcData === null) {
    http_response_code(404);
    exit('Pesanan tidak ditemukan.');
}

if ($rcData['order']['status'] === 'cancelled') {
    flash('warning', 'Pesanan yang dibatalkan tidak memiliki struk.');
    redirect('admin/order_detail.php?id=' . $orderId);
}

receipt_render($rcData, url('admin/order_detail.php?id=' . $orderId));