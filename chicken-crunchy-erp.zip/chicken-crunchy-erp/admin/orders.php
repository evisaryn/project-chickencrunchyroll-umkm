<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo = db();

$statuses    = ['pending', 'processing', 'ready', 'completed', 'cancelled'];
$payStatuses = ['unpaid', 'paid', 'failed', 'refunded'];

$status = get_str('status', 12);
$pay    = get_str('pay', 10);
$q      = get_str('q', 60);
$from   = get_str('from', 10);
$to     = get_str('to', 10);
if (!in_array($status, $statuses, true))    { $status = ''; }
if (!in_array($pay, $payStatuses, true))    { $pay = ''; }
if ($from !== '' && !valid_date_ymd($from)) { $from = ''; }
if ($to !== ''   && !valid_date_ymd($to))   { $to = ''; }
$page = max(1, get_int('page', 1));

$filters = ['status' => $status, 'pay' => $pay, 'q' => $q, 'from' => $from, 'to' => $to];

function orders_url(array $f, int $page = 1): string
{
    $query = array_filter($f + ['page' => $page > 1 ? (string) $page : ''], static fn ($v) => $v !== '');
    return url('admin/orders.php') . ($query ? '?' . http_build_query($query) : '');
}

/* ---------- Kondisi query ---------- */
$where  = ' WHERE 1 = 1';
$params = [];
if ($status !== '') { $where .= ' AND o.status = ?'; $params[] = $status; }
if ($pay !== '')    { $where .= ' AND p.status = ?'; $params[] = $pay; }
if ($q !== '') {
    $where .= ' AND (o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ?)';
    $like = '%' . addcslashes($q, '%_\\') . '%';
    array_push($params, $like, $like, $like);
}
if ($from !== '') { $where .= ' AND o.created_at >= ?'; $params[] = $from . ' 00:00:00'; }
if ($to !== '')   { $where .= ' AND o.created_at < ?';  $params[] = date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00'; }

$base = ' FROM orders o LEFT JOIN payments p ON p.order_id = o.id';

$st = $pdo->prepare('SELECT COUNT(*)' . $base . $where);
$st->execute($params);
$totalRows  = (int) $st->fetchColumn();
$perPage    = 25;
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * $perPage;

$st = $pdo->prepare(
    'SELECT o.id, o.order_number, o.queue_number, o.customer_name, o.customer_phone, o.total, o.status,
            o.fulfillment, o.payment_method, o.created_at, p.status AS pay_status,
            (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count'
    . $base . $where
    . ' ORDER BY o.created_at DESC, o.id DESC LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset
);
$st->execute($params);
$orders = $st->fetchAll();

// Jumlah per status untuk chip
$counts = array_fill_keys($statuses, 0);
foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM orders GROUP BY status')->fetchAll() as $r) {
    $counts[(string) $r['status']] = (int) $r['n'];
}

$pageTitle  = 'Manajemen Pesanan';
$activePage = 'orders';
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Pesanan</h2>
    <p>Pesanan dari website pelanggan masuk di sini secara langsung.</p>
  </div>
</div>

<section class="panel">
  <div class="chips mb-2">
    <a class="chip<?= $status === '' ? ' active' : '' ?>" href="<?= e(orders_url(array_merge($filters, ['status' => '']))) ?>">Semua (<?= array_sum($counts) ?>)</a>
    <?php foreach ($statuses as $s): ?>
      <a class="chip<?= $status === $s ? ' active' : '' ?>"
         href="<?= e(orders_url(array_merge($filters, ['status' => $s]))) ?>"><?= e(order_status_label($s)) ?> (<?= $counts[$s] ?>)</a>
    <?php endforeach; ?>
  </div>

  <form class="toolbar" method="get" action="<?= e(url('admin/orders.php')) ?>">
    <?php if ($status !== ''): ?><input type="hidden" name="status" value="<?= e($status) ?>"><?php endif; ?>
    <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="No. pesanan / nama / telepon" maxlength="60">
    <select class="form-control" name="pay">
      <option value="">Semua pembayaran</option>
      <?php foreach ($payStatuses as $ps): ?>
        <option value="<?= e($ps) ?>" <?= $pay === $ps ? 'selected' : '' ?>><?= e(payment_status_label($ps)) ?></option>
      <?php endforeach; ?>
    </select>
    <label class="text-muted" for="from">Dari</label>
    <input class="form-control" type="date" id="from" name="from" value="<?= e($from) ?>">
    <label class="text-muted" for="to">Sampai</label>
    <input class="form-control" type="date" id="to" name="to" value="<?= e($to) ?>">
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/orders.php')) ?>">Reset</a>
  </form>

  <?php if (!$orders): ?>
    <p class="text-muted">Tidak ada pesanan yang cocok.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Antrean</th>
            <th>No. Pesanan</th><th>Pelanggan</th><th>Tanggal</th><th class="text-right">Item</th>
            <th class="text-right">Total</th><th>Pengambilan</th><th>Status</th><th>Pembayaran</th><th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $o): ?>
            <tr>
              <td><strong><?= e(queue_label($o['queue_number'])) ?></strong></td>
              <td class="nowrap"><strong><?= e((string) $o['order_number']) ?></strong></td>
              <td><?= e((string) $o['customer_name']) ?><br><small class="text-muted"><?= e((string) $o['customer_phone']) ?></small></td>
              <td class="nowrap"><?= e(format_datetime($o['created_at'])) ?></td>
              <td class="text-right"><?= (int) $o['item_count'] ?></td>
              <td class="text-right nowrap"><?= e(rupiah($o['total'])) ?></td>
              <td><?= e(fulfillment_label((string) $o['fulfillment'])) ?><br><small class="text-muted"><?= e(payment_method_label((string) $o['payment_method'])) ?></small></td>
              <td><span class="badge badge-<?= e((string) $o['status']) ?>"><?= e(order_status_label((string) $o['status'])) ?></span></td>
              <td><span class="badge badge-<?= e((string) $o['pay_status']) ?>"><?= e(payment_status_label((string) $o['pay_status'])) ?></span></td>
              <td><a class="btn btn-outline btn-sm" href="<?= e(url('admin/order_detail.php?id=' . (int) $o['id'])) ?>">Detail</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a class="chip" href="<?= e(orders_url($filters, $page - 1)) ?>">&laquo; Sebelumnya</a><?php endif; ?>
        <span class="text-muted">Halaman <?= $page ?> dari <?= $totalPages ?> (<?= $totalRows ?> pesanan)</span>
        <?php if ($page < $totalPages): ?><a class="chip" href="<?= e(orders_url($filters, $page + 1)) ?>">Berikutnya &raquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>