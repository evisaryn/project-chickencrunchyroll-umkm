<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo = db();

/* ---------- Filter daftar ---------- */
$q      = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 60);
$catId  = get_int('cat');
$type   = (string) ($_GET['type'] ?? '');
$status = (string) ($_GET['status'] ?? '');
if (!in_array($type, ['main', 'addon'], true))          { $type = ''; }
if (!in_array($status, ['active', 'inactive'], true))   { $status = ''; }

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY id')->fetchAll();

/* ---------- Form tambah / edit ---------- */
$editId   = get_int('edit');
$showForm = (($_GET['form'] ?? '') === 'new') || $editId > 0;
$product  = null;

if ($editId > 0) {
    $st = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $st->execute([$editId]);
    $product = $st->fetch() ?: null;
    if (!$product) {
        flash('danger', 'Produk tidak ditemukan.');
        redirect('admin/products.php');
    }
}
$isEdit = $product !== null;

$money = static fn ($v): string => (string) (int) round((float) $v);

$form = $product ?? [
    'name' => '', 'category_id' => '', 'description' => '', 'image' => null,
    'price' => '0', 'cost_price' => '0', 'stock' => '0',
    'min_stock' => get_setting('default_min_stock', '10'),
    'product_type' => 'main', 'addon_group' => '', 'is_active' => 1,
];

// Isi ulang form jika validasi sebelumnya gagal
$old = $_SESSION['product_old'] ?? null;
unset($_SESSION['product_old']);
if (is_array($old)) {
    $form = array_merge($form, $old);
    $showForm = true;
}

/* ---------- Daftar produk ---------- */
$sql = "SELECT p.id, p.name, p.image, p.price, p.cost_price, p.stock, p.min_stock,
               p.product_type, p.addon_group, p.is_active, c.name AS category_name
        FROM products p
        JOIN categories c ON c.id = p.category_id
        WHERE 1 = 1";
$params = [];
if ($q !== '') {
    $sql .= ' AND (p.name LIKE ? OR p.description LIKE ?)';
    $like = '%' . addcslashes($q, '%_\\') . '%';
    $params[] = $like;
    $params[] = $like;
}
if ($catId > 0)          { $sql .= ' AND p.category_id = ?'; $params[] = $catId; }
if ($type !== '')        { $sql .= ' AND p.product_type = ?'; $params[] = $type; }
if ($status === 'active')   { $sql .= ' AND p.is_active = 1'; }
if ($status === 'inactive') { $sql .= ' AND p.is_active = 0'; }
$sql .= ' ORDER BY p.product_type, p.category_id, p.name LIMIT 300';

$st = $pdo->prepare($sql);
$st->execute($params);
$products = $st->fetchAll();

$pageTitle    = 'Manajemen Produk';
$activePage   = 'products';
$extraScripts = ['assets/js/admin_products.js'];
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Produk</h2>
    <p>Perubahan di sini langsung tampil di website pelanggan.</p>
  </div>
  <?php if (!$showForm): ?>
    <a class="btn btn-primary" href="<?= e(url('admin/products.php?form=new')) ?>">+ Tambah Produk</a>
  <?php endif; ?>
</div>

<?php if ($showForm): ?>
<section class="panel">
  <div class="panel-head">
    <h3><?= $isEdit ? 'Edit Produk' : 'Tambah Produk' ?></h3>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/products.php')) ?>">Batal</a>
  </div>

  <form method="post" action="<?= e(url('actions/product_action.php')) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= $isEdit ? (int) $product['id'] : 0 ?>">

    <div class="form-grid">
      <div class="form-group">
        <label for="name">Nama Produk</label>
        <input class="form-control" type="text" id="name" name="name" required minlength="3" maxlength="150"
               value="<?= e((string) $form['name']) ?>">
      </div>
      <div class="form-group">
        <label for="category_id">Kategori</label>
        <select class="form-control" id="category_id" name="category_id" required>
          <option value="">-- Pilih kategori --</option>
          <?php foreach ($categories as $c): ?>
            <option value="<?= (int) $c['id'] ?>" <?= (int) $form['category_id'] === (int) $c['id'] ? 'selected' : '' ?>>
              <?= e((string) $c['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="product_type">Tipe Produk</label>
        <select class="form-control" id="product_type" name="product_type" <?= $isEdit ? 'disabled' : '' ?>>
          <option value="main"  <?= $form['product_type'] === 'main'  ? 'selected' : '' ?>>Produk utama (roll)</option>
          <option value="addon" <?= $form['product_type'] === 'addon' ? 'selected' : '' ?>>Varian (saus / bubuk / filling)</option>
        </select>
        <?php if ($isEdit): ?><div class="form-hint">Tipe tidak dapat diubah setelah produk dibuat.</div><?php endif; ?>
      </div>
      <div class="form-group<?= $form['product_type'] === 'addon' ? '' : ' hidden' ?>" id="groupWrap">
        <label for="addon_group">Grup Varian</label>
        <select class="form-control" id="addon_group" name="addon_group" <?= $isEdit ? 'disabled' : '' ?>>
          <option value="">-- Pilih grup --</option>
          <?php foreach (['sauce', 'powder', 'filling'] as $g): ?>
            <option value="<?= e($g) ?>" <?= (string) $form['addon_group'] === $g ? 'selected' : '' ?>><?= e(addon_group_label($g)) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-group">
      <label for="description">Deskripsi</label>
      <textarea class="form-control" id="description" name="description" maxlength="1000"><?= e((string) ($form['description'] ?? '')) ?></textarea>
    </div>

    <div class="form-3">
      <div class="form-group">
        <label for="price">Harga Jual (Rp)</label>
        <input class="form-control" type="number" id="price" name="price" min="0" step="1" required
               value="<?= e($money($form['price'])) ?>">
        <div class="form-hint">Untuk varian: harga tambahan per porsi (0 = gratis).</div>
      </div>
      <div class="form-group">
        <label for="cost_price">Harga Pokok / Modal (Rp)</label>
        <input class="form-control" type="number" id="cost_price" name="cost_price" min="0" step="1" required
               value="<?= e($money($form['cost_price'])) ?>">
        <div class="form-hint">Dipakai menghitung laba di laporan.</div>
      </div>
      <div class="form-group">
        <label for="min_stock">Batas Minimum Stok</label>
        <input class="form-control" type="number" id="min_stock" name="min_stock" min="0" step="1" required
               value="<?= e((string) (int) $form['min_stock']) ?>">
      </div>
    </div>

    <div class="form-grid">
      <div class="form-group">
        <label for="stock">Stok</label>
        <?php if ($isEdit): ?>
          <input class="form-control" type="text" id="stock" value="<?= (int) $product['stock'] ?>" disabled>
          <div class="form-hint">Ubah stok lewat <a href="<?= e(url('admin/inventory.php?product=' . (int) $product['id'] . '#adjust')) ?>">Inventaris</a>
            atau Restock agar tercatat di riwayat.</div>
        <?php else: ?>
          <input class="form-control" type="number" id="stock" name="stock" min="0" step="1"
                 value="<?= e((string) (int) $form['stock']) ?>">
          <div class="form-hint">Stok awal, dicatat sebagai barang masuk.</div>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label for="image">Gambar Produk</label>
        <img id="imgPreview" class="img-preview" src="<?= e(product_image_url($form['image'] ?? null)) ?>" alt="Pratinjau">
        <input class="form-control" type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp">
        <div class="form-hint">JPG, PNG, atau WEBP, maksimal 2 MB.<?= $isEdit ? ' Kosongkan jika tidak ingin mengganti.' : '' ?></div>
      </div>
    </div>

    <div class="form-group">
      <label><input type="checkbox" name="is_active" value="1" <?= (int) $form['is_active'] === 1 ? 'checked' : '' ?>>
        Aktif (tampil di website pelanggan)</label>
    </div>

    <button type="submit" class="btn btn-primary" data-once><?= $isEdit ? 'Simpan Perubahan' : 'Simpan Produk' ?></button>
  </form>
</section>
<?php endif; ?>

<section class="panel">
  <form class="toolbar" method="get" action="<?= e(url('admin/products.php')) ?>">
    <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari produk..." maxlength="60">
    <select class="form-control" name="cat">
      <option value="0">Semua kategori</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= $catId === (int) $c['id'] ? 'selected' : '' ?>><?= e((string) $c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="form-control" name="type">
      <option value="">Semua tipe</option>
      <option value="main"  <?= $type === 'main'  ? 'selected' : '' ?>>Produk utama</option>
      <option value="addon" <?= $type === 'addon' ? 'selected' : '' ?>>Varian</option>
    </select>
    <select class="form-control" name="status">
      <option value="">Semua status</option>
      <option value="active"   <?= $status === 'active'   ? 'selected' : '' ?>>Aktif</option>
      <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>Nonaktif</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/products.php')) ?>">Reset</a>
    <span class="spacer"></span>
    <a class="btn btn-primary btn-sm" href="<?= e(url('admin/products.php?form=new')) ?>">+ Tambah</a>
  </form>

  <?php if (!$products): ?>
    <p class="text-muted">Tidak ada produk yang cocok.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>Foto</th><th>Produk</th><th>Tipe</th>
            <th class="text-right">Harga</th><th class="text-right">Modal</th>
            <th class="text-right">Stok</th><th>Status</th><th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($products as $p):
              $stock = (int) $p['stock'];
              $badge = $stock <= 0 ? 'badge-out' : ($stock <= (int) $p['min_stock'] ? 'badge-low' : 'badge-ok'); ?>
            <tr>
              <td><img class="thumb-sm" src="<?= e(product_image_url($p['image'])) ?>" alt=""></td>
              <td>
                <strong><?= e((string) $p['name']) ?></strong><br>
                <small class="text-muted"><?= e((string) $p['category_name']) ?></small>
              </td>
              <td><?= $p['product_type'] === 'main' ? 'Utama' : e(addon_group_label((string) $p['addon_group'])) ?></td>
              <td class="text-right nowrap"><?= e(rupiah($p['price'])) ?></td>
              <td class="text-right nowrap"><?= e(rupiah($p['cost_price'])) ?></td>
              <td class="text-right nowrap">
                <span class="badge <?= $badge ?>"><?= $stock ?></span><br>
                <small class="text-muted">min <?= (int) $p['min_stock'] ?></small>
              </td>
              <td>
                <span class="badge <?= (int) $p['is_active'] === 1 ? 'badge-ok' : 'badge-muted' ?>">
                  <?= (int) $p['is_active'] === 1 ? 'Aktif' : 'Nonaktif' ?>
                </span>
              </td>
              <td>
                <div class="table-actions">
                  <a class="btn btn-outline btn-sm" href="<?= e(url('admin/products.php?edit=' . (int) $p['id'])) ?>">Edit</a>

                  <form method="post" action="<?= e(url('actions/product_action.php')) ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                    <button type="submit" class="btn btn-dark btn-sm"><?= (int) $p['is_active'] === 1 ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                  </form>

                  <form method="post" action="<?= e(url('actions/product_action.php')) ?>"
                        data-confirm="Hapus produk ini permanen? Hanya bisa jika belum pernah dipesan.">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>