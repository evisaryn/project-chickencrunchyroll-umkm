<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_admin();
$pdo = db();

/** Satu baris barang pada form restock (dipakai juga untuk template JavaScript). */
function restock_row(array $products, string $pid = '', string $qty = '', string $cost = ''): string
{
    ob_start(); ?>
    <div class="item-row">
      <div class="form-group row-product">
        <label>Barang</label>
        <select class="form-control in-product" name="product_id[]" required>
          <option value="">-- Pilih barang --</option>
          <?php foreach ($products as $p): ?>
            <option value="<?= (int) $p['id'] ?>"
                    data-cost="<?= (int) round((float) $p['cost_price']) ?>"
                    <?= $pid === (string) $p['id'] ? 'selected' : '' ?>>
              <?= e((string) $p['name']) ?> (stok <?= (int) $p['stock'] ?>)<?= (int) $p['is_active'] === 1 ? '' : ' [nonaktif]' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Jumlah</label>
        <input class="form-control in-qty" type="number" name="quantity[]" min="1" max="100000" step="1" required value="<?= e($qty) ?>">
      </div>
      <div class="form-group">
        <label>Harga beli / unit (Rp)</label>
        <input class="form-control in-cost" type="number" name="unit_cost[]" min="1" step="1" required value="<?= e($cost) ?>">
      </div>
      <div class="row-subtotal">Rp 0</div>
      <button type="button" class="btn btn-outline btn-sm remove-row" aria-label="Hapus baris">&times;</button>
    </div>
    <?php
    return (string) ob_get_clean();
}

$viewId   = get_int('view');
$showForm = get_str('form', 5) === 'new';

/* ---------- Detail satu restock ---------- */
$restock = null;
$restockItems = [];
if ($viewId > 0) {
    $st = $pdo->prepare(
        'SELECT r.*, s.name AS supplier_name, u.name AS admin_name
         FROM restocks r
         LEFT JOIN suppliers s ON s.id = r.supplier_id
         LEFT JOIN users u ON u.id = r.created_by
         WHERE r.id = ?'
    );
    $st->execute([$viewId]);
    $restock = $st->fetch() ?: null;
    if (!$restock) {
        flash('danger', 'Data restock tidak ditemukan.');
        redirect('admin/restocks.php');
    }
    $st = $pdo->prepare(
        'SELECT ri.*, p.name AS product_name
         FROM restock_items ri JOIN products p ON p.id = ri.product_id
         WHERE ri.restock_id = ? ORDER BY ri.id'
    );
    $st->execute([$viewId]);
    $restockItems = $st->fetchAll();
}

/* ---------- Data form ---------- */
$old = $_SESSION['restock_old'] ?? null;
unset($_SESSION['restock_old']);
if (is_array($old)) {
    $showForm = true;
}
$suppliersActive = $pdo->query('SELECT id, name FROM suppliers WHERE is_active = 1 ORDER BY name')->fetchAll();
$allProducts     = $pdo->query(
    'SELECT id, name, stock, cost_price, is_active FROM products ORDER BY product_type, name'
)->fetchAll();

$form = [
    'supplier_id'  => is_array($old) ? (string) ($old['supplier_id'] ?? '') : '',
    'restock_date' => is_array($old) ? (string) ($old['restock_date'] ?? date('Y-m-d')) : date('Y-m-d'),
    'notes'        => is_array($old) ? (string) ($old['notes'] ?? '') : '',
    'update_cost'  => is_array($old) ? !empty($old['update_cost']) : true,
    'rows'         => is_array($old) && !empty($old['rows']) ? $old['rows'] : [['product_id' => '', 'quantity' => '', 'unit_cost' => '']],
];

/* ---------- Daftar riwayat (filter + halaman) ---------- */
$from = get_str('from', 10);
$to   = get_str('to', 10);
$sup  = get_int('sup');
if ($from !== '' && !valid_date_ymd($from)) { $from = ''; }
if ($to !== ''   && !valid_date_ymd($to))   { $to = ''; }
$page = max(1, get_int('page', 1));

$where  = ' WHERE 1 = 1';
$params = [];
if ($from !== '') { $where .= ' AND r.restock_date >= ?'; $params[] = $from; }
if ($to !== '')   { $where .= ' AND r.restock_date <= ?'; $params[] = $to; }
if ($sup > 0)     { $where .= ' AND r.supplier_id = ?';   $params[] = $sup; }

$st = $pdo->prepare('SELECT COUNT(*) AS n, COALESCE(SUM(r.total_cost), 0) AS total FROM restocks r' . $where);
$st->execute($params);
$sum        = $st->fetch();
$totalRows  = (int) $sum['n'];
$perPage    = 25;
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * $perPage;

$st = $pdo->prepare(
    'SELECT r.id, r.restock_date, r.total_cost, r.notes, s.name AS supplier_name, u.name AS admin_name,
            (SELECT COUNT(*) FROM restock_items ri WHERE ri.restock_id = r.id) AS item_count,
            (SELECT COALESCE(SUM(ri.quantity), 0) FROM restock_items ri WHERE ri.restock_id = r.id) AS qty_total
     FROM restocks r
     LEFT JOIN suppliers s ON s.id = r.supplier_id
     LEFT JOIN users u ON u.id = r.created_by'
    . $where . ' ORDER BY r.restock_date DESC, r.id DESC LIMIT ' . (int) $perPage . ' OFFSET ' . (int) $offset
);
$st->execute($params);
$restocks = $st->fetchAll();

$allSuppliers = $pdo->query('SELECT id, name FROM suppliers ORDER BY name')->fetchAll();

function restock_list_url(string $from, string $to, int $sup, int $page): string
{
    $q = array_filter([
        'from' => $from, 'to' => $to,
        'sup'  => $sup > 0 ? (string) $sup : '',
        'page' => $page > 1 ? (string) $page : '',
    ], static fn ($v) => $v !== '');
    return url('admin/restocks.php') . ($q ? '?' . http_build_query($q) : '');
}

$pageTitle    = 'Restock Barang';
$activePage   = 'restocks';
$extraScripts = $showForm ? ['assets/js/admin_restock.js'] : [];
require __DIR__ . '/../includes/admin_header.php';
?>

<div class="page-head">
  <div>
    <h2>Restock</h2>
    <p>Catat penerimaan barang dari pemasok. Stok bertambah otomatis dan tercatat di riwayat inventaris.</p>
  </div>
  <?php if (!$showForm): ?>
    <a class="btn btn-primary" href="<?= e(url('admin/restocks.php?form=new')) ?>">+ Restock Baru</a>
  <?php endif; ?>
</div>

<?php if ($restock): ?>
<section class="panel">
  <div class="panel-head">
    <h3>Detail Restock #<?= (int) $restock['id'] ?></h3>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/restocks.php')) ?>">Tutup</a>
  </div>
  <div class="kv"><span>Tanggal</span><strong><?= e(date('d/m/Y', strtotime((string) $restock['restock_date']))) ?></strong></div>
  <div class="kv"><span>Pemasok</span><strong><?= e((string) ($restock['supplier_name'] ?? '-')) ?></strong></div>
  <div class="kv"><span>Dicatat oleh</span><strong><?= e((string) ($restock['admin_name'] ?? '-')) ?></strong></div>
  <div class="kv"><span>Keterangan</span><strong><?= e((string) ($restock['notes'] ?? '-')) ?></strong></div>

  <div class="table-wrap mt-2">
    <table class="table">
      <thead><tr><th>Barang</th><th class="text-right">Jumlah</th><th class="text-right">Harga beli</th><th class="text-right">Subtotal</th></tr></thead>
      <tbody>
        <?php foreach ($restockItems as $ri): ?>
          <tr>
            <td><?= e((string) $ri['product_name']) ?></td>
            <td class="text-right"><?= (int) $ri['quantity'] ?></td>
            <td class="text-right nowrap"><?= e(rupiah($ri['unit_cost'])) ?></td>
            <td class="text-right nowrap"><?= e(rupiah($ri['subtotal'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="total-bar"><span>Total pembelian</span><span class="price"><?= e(rupiah($restock['total_cost'])) ?></span></div>
  <p class="form-hint">Restock tidak dapat diedit. Jika ada salah catat, koreksi lewat
    <a href="<?= e(url('admin/inventory.php#adjust')) ?>">Inventaris</a> (barang keluar manual dengan alasan koreksi).</p>
</section>
<?php endif; ?>

<?php if ($showForm): ?>
<section class="panel">
  <div class="panel-head">
    <h3>Restock Baru</h3>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/restocks.php')) ?>">Batal</a>
  </div>

  <form method="post" action="<?= e(url('actions/restock_action.php')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">

    <div class="form-3">
      <div class="form-group">
        <label for="supplier_id">Pemasok</label>
        <select class="form-control" id="supplier_id" name="supplier_id">
          <option value="0">-- Tanpa pemasok --</option>
          <?php foreach ($suppliersActive as $s): ?>
            <option value="<?= (int) $s['id'] ?>" <?= $form['supplier_id'] === (string) $s['id'] ? 'selected' : '' ?>>
              <?= e((string) $s['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="form-hint"><a href="<?= e(url('admin/suppliers.php')) ?>">Kelola pemasok</a></div>
      </div>
      <div class="form-group">
        <label for="restock_date">Tanggal</label>
        <input class="form-control" type="date" id="restock_date" name="restock_date" required
               max="<?= e(date('Y-m-d')) ?>" value="<?= e($form['restock_date']) ?>">
      </div>
      <div class="form-group">
        <label for="notes">Keterangan</label>
        <input class="form-control" type="text" id="notes" name="notes" maxlength="255"
               placeholder="Contoh: nota no. 0123" value="<?= e($form['notes']) ?>">
      </div>
    </div>

    <h4 class="mb-2">Barang yang Diterima</h4>
    <div class="item-rows" id="itemRows">
      <?php foreach ($form['rows'] as $r): ?>
        <?= restock_row($allProducts, (string) ($r['product_id'] ?? ''), (string) ($r['quantity'] ?? ''), (string) ($r['unit_cost'] ?? '')) ?>
      <?php endforeach; ?>
    </div>
    <template id="rowTemplate"><?= restock_row($allProducts) ?></template>

    <button type="button" class="btn btn-outline btn-sm" id="addRow">+ Tambah Barang</button>

    <div class="total-bar"><span>Total pembelian</span><span class="price" id="restockTotal">Rp 0</span></div>

    <div class="form-group">
      <label><input type="checkbox" name="update_cost" value="1" <?= $form['update_cost'] ? 'checked' : '' ?>>
        Perbarui harga pokok produk dengan harga beli ini</label>
      <div class="form-hint">Harga pokok dipakai menghitung laba pada pesanan <strong>berikutnya</strong>. Pesanan lama tidak berubah.</div>
    </div>

    <button type="submit" class="btn btn-primary" data-once>Simpan &amp; Tambah Stok</button>
  </form>
</section>
<?php endif; ?>

<section class="panel">
  <div class="panel-head"><h3>Riwayat Restock</h3></div>

  <form class="toolbar" method="get" action="<?= e(url('admin/restocks.php')) ?>">
    <label class="text-muted" for="from">Dari</label>
    <input class="form-control" type="date" id="from" name="from" value="<?= e($from) ?>">
    <label class="text-muted" for="to">Sampai</label>
    <input class="form-control" type="date" id="to" name="to" value="<?= e($to) ?>">
    <select class="form-control" name="sup">
      <option value="0">Semua pemasok</option>
      <?php foreach ($allSuppliers as $s): ?>
        <option value="<?= (int) $s['id'] ?>" <?= $sup === (int) $s['id'] ? 'selected' : '' ?>><?= e((string) $s['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a class="btn btn-outline btn-sm" href="<?= e(url('admin/restocks.php')) ?>">Reset</a>
  </form>

  <p class="text-muted mb-2"><?= $totalRows ?> restock, total pembelian
    <strong class="text-red"><?= e(rupiah($sum['total'])) ?></strong> (sesuai filter)</p>

  <?php if (!$restocks): ?>
    <p class="text-muted">Belum ada data restock.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>#</th><th>Tanggal</th><th>Pemasok</th><th class="text-right">Item</th><th class="text-right">Total Unit</th><th class="text-right">Total</th><th>Oleh</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($restocks as $r): ?>
            <tr>
              <td><?= (int) $r['id'] ?></td>
              <td class="nowrap"><?= e(date('d/m/Y', strtotime((string) $r['restock_date']))) ?></td>
              <td><?= e((string) ($r['supplier_name'] ?? '-')) ?></td>
              <td class="text-right"><?= (int) $r['item_count'] ?></td>
              <td class="text-right"><?= (int) $r['qty_total'] ?></td>
              <td class="text-right nowrap"><?= e(rupiah($r['total_cost'])) ?></td>
              <td><?= e((string) ($r['admin_name'] ?? '-')) ?></td>
              <td><a class="btn btn-outline btn-sm" href="<?= e(url('admin/restocks.php?view=' . (int) $r['id'])) ?>">Detail</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="pager">
        <?php if ($page > 1): ?><a class="chip" href="<?= e(restock_list_url($from, $to, $sup, $page - 1)) ?>">&laquo; Sebelumnya</a><?php endif; ?>
        <span class="text-muted">Halaman <?= $page ?> dari <?= $totalPages ?></span>
        <?php if ($page < $totalPages): ?><a class="chip" href="<?= e(restock_list_url($from, $to, $sup, $page + 1)) ?>">Berikutnya &raquo;</a><?php endif; ?>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>