<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_admin();

$pdo    = db();
$action = post_str('action', 20);

function handle_save(PDO $pdo): void
{
    $id   = post_int('id');
    $name = post_str('name', 100);
    $back = $id > 0 ? 'admin/categories.php?edit=' . $id : 'admin/categories.php';

    if (mb_strlen($name) < 3) {
        flash('danger', 'Nama kategori minimal 3 karakter.');
        redirect($back);
    }

    // Nama tidak boleh kembar (tanpa membedakan huruf besar/kecil)
    $st = $pdo->prepare('SELECT 1 FROM categories WHERE name = ? AND id <> ?');
    $st->execute([$name, $id]);
    if ($st->fetchColumn()) {
        flash('danger', 'Nama kategori sudah dipakai.');
        redirect($back);
    }

    if ($id > 0) {
        $st = $pdo->prepare('SELECT 1 FROM categories WHERE id = ?');
        $st->execute([$id]);
        if (!$st->fetchColumn()) {
            flash('danger', 'Kategori tidak ditemukan.');
            redirect('admin/categories.php');
        }
        // Slug tidak diubah agar tautan filter tetap valid
        $pdo->prepare('UPDATE categories SET name = ? WHERE id = ?')->execute([$name, $id]);
        flash('success', 'Kategori diperbarui.');
        redirect('admin/categories.php');
    }

    // Slug unik: tambahkan -2, -3, dst. bila bentrok
    $base = slugify($name);
    $slug = $base;
    $chk  = $pdo->prepare('SELECT 1 FROM categories WHERE slug = ?');
    for ($i = 2; $i < 100; $i++) {
        $chk->execute([$slug]);
        if (!$chk->fetchColumn()) {
            break;
        }
        $slug = $base . '-' . $i;
    }

    try {
        $pdo->prepare('INSERT INTO categories (name, slug) VALUES (?, ?)')->execute([$name, $slug]);
    } catch (PDOException $e) {
        error_log('Add category error: ' . $e->getMessage());
        flash('danger', 'Gagal menambah kategori.');
        redirect('admin/categories.php');
    }
    flash('success', 'Kategori "' . $name . '" ditambahkan.');
    redirect('admin/categories.php');
}

function handle_toggle(PDO $pdo): void
{
    $id = post_int('id');
    $st = $pdo->prepare('SELECT name, is_active FROM categories WHERE id = ?');
    $st->execute([$id]);
    $c = $st->fetch();
    if (!$c) {
        flash('danger', 'Kategori tidak ditemukan.');
        redirect('admin/categories.php');
    }
    $new = (int) $c['is_active'] === 1 ? 0 : 1;
    $pdo->prepare('UPDATE categories SET is_active = ? WHERE id = ?')->execute([$new, $id]);
    flash('success', 'Kategori "' . $c['name'] . '" ' . ($new === 1 ? 'diaktifkan.' : 'dinonaktifkan.'));
    redirect('admin/categories.php');
}

function handle_delete(PDO $pdo): void
{
    $id = post_int('id');
    $st = $pdo->prepare('SELECT name FROM categories WHERE id = ?');
    $st->execute([$id]);
    $c = $st->fetch();
    if (!$c) {
        flash('danger', 'Kategori tidak ditemukan.');
        redirect('admin/categories.php');
    }

    $st = $pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id = ?');
    $st->execute([$id]);
    if ((int) $st->fetchColumn() > 0) {
        flash('warning', 'Kategori masih memiliki produk. Pindahkan atau hapus produknya dulu, atau nonaktifkan kategori.');
        redirect('admin/categories.php');
    }

    $pdo->prepare('DELETE FROM categories WHERE id = ?')->execute([$id]);
    flash('success', 'Kategori "' . $c['name'] . '" dihapus.');
    redirect('admin/categories.php');
}

switch ($action) {
    case 'save':   handle_save($pdo);   break;
    case 'toggle': handle_toggle($pdo); break;
    case 'delete': handle_delete($pdo); break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect('admin/categories.php');
}