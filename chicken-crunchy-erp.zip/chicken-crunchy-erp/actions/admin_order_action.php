<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_admin();

/** Error yang aman ditampilkan ke admin. */
class AdminOrderException extends RuntimeException
{
}

$pdo     = db();
$adminId = (int) current_user()['id'];
$action  = post_str('action', 20);
$orderId = post_int('order_id');
$back    = 'admin/order_detail.php?id=' . $orderId;

if ($orderId <= 0) {
    flash('danger', 'Pesanan tidak valid.');
    redirect('admin/orders.php');
}

/**
 * Jalankan $work di dalam transaksi. $work mengembalikan daftar notifikasi
 * [[tipe, pesan], ...]. Semua error dibatalkan (rollback) dan dilaporkan.
 */
function run_tx(PDO $pdo, callable $work, string $back, string $label): void
{
    $pdo->beginTransaction();
    try {
        $messages = $work($pdo);
        $pdo->commit();
    } catch (AdminOrderException | StockException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        flash('danger', $e->getMessage());
        redirect($back);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log($label . ': ' . $e->getMessage());
        flash('danger', 'Terjadi kesalahan. Silakan coba lagi.');
        redirect($back);
    }

    foreach ($messages as [$type, $text]) {
        flash($type, $text);
    }
    redirect($back);
}

/** Kunci baris pesanan. Semua keputusan status diambil dari data terkunci ini. */
function lock_order(PDO $pdo, int $orderId): array
{
    $st = $pdo->prepare('SELECT id, order_number, status, stock_deducted FROM orders WHERE id = ? FOR UPDATE');
    $st->execute([$orderId]);
    $o = $st->fetch();
    if (!$o) {
        throw new AdminOrderException('Pesanan tidak ditemukan.');
    }
    return $o;
}

/** Kunci baris pembayaran (selalu setelah mengunci pesanan, agar urutan kunci konsisten). */
function lock_payment(PDO $pdo, int $orderId): ?array
{
    $st = $pdo->prepare('SELECT id, status FROM payments WHERE order_id = ? FOR UPDATE');
    $st->execute([$orderId]);
    return $st->fetch() ?: null;
}

/** Kebutuhan stok pesanan: [product_id => jumlah], produk utama + varian, urut id. */
function order_stock_demand(PDO $pdo, int $orderId): array
{
    $demand = [];

    $st = $pdo->prepare('SELECT product_id, SUM(quantity) AS q FROM order_items WHERE order_id = ? GROUP BY product_id');
    $st->execute([$orderId]);
    foreach ($st->fetchAll() as $r) {
        $demand[(int) $r['product_id']] = ($demand[(int) $r['product_id']] ?? 0) + (int) $r['q'];
    }

    $st = $pdo->prepare(
        'SELECT oia.addon_product_id AS product_id, SUM(oi.quantity) AS q
         FROM order_item_addons oia
         JOIN order_items oi ON oi.id = oia.order_item_id
         WHERE oi.order_id = ?
         GROUP BY oia.addon_product_id'
    );
    $st->execute([$orderId]);
    foreach ($st->fetchAll() as $r) {
        $demand[(int) $r['product_id']] = ($demand[(int) $r['product_id']] ?? 0) + (int) $r['q'];
    }

    ksort($demand); // urutan kunci tetap, cegah deadlock
    return $demand;
}

/* =====================================================
   AKSI
   ===================================================== */

/** Pindah ke tahap berikutnya: pending > processing > ready > completed. */
function handle_advance(PDO $pdo, int $orderId, int $adminId, string $back): void
{
    $to = post_str('to', 12);

    run_tx($pdo, static function (PDO $pdo) use ($orderId, $adminId, $to): array {
        $o = lock_order($pdo, $orderId);

        $nextMap  = ['pending' => 'processing', 'processing' => 'ready', 'ready' => 'completed'];
        $expected = $nextMap[(string) $o['status']] ?? null;
        if ($expected === null || $expected !== $to) {
            throw new AdminOrderException('Status pesanan sudah berubah atau perpindahan tidak valid. Muat ulang halaman.');
        }

        $messages = [];

        if ($to === 'processing') {
            if ((int) $o['stock_deducted'] === 1) {
                throw new AdminOrderException('Stok pesanan ini sudah pernah dikurangi.');
            }
            foreach (order_stock_demand($pdo, $orderId) as $pid => $qty) {
                apply_stock_change(
                    $pdo, $pid, 'out', $qty, 'order', $orderId,
                    'Pesanan ' . $o['order_number'], $adminId
                );
            }
            $pdo->prepare("UPDATE orders SET status = 'processing', stock_deducted = 1 WHERE id = ?")->execute([$orderId]);
            $messages[] = ['success', 'Pesanan ' . $o['order_number'] . ' diproses. Stok produk dan varian sudah dikurangi.'];
        } elseif ($to === 'completed') {
            $pay = lock_payment($pdo, $orderId);
            if (!$pay || $pay['status'] !== 'paid') {
                throw new AdminOrderException('Verifikasi pembayaran dulu sebelum menyelesaikan pesanan.');
            }
            $pdo->prepare("UPDATE orders SET status = 'completed' WHERE id = ?")->execute([$orderId]);
            $messages[] = ['success', 'Pesanan ' . $o['order_number'] . ' selesai dan masuk laporan penjualan.'];
        } else {
            $pdo->prepare("UPDATE orders SET status = 'ready' WHERE id = ?")->execute([$orderId]);
            $messages[] = ['success', 'Pesanan ' . $o['order_number'] . ' ditandai siap.'];
        }

        return $messages;
    }, $back, 'Advance order error');
}

/** Verifikasi pembayaran lunas. */
function handle_mark_paid(PDO $pdo, int $orderId, string $back): void
{
    $note = post_str('note', 255);

    run_tx($pdo, static function (PDO $pdo) use ($orderId, $note): array {
        $o = lock_order($pdo, $orderId);
        if ($o['status'] === 'cancelled') {
            throw new AdminOrderException('Pesanan yang dibatalkan tidak dapat diverifikasi pembayarannya.');
        }
        $pay = lock_payment($pdo, $orderId);
        if (!$pay) {
            throw new AdminOrderException('Data pembayaran tidak ditemukan.');
        }
        if ($pay['status'] !== 'unpaid') {
            throw new AdminOrderException('Pembayaran ini sudah berstatus "' . payment_status_label((string) $pay['status']) . '".');
        }

        $pdo->prepare("UPDATE payments SET status = 'paid', paid_at = NOW(), note = ? WHERE id = ?")
            ->execute([$note !== '' ? $note : null, (int) $pay['id']]);

        return [['success', 'Pembayaran pesanan ' . $o['order_number'] . ' ditandai lunas.']];
    }, $back, 'Mark paid error');
}

/** Batalkan verifikasi (koreksi salah tandai). Tidak boleh setelah pesanan selesai. */
function handle_mark_unpaid(PDO $pdo, int $orderId, string $back): void
{
    run_tx($pdo, static function (PDO $pdo) use ($orderId): array {
        $o = lock_order($pdo, $orderId);
        if (in_array($o['status'], ['cancelled', 'completed'], true)) {
            throw new AdminOrderException('Pembayaran pesanan yang sudah selesai atau dibatalkan tidak dapat diubah.');
        }
        $pay = lock_payment($pdo, $orderId);
        if (!$pay || $pay['status'] !== 'paid') {
            throw new AdminOrderException('Pembayaran tidak berstatus lunas.');
        }

        $pdo->prepare("UPDATE payments SET status = 'unpaid', paid_at = NULL, note = 'Verifikasi dibatalkan admin' WHERE id = ?")
            ->execute([(int) $pay['id']]);

        return [['info', 'Verifikasi pembayaran pesanan ' . $o['order_number'] . ' dibatalkan.']];
    }, $back, 'Mark unpaid error');
}

/** Batalkan pesanan: kembalikan stok (sekali) dan perbarui status pembayaran. */
function handle_cancel(PDO $pdo, int $orderId, int $adminId, string $back): void
{
    $reason = post_str('reason', 255);
    if (mb_strlen($reason) < 3) {
        flash('danger', 'Alasan pembatalan wajib diisi (minimal 3 karakter).');
        redirect($back);
    }

    run_tx($pdo, static function (PDO $pdo) use ($orderId, $adminId, $reason): array {
        $o = lock_order($pdo, $orderId);
        if (!in_array($o['status'], ['pending', 'processing', 'ready'], true)) {
            throw new AdminOrderException('Pesanan dengan status ini tidak dapat dibatalkan.');
        }

        $messages = [];

        // Kembalikan stok hanya jika memang pernah dikurangi
        if ((int) $o['stock_deducted'] === 1) {
            foreach (order_stock_demand($pdo, $orderId) as $pid => $qty) {
                apply_stock_change(
                    $pdo, $pid, 'in', $qty, 'order_cancel', $orderId,
                    'Pembatalan ' . $o['order_number'], $adminId
                );
            }
        }

        $pdo->prepare("UPDATE orders SET status = 'cancelled', cancel_reason = ?, stock_deducted = 0 WHERE id = ?")
            ->execute([$reason, $orderId]);

        $refund = false;
        $pay = lock_payment($pdo, $orderId);
        if ($pay) {
            if ($pay['status'] === 'paid') {
                $pdo->prepare("UPDATE payments SET status = 'refunded', note = ? WHERE id = ?")
                    ->execute(['Pesanan dibatalkan; dana perlu dikembalikan ke pelanggan', (int) $pay['id']]);
                $refund = true;
            } elseif ($pay['status'] === 'unpaid') {
                $pdo->prepare("UPDATE payments SET status = 'failed', note = 'Pesanan dibatalkan' WHERE id = ?")
                    ->execute([(int) $pay['id']]);
            }
        }

        $messages[] = ['success', 'Pesanan ' . $o['order_number'] . ' dibatalkan.'
            . ((int) $o['stock_deducted'] === 1 ? ' Stok sudah dikembalikan.' : '')];
        if ($refund) {
            $messages[] = ['warning', 'Pesanan ini sudah dibayar. Kembalikan dana ke pelanggan secara manual.'];
        }
        return $messages;
    }, $back, 'Cancel order error');
}

switch ($action) {
    case 'advance':     handle_advance($pdo, $orderId, $adminId, $back);     break;
    case 'mark_paid':   handle_mark_paid($pdo, $orderId, $back);             break;
    case 'mark_unpaid': handle_mark_unpaid($pdo, $orderId, $back);           break;
    case 'cancel':      handle_cancel($pdo, $orderId, $adminId, $back);      break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect($back);
}