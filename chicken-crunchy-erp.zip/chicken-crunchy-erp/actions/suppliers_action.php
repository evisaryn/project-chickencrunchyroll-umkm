<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_admin();

$pdo    = db();
$action = post_str('action', 20);

function handle_save(PDO $pdo): void
{
    $id    = post_int('id');
    $input = [
        'name'    => post_str('name', 150),
        'phone'   => post_str('phone', 20),
        'address' => post_str('address', 500),
    ];
    $back = $id > 0 ? 'admin/suppliers.php?edit=' . $id : 'admin/suppliers.php';

    $errors = [];
    if (mb_strlen($input['name']) < 3) {
        $errors[] = 'Nama pemasok minimal 3 karakter.';
    }
    if ($input['phone'] !== '' && !valid_phone($input['phone'])) {
        $errors[] = 'Nomor telepon tidak valid.';
    }

    $st = $pdo->prepare('SELECT 1 FROM suppliers WHERE name = ? AND id <> ?');
    $st->execute([$input['name'], $id]);
    if ($st->fetchColumn()) {
        $errors[] = 'Nama pemasok sudah ada.';
    }

    if ($id > 0) {
        $st = $pdo->prepare('SELECT 1 FROM suppliers WHERE id = ?');
        $st->execute([$id]);
        if (!$st->fetchColumn()) {
            flash('danger', 'Pemasok tidak ditemukan.');
            redirect('admin/suppliers.php');
        }
    }

    if ($errors) {
        $_SESSION['supplier_old'] = $input;
        foreach ($errors as $err) {
            flash('danger', $err);
        }
        redirect($back);
    }

    $phone   = $input['phone'] !== '' ? $input['phone'] : null;
    $address = $input['address'] !== '' ? $input['address'] : null;

    if ($id > 0) {
        $pdo->prepare('UPDATE suppliers SET name = ?, phone = ?, address = ? WHERE id = ?')
            ->execute([$input['name'], $phone, $address, $id]);
        flash('success', 'Pemasok diperbarui.');
    } else {
        $pdo->prepare('INSERT INTO suppliers (name, phone, address) VALUES (?, ?, ?)')
            ->execute([$input['name'], $phone, $address]);
        flash('success', 'Pemasok "' . $input['name'] . '" ditambahkan.');
    }
    redirect('admin/suppliers.php');
}

function handle_toggle(PDO $pdo): void
{
    $id = post_int('id');
    $st = $pdo->prepare('SELECT name, is_active FROM suppliers WHERE id = ?');
    $st->execute([$id]);
    $s = $st->fetch();
    if (!$s) {
        flash('danger', 'Pemasok tidak ditemukan.');
        redirect('admin/suppliers.php');
    }
    $new = (int) $s['is_active'] === 1 ? 0 : 1;
    $pdo->prepare('UPDATE suppliers SET is_active = ? WHERE id = ?')->execute([$new, $id]);
    flash('success', 'Pemasok "' . $s['name'] . '" ' . ($new === 1 ? 'diaktifkan.' : 'dinonaktifkan.'));
    redirect('admin/suppliers.php');
}

function handle_delete(PDO $pdo): void
{
    $id = post_int('id');
    $st = $pdo->prepare('SELECT name FROM suppliers WHERE id = ?');
    $st->execute([$id]);
    $s = $st->fetch();
    if (!$s) {
        flash('danger', 'Pemasok tidak ditemukan.');
        redirect('admin/suppliers.php');
    }

    $st = $pdo->prepare('SELECT COUNT(*) FROM restocks WHERE supplier_id = ?');
    $st->execute([$id]);
    if ((int) $st->fetchColumn() > 0) {
        flash('warning', 'Pemasok sudah punya riwayat restock sehingga tidak bisa dihapus. Gunakan Nonaktifkan.');
        redirect('admin/suppliers.php');
    }

    $pdo->prepare('DELETE FROM suppliers WHERE id = ?')->execute([$id]);
    flash('success', 'Pemasok "' . $s['name'] . '" dihapus.');
    redirect('admin/suppliers.php');
}

switch ($action) {
    case 'save':   handle_save($pdo);   break;
    case 'toggle': handle_toggle($pdo); break;
    case 'delete': handle_delete($pdo); break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect('admin/suppliers.php');
}