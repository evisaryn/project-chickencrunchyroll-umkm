<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_admin();

$pdo     = db();
$adminId = (int) current_user()['id'];
$action  = post_str('action', 20);

/** Hapus file gambar produk dari disk (aman: hanya nama file). */
function delete_product_image(?string $file): void
{
    if (!$file) {
        return;
    }
    $path = UPLOAD_PATH . basename($file);
    if (is_file($path)) {
        @unlink($path);
    }
}

/** Simpan input lama + pesan error, lalu kembali ke form. */
function fail_save(array $input, array $errors, string $back): void
{
    $_SESSION['product_old'] = $input;
    foreach ($errors as $err) {
        flash('danger', $err);
    }
    redirect($back);
}

function handle_save(PDO $pdo, int $adminId): void
{
    $id     = post_int('id');
    $isEdit = $id > 0;
    $existing = null;

    if ($isEdit) {
        $st = $pdo->prepare('SELECT * FROM products WHERE id = ?');
        $st->execute([$id]);
        $existing = $st->fetch();
        if (!$existing) {
            flash('danger', 'Produk tidak ditemukan.');
            redirect('admin/products.php');
        }
    }

    $input = [
        'name'         => post_str('name', 150),
        'category_id'  => post_int('category_id'),
        'description'  => post_str('description', 1000),
        'price'        => post_rupiah('price'),
        'cost_price'   => post_rupiah('cost_price'),
        'min_stock'    => max(0, post_int('min_stock')),
        'stock'        => $isEdit ? (int) $existing['stock'] : max(0, post_int('stock')),
        // Tipe dan grup dikunci saat edit
        'product_type' => $isEdit ? (string) $existing['product_type'] : post_str('product_type', 10),
        'addon_group'  => $isEdit ? (string) ($existing['addon_group'] ?? '') : post_str('addon_group', 10),
        'is_active'    => isset($_POST['is_active']) ? 1 : 0,
    ];
    $back = $isEdit ? 'admin/products.php?edit=' . $id : 'admin/products.php?form=new';

    // ---- Validasi ----
    $errors = [];
    if (mb_strlen($input['name']) < 3) {
        $errors[] = 'Nama produk minimal 3 karakter.';
    }

    $st = $pdo->prepare('SELECT 1 FROM categories WHERE id = ?');
    $st->execute([$input['category_id']]);
    if (!$st->fetchColumn()) {
        $errors[] = 'Kategori tidak valid.';
    }

    if (!in_array($input['product_type'], ['main', 'addon'], true)) {
        $errors[] = 'Tipe produk tidak valid.';
    } elseif ($input['product_type'] === 'addon') {
        if (!in_array($input['addon_group'], ['sauce', 'powder', 'filling'], true)) {
            $errors[] = 'Grup varian wajib dipilih.';
        }
    } else {
        $input['addon_group'] = '';
        if ($input['price'] <= 0) {
            $errors[] = 'Harga produk utama harus lebih dari 0.';
        }
    }
    if ($input['min_stock'] > 100000 || $input['stock'] > 1000000) {
        $errors[] = 'Nilai stok terlalu besar.';
    }

    // ---- Upload gambar (opsional) ----
    $newImage = null;
    if (!$errors) {
        $file = $_FILES['image'] ?? null;
        if (is_array($file) && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            try {
                $newImage = save_uploaded_image($file);
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
    if ($errors) {
        fail_save($input, $errors, $back);
    }

    // ---- Simpan ----
    $pdo->beginTransaction();
    try {
        if ($isEdit) {
            $pdo->prepare(
                'UPDATE products
                 SET category_id = ?, name = ?, description = ?, image = ?,
                     price = ?, cost_price = ?, min_stock = ?, is_active = ?
                 WHERE id = ?'
            )->execute([
                $input['category_id'], $input['name'],
                $input['description'] !== '' ? $input['description'] : null,
                $newImage ?? $existing['image'],
                $input['price'], $input['cost_price'], $input['min_stock'], $input['is_active'], $id,
            ]);
        } else {
            $pdo->prepare(
                'INSERT INTO products
                   (category_id, name, description, image, price, cost_price, stock, min_stock,
                    product_type, addon_group, is_active)
                 VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)'
            )->execute([
                $input['category_id'], $input['name'],
                $input['description'] !== '' ? $input['description'] : null,
                $newImage, $input['price'], $input['cost_price'], $input['min_stock'],
                $input['product_type'],
                $input['addon_group'] !== '' ? $input['addon_group'] : null,
                $input['is_active'],
            ]);
            $newId = (int) $pdo->lastInsertId();

            if ($input['stock'] > 0) {
                apply_stock_change($pdo, $newId, 'in', $input['stock'], 'manual', null, 'Stok awal produk', $adminId);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        delete_product_image($newImage);
        error_log('Save product error: ' . $e->getMessage());
        fail_save($input, ['Gagal menyimpan produk. Silakan coba lagi.'], $back);
    }

    // Gambar lama dihapus setelah penyimpanan berhasil
    if ($isEdit && $newImage !== null) {
        delete_product_image($existing['image']);
    }

    flash('success', 'Produk "' . $input['name'] . '" berhasil disimpan.');
    redirect('admin/products.php');
}

function handle_toggle(PDO $pdo): void
{
    $id = post_int('id');
    $st = $pdo->prepare('SELECT name, is_active FROM products WHERE id = ?');
    $st->execute([$id]);
    $p = $st->fetch();
    if (!$p) {
        flash('danger', 'Produk tidak ditemukan.');
        redirect('admin/products.php');
    }

    $new = (int) $p['is_active'] === 1 ? 0 : 1;
    $pdo->prepare('UPDATE products SET is_active = ? WHERE id = ?')->execute([$new, $id]);
    flash('success', '"' . $p['name'] . '" ' . ($new === 1 ? 'diaktifkan.' : 'dinonaktifkan dan disembunyikan dari website.'));
    redirect('admin/products.php');
}

function handle_delete(PDO $pdo): void
{
    $id = post_int('id');
    $st = $pdo->prepare('SELECT name, image FROM products WHERE id = ?');
    $st->execute([$id]);
    $p = $st->fetch();
    if (!$p) {
        flash('danger', 'Produk tidak ditemukan.');
        redirect('admin/products.php');
    }

    // Jangan hapus jika sudah punya jejak transaksi
    $st = $pdo->prepare(
        'SELECT (SELECT COUNT(*) FROM order_items WHERE product_id = ?)
              + (SELECT COUNT(*) FROM order_item_addons WHERE addon_product_id = ?)
              + (SELECT COUNT(*) FROM restock_items WHERE product_id = ?)'
    );
    $st->execute([$id, $id, $id]);
    if ((int) $st->fetchColumn() > 0) {
        flash('warning', '"' . $p['name'] . '" sudah punya riwayat pesanan/restock sehingga tidak bisa dihapus. Gunakan Nonaktifkan.');
        redirect('admin/products.php');
    }

    try {
        $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
    } catch (PDOException $e) {
        error_log('Delete product error: ' . $e->getMessage());
        flash('danger', 'Produk tidak dapat dihapus. Gunakan Nonaktifkan.');
        redirect('admin/products.php');
    }

    delete_product_image($p['image']);
    flash('success', 'Produk "' . $p['name'] . '" dihapus.');
    redirect('admin/products.php');
}

switch ($action) {
    case 'save':   handle_save($pdo, $adminId); break;
    case 'toggle': handle_toggle($pdo);         break;
    case 'delete': handle_delete($pdo);         break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect('admin/products.php');
}