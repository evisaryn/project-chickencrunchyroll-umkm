<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_post();
csrf_verify();
require_admin();

$pdo    = db();
$me     = current_user();
$action = post_str('action', 20);

function handle_toggle(PDO $pdo, array $me): void
{
    $tab  = post_str('tab', 10) === 'admins' ? 'admins' : 'customers';
    $back = 'admin/customers.php' . ($tab === 'admins' ? '?tab=admins' : '');
    $id   = post_int('id');

    $st = $pdo->prepare('SELECT id, name, role, is_active FROM users WHERE id = ?');
    $st->execute([$id]);
    $u = $st->fetch();

    if (!$u) {
        flash('danger', 'Akun tidak ditemukan.');
        redirect($back);
    }
    if ((int) $u['id'] === (int) $me['id']) {
        flash('danger', 'Anda tidak dapat menonaktifkan akun sendiri.');
        redirect($back);
    }
    if ($u['role'] === 'superadmin') {
        flash('danger', 'Akun superadmin tidak dapat dinonaktifkan dari sini.');
        redirect($back);
    }
    if ($u['role'] === 'admin' && $me['role'] !== 'superadmin') {
        flash('danger', 'Hanya superadmin yang dapat mengelola akun admin.');
        redirect($back);
    }

    $new = (int) $u['is_active'] === 1 ? 0 : 1;
    $pdo->prepare('UPDATE users SET is_active = ? WHERE id = ?')->execute([$new, $id]);
    flash('success', 'Akun ' . $u['name'] . ($new === 1 ? ' diaktifkan.' : ' dinonaktifkan.'));
    redirect($back);
}

function handle_create_admin(PDO $pdo): void
{
    require_superadmin(); // hanya superadmin yang boleh membuat admin

    $back  = 'admin/customers.php?tab=admins';
    $name  = post_str('name', 100);
    $email = mb_strtolower(post_str('email', 150));
    $pass1 = (string) ($_POST['password'] ?? '');
    $pass2 = (string) ($_POST['password_confirm'] ?? '');

    $errors = [];
    if (mb_strlen($name) < 3)                       { $errors[] = 'Nama minimal 3 karakter.'; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Email tidak valid.'; }
    if (strlen($pass1) < 10)                        { $errors[] = 'Password minimal 10 karakter.'; }
    elseif (!preg_match('/[A-Za-z]/', $pass1) || !preg_match('/[0-9]/', $pass1)) {
        $errors[] = 'Password harus mengandung huruf dan angka.';
    }
    if ($pass1 !== $pass2)                          { $errors[] = 'Konfirmasi password tidak sama.'; }

    if (!$errors) {
        try {
            $pdo->prepare(
                "INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, NULL, ?, 'admin')"
            )->execute([$name, $email, password_hash($pass1, PASSWORD_DEFAULT)]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $errors[] = 'Email sudah terdaftar.';
            } else {
                error_log('Create admin error: ' . $e->getMessage());
                $errors[] = 'Gagal membuat akun. Silakan coba lagi.';
            }
        }
    }

    if ($errors) {
        $_SESSION['admin_old'] = ['name' => $name, 'email' => $email];
        foreach ($errors as $err) {
            flash('danger', $err);
        }
        redirect($back);
    }

    flash('success', 'Akun admin untuk ' . $email . ' dibuat. Sampaikan password melalui jalur aman.');
    redirect($back);
}

switch ($action) {
    case 'toggle':       handle_toggle($pdo, $me); break;
    case 'create_admin': handle_create_admin($pdo); break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect('admin/customers.php');
}