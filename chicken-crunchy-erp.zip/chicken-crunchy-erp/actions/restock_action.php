<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_admin();

const MAX_RESTOCK_ITEMS = 30;
const MAX_RESTOCK_TOTAL = 9000000000.0; // batas aman kolom DECIMAL(12,2)

$pdo     = db();
$adminId = (int) current_user()['id'];

if (post_str('action', 10) !== 'create') {
    flash('danger', 'Aksi tidak dikenal.');
    redirect('admin/restocks.php');
}

/** Simpan input lama, tampilkan error, kembali ke form. */
function restock_fail(array $old, array $errors): void
{
    $_SESSION['restock_old'] = $old;
    foreach ($errors as $err) {
        flash('danger', $err);
    }
    redirect('admin/restocks.php?form=new');
}

/** Ubah input menjadi rupiah bulat (hanya digit). */
function digits_money($v): float
{
    if (!is_scalar($v)) {
        return 0.0;
    }
    $d = (string) preg_replace('/[^0-9]/', '', (string) $v);
    return $d === '' ? 0.0 : (float) min((int) substr($d, 0, 9), 999999999);
}

function scalar_str($v): string
{
    return is_scalar($v) ? trim((string) $v) : '';
}

/* ---------- Baca input ---------- */
$supplierId = post_int('supplier_id');
$date       = post_str('restock_date', 10);
$notes      = post_str('notes', 255);
$updateCost = isset($_POST['update_cost']);

$pids  = is_array($_POST['product_id'] ?? null) ? array_values($_POST['product_id']) : [];
$qtys  = is_array($_POST['quantity'] ?? null)   ? array_values($_POST['quantity'])   : [];
$costs = is_array($_POST['unit_cost'] ?? null)  ? array_values($_POST['unit_cost'])  : [];

$errors  = [];
$oldRows = [];
$rows    = [];

if (count($pids) > MAX_RESTOCK_ITEMS) {
    $errors[] = 'Maksimal ' . MAX_RESTOCK_ITEMS . ' barang per restock.';
}

$count = min(count($pids), MAX_RESTOCK_ITEMS);
for ($i = 0; $i < $count; $i++) {
    $pidS  = scalar_str($pids[$i] ?? '');
    $qtyS  = scalar_str($qtys[$i] ?? '');
    $costS = scalar_str($costs[$i] ?? '');
    $oldRows[] = ['product_id' => $pidS, 'quantity' => $qtyS, 'unit_cost' => $costS];

    if ($pidS === '' && $qtyS === '' && $costS === '') {
        continue; // baris kosong diabaikan
    }

    $line = $i + 1;
    $pid  = filter_var($pidS, FILTER_VALIDATE_INT);
    $qty  = filter_var($qtyS, FILTER_VALIDATE_INT);
    $cost = digits_money($costS);

    if ($pid === false || $pid <= 0) {
        $errors[] = "Baris $line: pilih barang.";
        continue;
    }
    if ($qty === false || $qty < 1 || $qty > 100000) {
        $errors[] = "Baris $line: jumlah harus 1 sampai 100.000.";
        continue;
    }
    if ($cost <= 0) {
        $errors[] = "Baris $line: harga beli harus lebih dari 0.";
        continue;
    }
    $rows[] = ['product_id' => (int) $pid, 'quantity' => (int) $qty, 'unit_cost' => $cost, 'line' => $line];
}

$old = [
    'supplier_id' => (string) $supplierId, 'restock_date' => $date, 'notes' => $notes,
    'update_cost' => $updateCost, 'rows' => $oldRows ?: [['product_id' => '', 'quantity' => '', 'unit_cost' => '']],
];

/* ---------- Validasi ---------- */
if (!$rows && !$errors) {
    $errors[] = 'Tambahkan minimal satu barang.';
}
if (!valid_date_ymd($date) || $date > date('Y-m-d')) {
    $errors[] = 'Tanggal tidak valid atau melebihi hari ini.';
}

// Tidak boleh ada barang kembar dalam satu restock
$seen = [];
foreach ($rows as $r) {
    if (isset($seen[$r['product_id']])) {
        $errors[] = 'Baris ' . $r['line'] . ': barang sudah ada di baris lain. Gabungkan jumlahnya.';
    }
    $seen[$r['product_id']] = true;
}

// Pemasok (opsional, harus aktif)
$supplierName = null;
if ($supplierId > 0) {
    $st = $pdo->prepare('SELECT name FROM suppliers WHERE id = ? AND is_active = 1');
    $st->execute([$supplierId]);
    $supplierName = $st->fetchColumn();
    if ($supplierName === false) {
        $errors[] = 'Pemasok tidak valid atau tidak aktif.';
        $supplierName = null;
    }
}

// Semua barang harus ada
if ($rows && !$errors) {
    $ids = array_keys($seen);
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $st  = $pdo->prepare("SELECT COUNT(*) FROM products WHERE id IN ($in)");
    $st->execute($ids);
    if ((int) $st->fetchColumn() !== count($ids)) {
        $errors[] = 'Ada barang yang tidak ditemukan.';
    }
}

// Total
$total = 0.0;
foreach ($rows as &$r) {
    $r['subtotal'] = round($r['quantity'] * $r['unit_cost'], 2);
    $total += $r['subtotal'];
}
unset($r);
$total = round($total, 2);
if ($total > MAX_RESTOCK_TOTAL) {
    $errors[] = 'Total pembelian terlalu besar.';
}

if ($errors) {
    restock_fail($old, $errors);
}

/* ---------- Simpan dalam satu transaksi ---------- */
usort($rows, static fn ($a, $b) => $a['product_id'] <=> $b['product_id']); // urutan kunci tetap, cegah deadlock

$pdo->beginTransaction();
try {
    $pdo->prepare(
        'INSERT INTO restocks (supplier_id, restock_date, total_cost, notes, created_by)
         VALUES (?, ?, ?, ?, ?)'
    )->execute([
        $supplierId > 0 ? $supplierId : null,
        $date, $total,
        $notes !== '' ? $notes : null,
        $adminId,
    ]);
    $restockId = (int) $pdo->lastInsertId();

    $insItem = $pdo->prepare(
        'INSERT INTO restock_items (restock_id, product_id, quantity, unit_cost, subtotal) VALUES (?, ?, ?, ?, ?)'
    );
    $updCost = $pdo->prepare('UPDATE products SET cost_price = ? WHERE id = ?');
    $stockNote = 'Restock #' . $restockId . ($supplierName !== null ? ' - ' . $supplierName : '');

    foreach ($rows as $r) {
        $insItem->execute([$restockId, $r['product_id'], $r['quantity'], $r['unit_cost'], $r['subtotal']]);
        apply_stock_change($pdo, $r['product_id'], 'in', $r['quantity'], 'restock', $restockId, $stockNote, $adminId);
        if ($updateCost) {
            $updCost->execute([$r['unit_cost'], $r['product_id']]);
        }
    }

    $pdo->commit();
} catch (StockException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    restock_fail($old, [$e->getMessage()]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Restock error: ' . $e->getMessage());
    restock_fail($old, ['Restock gagal disimpan. Silakan coba lagi.']);
}

flash('success', 'Restock #' . $restockId . ' tersimpan: ' . count($rows) . ' barang masuk, total ' . rupiah($total) . '.');
redirect('admin/restocks.php?view=' . $restockId);