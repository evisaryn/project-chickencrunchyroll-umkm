<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_admin();

$pdo     = db();
$adminId = (int) current_user()['id'];

$productId = post_int('product_id');
$type      = post_str('movement_type', 3);
$qty       = post_int('quantity');
$notes     = post_str('notes', 255);

$errors = [];
if ($productId <= 0)                          { $errors[] = 'Pilih barang terlebih dahulu.'; }
if (!in_array($type, ['in', 'out'], true))    { $errors[] = 'Jenis perubahan stok tidak valid.'; }
if ($qty < 1 || $qty > 100000)                { $errors[] = 'Jumlah harus antara 1 dan 100.000.'; }
if ($type === 'out' && $notes === '')         { $errors[] = 'Alasan wajib diisi untuk barang keluar.'; }

if ($errors) {
    foreach ($errors as $err) {
        flash('danger', $err);
    }
    redirect('admin/inventory.php' . ($productId > 0 ? '?product=' . $productId . '#adjust' : ''));
}

$pdo->beginTransaction();
try {
    $r = apply_stock_change(
        $pdo, $productId, $type, $qty, 'manual', null,
        $notes !== '' ? $notes : 'Penyesuaian manual', $adminId
    );
    $pdo->commit();
} catch (StockException $e) {
    $pdo->rollBack();
    flash('danger', $e->getMessage());
    redirect('admin/inventory.php?product=' . $productId . '#adjust');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Stock adjust error: ' . $e->getMessage());
    flash('danger', 'Gagal menyimpan perubahan stok. Silakan coba lagi.');
    redirect('admin/inventory.php?product=' . $productId . '#adjust');
}

flash('success', 'Stok ' . $r['name'] . ' diperbarui: ' . $r['before'] . ' → ' . $r['after'] . '.');
redirect('admin/inventory.php?hp=' . $productId . '#history');