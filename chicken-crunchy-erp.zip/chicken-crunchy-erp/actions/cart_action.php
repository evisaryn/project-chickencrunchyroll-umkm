<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/cart.php';

require_post();
csrf_verify();
require_login();

$pdo    = db();
$userId = (int) current_user()['id'];
$action = post_str('action', 20);

/** Halaman tujuan setelah aksi (whitelist, cegah open redirect). */
function return_target(): string
{
    $r = post_str('return_to', 40);
    return in_array($r, ['user/menu.php', 'user/cart.php'], true) ? $r : 'user/cart.php';
}

function respond(string $type, string $message): void
{
    flash($type, $message);
    redirect(return_target());
}

/** Tambah produk (dengan add-on pilihan) ke keranjang. */
function handle_add(PDO $pdo, int $userId): void
{
    $productId = post_int('product_id');
    $qty       = max(1, min(MAX_QTY_PER_LINE, post_int('quantity', 1)));

    $st = $pdo->prepare(
        "SELECT id, name, stock FROM products
         WHERE id = ? AND product_type = 'main' AND is_active = 1"
    );
    $st->execute([$productId]);
    $main = $st->fetch();
    if (!$main) {
        respond('danger', 'Produk tidak ditemukan atau sudah tidak dijual.');
    }

    // Kumpulkan pilihan add-on: sauce[] (banyak), powder dan filling (satu)
    $raw   = [];
    $sauce = $_POST['sauce'] ?? [];
    foreach ((is_array($sauce) ? $sauce : [$sauce]) as $v) {
        if ($v !== '') {
            $raw[] = $v;
        }
    }
    foreach (['powder', 'filling'] as $field) {
        $v = $_POST[$field] ?? '';
        if ($v !== '') {
            $raw[] = $v;
        }
    }

    $addonIds = [];
    foreach ($raw as $v) {
        if (!is_scalar($v) || filter_var($v, FILTER_VALIDATE_INT) === false) {
            respond('danger', 'Pilihan varian tidak valid.');
        }
        $addonIds[(int) $v] = (int) $v;
    }
    $addonIds = array_values($addonIds);
    sort($addonIds);

    // Validasi add-on ke database: harus aktif, bertipe addon, dan sesuai batas grup
    $addons = [];
    if ($addonIds) {
        $in = implode(',', array_fill(0, count($addonIds), '?'));
        $st = $pdo->prepare(
            "SELECT id, name, stock, addon_group FROM products
             WHERE id IN ($in) AND product_type = 'addon' AND is_active = 1"
        );
        $st->execute($addonIds);
        $addons = $st->fetchAll();

        if (count($addons) !== count($addonIds)) {
            respond('danger', 'Ada pilihan varian yang tidak valid atau sudah tidak tersedia.');
        }

        $perGroup = [];
        foreach ($addons as $a) {
            $g = (string) $a['addon_group'];
            if (!array_key_exists($g, ADDON_LIMITS)) {
                respond('danger', 'Pilihan varian tidak valid.');
            }
            $perGroup[$g] = ($perGroup[$g] ?? 0) + 1;
            if ($perGroup[$g] > ADDON_LIMITS[$g]) {
                respond('danger', 'Pilihan ' . addon_group_label($g) . ' maksimal ' . ADDON_LIMITS[$g] . '.');
            }
        }
    }

    // Validasi stok di server (termasuk yang sudah ada di keranjang)
    $demand = cart_demand(cart_lines($userId));
    $items  = [['id' => (int) $main['id'], 'name' => (string) $main['name'], 'stock' => (int) $main['stock'], 'active' => true]];
    foreach ($addons as $a) {
        $items[] = ['id' => (int) $a['id'], 'name' => (string) $a['name'], 'stock' => (int) $a['stock'], 'active' => true];
    }
    $err = cart_stock_error($items, $demand, $qty);
    if ($err !== null) {
        respond('danger', $err);
    }

    // Simpan. Kombinasi produk + add-on yang sama digabung jadi satu baris.
    $key = $addonIds ? md5(implode(',', $addonIds)) : '';

    $pdo->beginTransaction();
    try {
        $cartId = get_or_create_cart_id($userId);

        $st = $pdo->prepare(
            'SELECT id, quantity FROM cart_items
             WHERE cart_id = ? AND product_id = ? AND addon_key = ? FOR UPDATE'
        );
        $st->execute([$cartId, (int) $main['id'], $key]);
        $existing = $st->fetch();

        if ($existing) {
            $newQty = min(MAX_QTY_PER_LINE, (int) $existing['quantity'] + $qty);
            $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE id = ?')
                ->execute([$newQty, (int) $existing['id']]);
        } else {
            $pdo->prepare(
                'INSERT INTO cart_items (cart_id, product_id, quantity, addon_key) VALUES (?, ?, ?, ?)'
            )->execute([$cartId, (int) $main['id'], $qty, $key]);
            $itemId = (int) $pdo->lastInsertId();

            $ins = $pdo->prepare(
                'INSERT INTO cart_item_addons (cart_item_id, addon_product_id) VALUES (?, ?)'
            );
            foreach ($addonIds as $aid) {
                $ins->execute([$itemId, $aid]);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Cart add error: ' . $e->getMessage());
        respond('danger', 'Gagal menambahkan ke keranjang. Silakan coba lagi.');
    }

    respond('success', $main['name'] . ' ditambahkan ke keranjang.');
}

/** Tambah (inc) atau kurangi (dec) jumlah satu baris. */
function handle_update(PDO $pdo, int $userId): void
{
    $itemId = post_int('item_id');
    $op     = post_str('op', 5);

    $lines = cart_lines($userId); // hanya baris milik user ini
    if (!isset($lines[$itemId])) {
        respond('danger', 'Item keranjang tidak ditemukan.');
    }
    $line = $lines[$itemId];

    if ($op === 'dec') {
        if ($line['quantity'] <= 1) {
            $pdo->prepare('DELETE FROM cart_items WHERE id = ?')->execute([$itemId]);
            respond('info', $line['name'] . ' dihapus dari keranjang.');
        }
        $pdo->prepare('UPDATE cart_items SET quantity = quantity - 1 WHERE id = ?')->execute([$itemId]);
        redirect(return_target());
    }

    if ($op === 'inc') {
        if ($line['quantity'] >= MAX_QTY_PER_LINE) {
            respond('warning', 'Jumlah maksimal per item adalah ' . MAX_QTY_PER_LINE . '.');
        }
        $err = cart_stock_error(cart_line_stock_items($line), cart_demand($lines), 1);
        if ($err !== null) {
            respond('danger', $err);
        }
        $pdo->prepare('UPDATE cart_items SET quantity = quantity + 1 WHERE id = ?')->execute([$itemId]);
        redirect(return_target());
    }

    respond('danger', 'Perintah tidak dikenal.');
}

/** Hapus satu baris. */
function handle_remove(PDO $pdo, int $userId): void
{
    $itemId = post_int('item_id');
    $lines  = cart_lines($userId);
    if (!isset($lines[$itemId])) {
        respond('danger', 'Item keranjang tidak ditemukan.');
    }
    $pdo->prepare('DELETE FROM cart_items WHERE id = ?')->execute([$itemId]);
    respond('info', $lines[$itemId]['name'] . ' dihapus dari keranjang.');
}

/** Kosongkan keranjang. */
function handle_clear(PDO $pdo, int $userId): void
{
    $pdo->prepare(
        'DELETE ci FROM cart_items ci JOIN carts c ON c.id = ci.cart_id WHERE c.user_id = ?'
    )->execute([$userId]);
    respond('info', 'Keranjang dikosongkan.');
}

switch ($action) {
    case 'add':    handle_add($pdo, $userId);    break;
    case 'update': handle_update($pdo, $userId); break;
    case 'remove': handle_remove($pdo, $userId); break;
    case 'clear':  handle_clear($pdo, $userId);  break;
    default:       respond('danger', 'Aksi tidak dikenal.');
}