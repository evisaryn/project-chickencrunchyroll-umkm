<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/cart.php';

require_post();
csrf_verify();
require_login();

/** Error yang aman ditampilkan ke pelanggan. */
class OrderException extends RuntimeException
{
}

$pdo    = db();
$userId = (int) current_user()['id'];
$action = post_str('action', 20);

/** Buat pesanan dari keranjang. Semua langkah dalam satu transaksi. */
function handle_place(PDO $pdo, int $userId): void
{
    $old = [
        'name'           => post_str('customer_name', 100),
        'phone'          => post_str('customer_phone', 20),
        'payment_method' => post_str('payment_method', 10),
        'notes'          => post_str('notes', 255),
    ];

    // ---- Validasi input ----
    $errors = [];
    if (mb_strlen($old['name']) < 3) {
        $errors[] = 'Nama minimal 3 karakter.';
    }
    if (!valid_phone($old['phone'])) {
        $errors[] = 'Nomor telepon tidak valid.';
    }
    if (!in_array($old['payment_method'], ['cash', 'transfer', 'qris'], true)) {
        $errors[] = 'Metode pembayaran tidak valid.';
    } elseif ($old['payment_method'] === 'qris' && qris_image_url() === null) {
        $errors[] = 'QRIS belum tersedia. Pilih metode pembayaran lain.';
    }
    if ($errors) {
        $_SESSION['checkout_old'] = $old;
        foreach ($errors as $err) {
            flash('danger', $err);
        }
        redirect('user/checkout.php');
    }

    // ---- Ambil isi keranjang ----
    $lines = cart_lines($userId);
    if (!$lines) {
        flash('warning', 'Keranjang masih kosong.');
        redirect('user/menu.php');
    }

    $ids = [];
    foreach ($lines as $l) {
        $ids[$l['product_id']] = true;
        foreach ($l['addons'] as $a) {
            $ids[$a['id']] = true;
        }
    }
    $ids = array_keys($ids);
    sort($ids); // urutan tetap, mencegah deadlock antar transaksi

    $pdo->beginTransaction();
    try {
        // ---- Kunci baris produk, lalu baca data TERBARU (harga, modal, stok) ----
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $pdo->prepare(
            "SELECT id, name, price, cost_price, stock, is_active, product_type, addon_group
             FROM products WHERE id IN ($in) ORDER BY id FOR UPDATE"
        );
        $st->execute($ids);
        $locked = [];
        foreach ($st->fetchAll() as $r) {
            $locked[(int) $r['id']] = $r;
        }

        // ---- Susun baris pesanan dari data terkunci ----
        $demand     = [];
        $orderLines = [];
        $subtotal   = 0.0;
        $totalCost  = 0.0;

        foreach ($lines as $l) {
            $main = $locked[$l['product_id']] ?? null;
            if (!$main || (int) $main['is_active'] !== 1 || $main['product_type'] !== 'main') {
                throw new OrderException($l['name'] . ' sudah tidak tersedia. Hapus dari keranjang.');
            }

            $qty        = (int) $l['quantity'];
            $unitPrice  = (float) $main['price'];
            $unitCost   = (float) $main['cost_price'];
            $demand[(int) $main['id']] = ($demand[(int) $main['id']] ?? 0) + $qty;

            $addonRows  = [];
            $addonTotal = 0.0;
            $addonCost  = 0.0;
            foreach ($l['addons'] as $a) {
                $ad = $locked[$a['id']] ?? null;
                if (!$ad || (int) $ad['is_active'] !== 1 || $ad['product_type'] !== 'addon') {
                    throw new OrderException((string) $a['name'] . ' sudah tidak tersedia. Hapus item dari keranjang.');
                }
                $addonRows[]  = $ad;
                $addonTotal  += (float) $ad['price'];
                $addonCost   += (float) $ad['cost_price'];
                $demand[(int) $ad['id']] = ($demand[(int) $ad['id']] ?? 0) + $qty;
            }

            $lineTotal   = round(($unitPrice + $addonTotal) * $qty, 2);
            $subtotal   += $lineTotal;
            $totalCost  += ($unitCost + $addonCost) * $qty;

            $orderLines[] = [
                'product_id'  => (int) $main['id'],
                'name'        => (string) $main['name'],
                'unit_price'  => $unitPrice,
                'unit_cost'   => $unitCost,
                'addon_total' => round($addonTotal, 2),
                'addon_cost'  => round($addonCost, 2),
                'quantity'    => $qty,
                'line_total'  => $lineTotal,
                'addons'      => $addonRows,
            ];
        }

        // ---- Validasi stok di server (total kebutuhan semua baris) ----
        foreach ($demand as $pid => $need) {
            $have = (int) $locked[$pid]['stock'];
            if ($need > $have) {
                throw new OrderException(
                    'Stok ' . $locked[$pid]['name'] . ' tidak mencukupi (tersisa ' . $have . ', dipesan ' . $need . ').'
                );
            }
        }

        $subtotal  = round($subtotal, 2);
        $totalCost = round($totalCost, 2);
        $total     = $subtotal; // tanpa ongkir: semua pesanan diambil di toko

        // ---- Nomor antrean hari ini (aman dari duplikat) ----
        $queueDate = date('Y-m-d');
        $queueNo   = next_queue_number($pdo, $queueDate);

        // ---- Nomor pesanan unik ----
        $chk = $pdo->prepare('SELECT 1 FROM orders WHERE order_number = ?');
        do {
            $orderNumber = generate_order_number();
            $chk->execute([$orderNumber]);
        } while ($chk->fetchColumn());

        // ---- Simpan pesanan (selalu pickup, tanpa alamat dan ongkir) ----
        $pdo->prepare(
            "INSERT INTO orders
               (order_number, queue_date, queue_number, user_id, customer_name, customer_phone, address,
                fulfillment, payment_method, status, subtotal, delivery_fee, total, total_cost, stock_deducted, notes)
             VALUES (?, ?, ?, ?, ?, ?, NULL, 'pickup', ?, 'pending', ?, 0, ?, ?, 0, ?)"
        )->execute([
            $orderNumber, $queueDate, $queueNo, $userId, $old['name'], $old['phone'],
            $old['payment_method'],
            $subtotal, $total, $totalCost,
            $old['notes'] !== '' ? $old['notes'] : null,
        ]);
        $orderId = (int) $pdo->lastInsertId();

        $insItem = $pdo->prepare(
            'INSERT INTO order_items
               (order_id, product_id, product_name, unit_price, unit_cost, addon_total, addon_cost, quantity, line_total)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $insAddon = $pdo->prepare(
            'INSERT INTO order_item_addons
               (order_item_id, addon_product_id, addon_name, addon_group, price, cost)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        foreach ($orderLines as $ol) {
            $insItem->execute([
                $orderId, $ol['product_id'], $ol['name'], $ol['unit_price'], $ol['unit_cost'],
                $ol['addon_total'], $ol['addon_cost'], $ol['quantity'], $ol['line_total'],
            ]);
            $itemId = (int) $pdo->lastInsertId();
            foreach ($ol['addons'] as $ad) {
                $insAddon->execute([
                    $itemId, (int) $ad['id'], (string) $ad['name'], (string) $ad['addon_group'],
                    (float) $ad['price'], (float) $ad['cost_price'],
                ]);
            }
        }

        // ---- Data pembayaran: selalu "unpaid" sampai admin memverifikasi ----
        $pdo->prepare(
            "INSERT INTO payments (order_id, method, amount, status) VALUES (?, ?, ?, 'unpaid')"
        )->execute([$orderId, $old['payment_method'], $total]);

        // ---- Kosongkan hanya item keranjang yang baru dipesan ----
        $lineIds = array_keys($lines);
        $inLines = implode(',', array_fill(0, count($lineIds), '?'));
        $pdo->prepare("DELETE FROM cart_items WHERE id IN ($inLines)")->execute($lineIds);

        $pdo->commit();
    } catch (OrderException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['checkout_old'] = $old;
        flash('danger', $e->getMessage());
        redirect('user/cart.php');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Place order error: ' . $e->getMessage());
        $_SESSION['checkout_old'] = $old;
        flash('danger', 'Pesanan gagal dibuat. Silakan coba lagi.');
        redirect('user/checkout.php');
    }

    flash('success', 'Pesanan ' . $orderNumber . ' berhasil dibuat. Nomor antrean Anda: ' . queue_label($queueNo) . '.');
    redirect('user/order_detail.php?id=' . $orderId);
}

/** Pelanggan membatalkan pesanannya sendiri (hanya pending dan belum dibayar). */
function handle_cancel(PDO $pdo, int $userId): void
{
    $orderId = post_int('order_id');

    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare(
            'SELECT o.id, o.order_number, o.status, o.stock_deducted, p.status AS pay_status
             FROM orders o
             LEFT JOIN payments p ON p.order_id = o.id
             WHERE o.id = ? AND o.user_id = ?
             FOR UPDATE'
        );
        $st->execute([$orderId, $userId]);
        $o = $st->fetch();

        if (!$o) {
            throw new OrderException('Pesanan tidak ditemukan.');
        }
        if ($o['status'] !== 'pending' || (int) $o['stock_deducted'] === 1) {
            throw new OrderException('Pesanan yang sudah diproses tidak dapat dibatalkan sendiri. Hubungi kami.');
        }
        if ($o['pay_status'] === 'paid') {
            throw new OrderException('Pesanan sudah dibayar. Hubungi kami untuk pembatalan dan pengembalian dana.');
        }

        $pdo->prepare(
            "UPDATE orders SET status = 'cancelled', cancel_reason = 'Dibatalkan oleh pelanggan' WHERE id = ?"
        )->execute([$orderId]);
        $pdo->prepare(
            "UPDATE payments SET status = 'failed', note = 'Pesanan dibatalkan' WHERE order_id = ? AND status = 'unpaid'"
        )->execute([$orderId]);

        $pdo->commit();
    } catch (OrderException $e) {
        $pdo->rollBack();
        flash('danger', $e->getMessage());
        redirect('user/orders.php');
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('Cancel order error: ' . $e->getMessage());
        flash('danger', 'Gagal membatalkan pesanan. Silakan coba lagi.');
        redirect('user/order_detail.php?id=' . $orderId);
    }

    flash('info', 'Pesanan ' . $o['order_number'] . ' dibatalkan.');
    redirect('user/order_detail.php?id=' . $orderId);
}

switch ($action) {
    case 'place':  handle_place($pdo, $userId);  break;
    case 'cancel': handle_cancel($pdo, $userId); break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect('user/orders.php');
}