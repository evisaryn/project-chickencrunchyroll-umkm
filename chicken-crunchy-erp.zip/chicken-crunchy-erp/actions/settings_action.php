<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/inventory.php';

require_post();
csrf_verify();
require_superadmin();

$pdo    = db();
$action = post_str('action', 20);

function handle_save(PDO $pdo): void
{
    $in = [
        'business_name'     => post_str('business_name', 100),
        'business_phone'    => post_str('business_phone', 20),
        'business_email'    => post_str('business_email', 150),
        'business_address'  => post_str('business_address', 255),
        'business_hours'    => post_str('business_hours', 100),
        'default_min_stock' => (string) max(0, post_int('default_min_stock')),
        'bank_account'      => post_str('bank_account', 255),
    ];

    $errors = [];
    if (mb_strlen($in['business_name']) < 3)                 { $errors[] = 'Nama usaha minimal 3 karakter.'; }
    if (!valid_phone($in['business_phone']))                 { $errors[] = 'Nomor telepon tidak valid.'; }
    if (!filter_var($in['business_email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Email usaha tidak valid.'; }
    if ($in['business_address'] === '')                      { $errors[] = 'Alamat toko wajib diisi.'; }
    if ($in['business_hours'] === '')                        { $errors[] = 'Jam operasional wajib diisi.'; }
    if ($in['bank_account'] === '')                          { $errors[] = 'Rekening transfer wajib diisi.'; }
    if ((int) $in['default_min_stock'] > 100000)             { $errors[] = 'Batas minimum stok terlalu besar.'; }

    if ($errors) {
        $_SESSION['settings_old'] = $in;
        foreach ($errors as $err) {
            flash('danger', $err);
        }
        redirect('admin/settings.php');
    }

    $pdo->beginTransaction();
    try {
        foreach ($in as $key => $value) {
            set_setting($key, $value);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Save settings error: ' . $e->getMessage());
        $_SESSION['settings_old'] = $in;
        flash('danger', 'Gagal menyimpan pengaturan. Silakan coba lagi.');
        redirect('admin/settings.php');
    }

    flash('success', 'Pengaturan disimpan.');
    redirect('admin/settings.php');
}

function handle_apply_min_stock(PDO $pdo): void
{
    $min = max(0, (int) get_setting('default_min_stock', '10'));
    $st  = $pdo->prepare('UPDATE products SET min_stock = ? WHERE is_active = 1');
    $st->execute([$min]);
    flash('success', 'Batas minimum ' . $min . ' diterapkan ke ' . $st->rowCount() . ' produk aktif.');
    redirect('admin/settings.php');
}

function handle_save_qris(PDO $pdo): void
{
    $name    = post_str('qris_name', 100);
    $remove  = isset($_POST['remove_qris']);
    $current = get_setting('qris_image');

    if (mb_strlen($name) < 3) {
        flash('danger', 'Nama merchant minimal 3 karakter.');
        redirect('admin/settings.php');
    }

    $newFile = null;
    $file = $_FILES['qris_image'] ?? null;
    if (is_array($file) && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        try {
            $newFile = save_uploaded_image($file);
        } catch (RuntimeException $e) {
            flash('danger', $e->getMessage());
            redirect('admin/settings.php');
        }
    }

    set_setting('qris_name', $name);

    if ($newFile !== null || $remove) {
        set_setting('qris_image', $newFile ?? '');
        if ($current !== '' && is_file(UPLOAD_PATH . basename($current))) {
            @unlink(UPLOAD_PATH . basename($current)); // hapus gambar lama
        }
    }

    flash('success', $newFile !== null ? 'QRIS diperbarui dan aktif di checkout.'
        : ($remove ? 'QRIS dihapus. Metode QRIS tidak tampil lagi.' : 'Pengaturan QRIS disimpan.'));
    redirect('admin/settings.php');
}

switch ($action) {
    case 'save':          handle_save($pdo);           break;
    case 'apply_min_stock': handle_apply_min_stock($pdo); break;
    case 'save_qris':       handle_save_qris($pdo);      break;
    default:
        flash('danger', 'Aksi tidak dikenal.');
        redirect('admin/settings.php');
}