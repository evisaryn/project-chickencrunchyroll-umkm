<?php
declare(strict_types=1);

require_once __DIR__ . '/stats.php';

const REPORT_MAX_DAYS = 366;

/**
 * Tentukan periode laporan dari parameter GET.
 * Mode: daily | weekly | monthly | range. Tanggal start dan end bersifat inklusif (Y-m-d).
 */
function report_period(array $in): array
{
    $mode = (string) ($in['period'] ?? 'daily');
    if (!in_array($mode, ['daily', 'weekly', 'monthly', 'range'], true)) {
        $mode = 'daily';
    }

    $get = static function (string $k) use ($in): string {
        $v = $in[$k] ?? '';
        return is_string($v) ? trim($v) : '';
    };
    $okDate = static fn (string $d): bool => valid_date_ymd($d) && $d >= '2000-01-01' && $d <= '2099-12-31';

    $today = date('Y-m-d');
    $error = null;

    $date = $get('date');
    if (!$okDate($date)) {
        $date = $today;
    }

    if ($mode === 'daily') {
        $start = $end = $date;
        $label = 'Harian: ' . date('d/m/Y', strtotime($date));
    } elseif ($mode === 'weekly') {
        $dow   = (int) date('N', strtotime($date));
        $start = date('Y-m-d', strtotime($date . ' -' . ($dow - 1) . ' day'));
        $end   = date('Y-m-d', strtotime($start . ' +6 day'));
        $label = 'Mingguan: ' . date('d/m/Y', strtotime($start)) . ' - ' . date('d/m/Y', strtotime($end));
    } elseif ($mode === 'monthly') {
        $month = $get('month');
        if (!preg_match('/^20\d{2}-(0[1-9]|1[0-2])$/', $month)) {
            $month = date('Y-m');
        }
        $start = $month . '-01';
        $end   = date('Y-m-t', strtotime($start));
        $label = 'Bulanan: ' . month_short((int) substr($month, 5, 2)) . ' ' . substr($month, 0, 4);
    } else {
        $start = $get('from');
        $end   = $get('to');
        $valid = $okDate($start) && $okDate($end);

        if ($valid && $start > $end) {
            $error = 'Tanggal awal tidak boleh melebihi tanggal akhir.';
            $valid = false;
        }
        if ($valid && (new DateTime($start))->diff(new DateTime($end))->days + 1 > REPORT_MAX_DAYS) {
            $error = 'Rentang maksimal ' . REPORT_MAX_DAYS . ' hari.';
            $valid = false;
        }
        if (!$valid) {
            if (($get('from') !== '' || $get('to') !== '') && $error === null) {
                $error = 'Tanggal tidak valid.';
            }
            $start = date('Y-m-01');
            $end   = $today;
        }
        $label = 'Rentang: ' . date('d/m/Y', strtotime($start)) . ' - ' . date('d/m/Y', strtotime($end));
    }

    return [
        'mode'    => $mode,
        'start'   => $start,
        'end'     => $end,
        'date'    => $date,
        'label'   => $label,
        'error'   => $error,
        'from_ts' => $start . ' 00:00:00',
        'to_ts'   => date('Y-m-d', strtotime($end . ' +1 day')) . ' 00:00:00',
    ];
}

/** Query string yang mempertahankan periode (untuk tautan ekspor). */
function report_query(array $per, array $extra = []): string
{
    $q = ['period' => $per['mode']];
    if ($per['mode'] === 'daily' || $per['mode'] === 'weekly') {
        $q['date'] = $per['date'];
    } elseif ($per['mode'] === 'monthly') {
        $q['month'] = substr($per['start'], 0, 7);
    } else {
        $q['from'] = $per['start'];
        $q['to']   = $per['end'];
    }
    return http_build_query($q + $extra);
}

/** Ringkasan angka utama periode. */
function report_summary(array $per): array
{
    $pdo = db();

    $st = $pdo->prepare(
        'SELECT COUNT(*) AS trx,
                COALESCE(SUM(o.total), 0)        AS sales,
                COALESCE(SUM(o.subtotal), 0)     AS subtotal,
                COALESCE(SUM(o.delivery_fee), 0) AS delivery,
                COALESCE(SUM(o.total_cost), 0)   AS cost
         FROM orders o JOIN payments p ON p.order_id = o.id
         WHERE ' . SALE_VALID_SQL . ' AND o.created_at >= ? AND o.created_at < ?'
    );
    $st->execute([$per['from_ts'], $per['to_ts']]);
    $s = $st->fetch();

    $st = $pdo->prepare(
        "SELECT COUNT(*) AS total,
                COALESCE(SUM(o.status = 'cancelled'), 0) AS cancelled,
                COALESCE(SUM(o.status <> 'cancelled' AND p.status = 'unpaid'), 0) AS unpaid
         FROM orders o LEFT JOIN payments p ON p.order_id = o.id
         WHERE o.created_at >= ? AND o.created_at < ?"
    );
    $st->execute([$per['from_ts'], $per['to_ts']]);
    $a = $st->fetch();

    $st = $pdo->prepare(
        'SELECT COUNT(*) AS n, COALESCE(SUM(total_cost), 0) AS total
         FROM restocks WHERE restock_date BETWEEN ? AND ?'
    );
    $st->execute([$per['start'], $per['end']]);
    $r = $st->fetch();

    $subtotal = (float) $s['subtotal'];
    $cost     = (float) $s['cost'];
    $profit   = $subtotal - $cost;

    return [
        'trx'           => (int) $s['trx'],
        'sales'         => (float) $s['sales'],
        'subtotal'      => $subtotal,
        'delivery'      => (float) $s['delivery'],
        'cost'          => $cost,
        'profit'        => $profit,
        'margin'        => $subtotal > 0 ? $profit / $subtotal * 100 : 0.0,
        'orders_all'    => (int) $a['total'],
        'orders_cancel' => (int) $a['cancelled'],
        'orders_unpaid' => (int) $a['unpaid'],
        'restock_n'     => (int) $r['n'],
        'restock_total' => (float) $r['total'],
    ];
}

/** Rincian per hari (hari tanpa penjualan tetap tampil dengan nilai 0). */
function report_daily(array $per): array
{
    $pdo  = db();
    $rows = [];
    for ($t = strtotime($per['start']); $t <= strtotime($per['end']); $t = strtotime('+1 day', $t)) {
        $k = date('Y-m-d', $t);
        $rows[$k] = ['date' => $k, 'trx' => 0, 'sales' => 0.0, 'subtotal' => 0.0,
                     'cost' => 0.0, 'profit' => 0.0, 'restock' => 0.0];
    }

    $st = $pdo->prepare(
        'SELECT DATE(o.created_at) AS d, COUNT(*) AS trx, SUM(o.total) AS sales,
                SUM(o.subtotal) AS subtotal, SUM(o.total_cost) AS cost
         FROM orders o JOIN payments p ON p.order_id = o.id
         WHERE ' . SALE_VALID_SQL . ' AND o.created_at >= ? AND o.created_at < ?
         GROUP BY DATE(o.created_at)'
    );
    $st->execute([$per['from_ts'], $per['to_ts']]);
    foreach ($st->fetchAll() as $r) {
        $k = (string) $r['d'];
        if (isset($rows[$k])) {
            $rows[$k]['trx']      = (int) $r['trx'];
            $rows[$k]['sales']    = (float) $r['sales'];
            $rows[$k]['subtotal'] = (float) $r['subtotal'];
            $rows[$k]['cost']     = (float) $r['cost'];
            $rows[$k]['profit']   = (float) $r['subtotal'] - (float) $r['cost'];
        }
    }

    $st = $pdo->prepare(
        'SELECT restock_date AS d, SUM(total_cost) AS total
         FROM restocks WHERE restock_date BETWEEN ? AND ? GROUP BY restock_date'
    );
    $st->execute([$per['start'], $per['end']]);
    foreach ($st->fetchAll() as $r) {
        $k = (string) $r['d'];
        if (isset($rows[$k])) {
            $rows[$k]['restock'] = (float) $r['total'];
        }
    }

    return array_values($rows);
}

/** Jumlahkan hasil report_daily(). */
function report_totals(array $daily): array
{
    $t = ['trx' => 0, 'sales' => 0.0, 'subtotal' => 0.0, 'cost' => 0.0, 'profit' => 0.0, 'restock' => 0.0];
    foreach ($daily as $r) {
        foreach ($t as $k => $_) {
            $t[$k] += $r[$k];
        }
    }
    return $t;
}

/** Produk utama terlaris (nilai = line_total, sudah termasuk varian). */
function report_top_products(array $per, int $limit = 10): array
{
    $st = db()->prepare(
        'SELECT oi.product_name AS name, SUM(oi.quantity) AS qty, SUM(oi.line_total) AS revenue
         FROM order_items oi
         JOIN orders o   ON o.id = oi.order_id
         JOIN payments p ON p.order_id = o.id
         WHERE ' . SALE_VALID_SQL . ' AND o.created_at >= ? AND o.created_at < ?
         GROUP BY oi.product_id, oi.product_name
         ORDER BY qty DESC, revenue DESC
         LIMIT ' . max(1, $limit)
    );
    $st->execute([$per['from_ts'], $per['to_ts']]);
    return $st->fetchAll();
}

/** Varian terlaris (saus, bubuk, filling). */
function report_top_variants(array $per, int $limit = 10): array
{
    $st = db()->prepare(
        'SELECT oia.addon_name AS name, oia.addon_group AS grp,
                SUM(oi.quantity) AS qty, SUM(oia.price * oi.quantity) AS revenue
         FROM order_item_addons oia
         JOIN order_items oi ON oi.id = oia.order_item_id
         JOIN orders o       ON o.id = oi.order_id
         JOIN payments p     ON p.order_id = o.id
         WHERE ' . SALE_VALID_SQL . ' AND o.created_at >= ? AND o.created_at < ?
         GROUP BY oia.addon_product_id, oia.addon_name, oia.addon_group
         ORDER BY qty DESC, revenue DESC
         LIMIT ' . max(1, $limit)
    );
    $st->execute([$per['from_ts'], $per['to_ts']]);
    return $st->fetchAll();
}

/** Daftar transaksi sah pada periode. */
function report_orders(array $per, int $limit = 200): array
{
    $st = db()->prepare(
        'SELECT o.id, o.order_number, o.created_at, o.customer_name, o.payment_method, o.status,
                o.subtotal, o.delivery_fee, o.total, o.total_cost
         FROM orders o JOIN payments p ON p.order_id = o.id
         WHERE ' . SALE_VALID_SQL . ' AND o.created_at >= ? AND o.created_at < ?
         ORDER BY o.created_at, o.id
         LIMIT ' . max(1, $limit)
    );
    $st->execute([$per['from_ts'], $per['to_ts']]);
    return $st->fetchAll();
}

/** Daftar restock pada periode (laporan pembelian). */
function report_restocks(array $per): array
{
    $st = db()->prepare(
        'SELECT r.id, r.restock_date, r.total_cost, s.name AS supplier_name,
                (SELECT COUNT(*) FROM restock_items ri WHERE ri.restock_id = r.id) AS item_count
         FROM restocks r LEFT JOIN suppliers s ON s.id = r.supplier_id
         WHERE r.restock_date BETWEEN ? AND ?
         ORDER BY r.restock_date, r.id'
    );
    $st->execute([$per['start'], $per['end']]);
    return $st->fetchAll();
}

/**
 * Kirim file CSV lalu hentikan skrip. Pemisah titik koma (cocok dengan Excel
 * berlokal Indonesia), diawali BOM UTF-8. Sel teks yang diawali = + - @ diberi
 * apostrof agar tidak dieksekusi sebagai rumus (CSV injection).
 */
function csv_download(string $filename, array $header, array $rows): void
{
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('X-Content-Type-Options: nosniff');

    $clean = static function ($v) {
        if (is_string($v) && $v !== '' && strpbrk($v[0], "=+-@\t\r") !== false) {
            return "'" . $v;
        }
        return $v;
    };

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array_map($clean, $header), ';', '"', '');
    foreach ($rows as $r) {
        fputcsv($out, array_map($clean, $r), ';', '"', '');
    }
    fclose($out);
    exit;
}