<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';

$pageTitle  = $pageTitle  ?? 'Beranda';
$activePage = $activePage ?? '';
$bodyClass  = $bodyClass  ?? '';
$user       = current_user();

// Jumlah item keranjang (diambil dari database, sesuai akun)
$cartCount = 0;
if ($user) {
    $st = db()->prepare(
        'SELECT COALESCE(SUM(ci.quantity), 0)
         FROM carts c JOIN cart_items ci ON ci.cart_id = c.id
         WHERE c.user_id = ?'
    );
    $st->execute([(int) $user['id']]);
    $cartCount = (int) $st->fetchColumn();
}

$cssFile = __DIR__ . '/../assets/css/style.css';
$cssVer  = is_file($cssFile) ? filemtime($cssFile) : 1;
$bizName = get_setting('business_name', 'Chicken Crunchy Roll');

function nav_active(string $key, string $current): string
{
    return $key === $current ? ' class="active"' : '';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | <?= e($bizName) ?></title>
  <meta name="theme-color" content="#B21807">
  <link rel="icon" type="image/svg+xml" href="<?= e(url('assets/images/logo.jpg')) ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>?v=<?= (int) $cssVer ?>">
</head>
<body class="<?= e($bodyClass) ?>">

<div class="topbar">
  <div class="container">
    <span>📍 <?= e(get_setting('business_address')) ?></span>
    <span>🕒 <?= e(get_setting('business_hours')) ?> &nbsp;|&nbsp; ☎ <?= e(get_setting('business_phone')) ?></span>
  </div>
</div>

<header class="navbar">
  <div class="container">
    <a class="brand" href="<?= e(url('index.php')) ?>">
      <img src="<?= e(url('assets/images/logo.jpg')) ?>" alt="Logo">
      <span><?= e($bizName) ?></span>
    </a>

    <button class="nav-toggle" type="button" aria-label="Buka menu" aria-expanded="false">☰</button>

    <ul class="nav-menu">
      <li><a href="<?= e(url('index.php')) ?>"<?= nav_active('home', $activePage) ?>>Beranda</a></li>
      <li><a href="<?= e(url('user/menu.php')) ?>"<?= nav_active('menu', $activePage) ?>>Menu</a></li>
      <li><a href="<?= e(url('user/about.php')) ?>"<?= nav_active('about', $activePage) ?>>Tentang Kami</a></li>
      <li><a href="<?= e(url('user/orders.php')) ?>"<?= nav_active('orders', $activePage) ?>>Pesanan Saya</a></li>

      <?php if ($user): ?>
        <li>
          <a href="<?= e(url('user/cart.php')) ?>"<?= nav_active('cart', $activePage) ?>>
            🛒 Keranjang <span class="cart-badge"><?= $cartCount ?></span>
          </a>
        </li>
        <?php if (is_admin()): ?>
          <li><a href="<?= e(url('admin/dashboard.php')) ?>">Dashboard ERP</a></li>
        <?php endif; ?>
        <li><a href="<?= e(url('user/profile.php')) ?>"<?= nav_active('profile', $activePage) ?>>👤 <?= e(explode(' ', $user['name'])[0]) ?></a></li>
        <li>
          <form method="post" action="<?= e(url('auth/logout.php')) ?>">
            <?= csrf_field() ?>
            <button type="submit" class="nav-link">Logout</button>
          </form>
        </li>
      <?php else: ?>
        <li><a href="<?= e(url('auth/login.php')) ?>"<?= nav_active('login', $activePage) ?>>Login</a></li>
      <?php endif; ?>
    </ul>
  </div>
</header>

<?php $flashes = get_flashes(); ?>
<?php if ($flashes): ?>
  <div class="flash-wrap">
    <?php foreach ($flashes as $f):
        $type = in_array($f['type'], ['success', 'danger', 'warning', 'info'], true)
            ? $f['type']
            : ($f['type'] === 'error' ? 'danger' : 'info'); ?>
      <div class="alert alert-<?= e($type) ?>" role="alert">
        <div><?= e($f['message']) ?></div>
        <button type="button" class="alert-close" aria-label="Tutup">&times;</button>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<main>