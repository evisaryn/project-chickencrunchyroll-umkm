<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

/** Escape output HTML (cegah XSS). Pakai di setiap echo data pengguna. */
function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Buat URL absolut dari path aplikasi. Contoh: url('user/menu.php') */
function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

/** Format angka ke Rupiah. */
function rupiah($amount): string
{
    return 'Rp ' . number_format((float) $amount, 0, ',', '.');
}

/** ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/** Hentikan request jika token CSRF tidak valid. Panggil di awal setiap action POST. */
function csrf_verify(): void
{
    $sent = $_POST['csrf_token'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf_token'] ?? '', $sent)) {
        http_response_code(419);
        exit('Token keamanan tidak valid. Silakan kembali dan muat ulang halaman.');
    }
}

/** Pastikan request berupa POST. */
function require_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Metode tidak diizinkan.');
    }
}

/** ---------- Flash message (notifikasi sekali tampil) ---------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

/** ---------- Input helpers ---------- */
function post_str(string $key, int $maxLen = 255): string
{
    $v = trim((string) ($_POST[$key] ?? ''));
    return mb_substr($v, 0, $maxLen);
}

function post_int(string $key, int $default = 0): int
{
    $v = $_POST[$key] ?? null;
    return filter_var($v, FILTER_VALIDATE_INT) !== false ? (int) $v : $default;
}

function post_money(string $key): float
{
    $v = $_POST[$key] ?? 0;
    $v = is_string($v) ? str_replace(['.', ','], ['', '.'], $v) : $v;
    return is_numeric($v) ? max(0.0, round((float) $v, 2)) : 0.0;
}

function get_int(string $key, int $default = 0): int
{
    $v = $_GET[$key] ?? null;
    return filter_var($v, FILTER_VALIDATE_INT) !== false ? (int) $v : $default;
}

function valid_phone(string $phone): bool
{
    return (bool) preg_match('/^[0-9+\-\s]{8,20}$/', $phone);
}

/** ---------- Pengaturan bisnis ---------- */
function get_setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query('SELECT setting_key, setting_value FROM business_settings') as $row) {
            $cache[$row['setting_key']] = (string) $row['setting_value'];
        }
    }
    return $cache[$key] ?? $default;
}

function set_setting(string $key, string $value): void
{
    $stmt = db()->prepare(
        'INSERT INTO business_settings (setting_key, setting_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    );
    $stmt->execute([$key, $value]);
}

/** ---------- Pesanan ---------- */
function generate_order_number(): string
{
    return 'CCR-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
}

function order_status_label(string $status): string
{
    return [
        'pending'    => 'Menunggu',
        'processing' => 'Diproses',
        'ready'      => 'Siap Diambil/Dikirim',
        'completed'  => 'Selesai',
        'cancelled'  => 'Dibatalkan',
    ][$status] ?? $status;
}

function payment_status_label(string $status): string
{
    return [
        'unpaid'   => 'Belum Dibayar',
        'paid'     => 'Lunas',
        'failed'   => 'Gagal',
        'refunded' => 'Dikembalikan',
    ][$status] ?? $status;
}

function addon_group_label(string $group): string
{
    return ['sauce' => 'Saus Celup', 'powder' => 'Bubuk Tabur', 'filling' => 'Filling'][$group] ?? $group;
}

/** ---------- Gambar produk ---------- */
function product_image_url(?string $filename): string
{
    if ($filename && is_file(UPLOAD_PATH . basename($filename))) {
        return UPLOAD_URL . rawurlencode(basename($filename));
    }
    return url('assets/images/placeholder.svg');
}

/**
 * Validasi dan simpan gambar upload. Mengembalikan nama file baru,
 * atau melempar RuntimeException jika tidak valid.
 */
function save_uploaded_image(array $file): string
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload gambar gagal.');
    }
    if ($file['size'] > MAX_UPLOAD_BYTES) {
        throw new RuntimeException('Ukuran gambar maksimal 2 MB.');
    }

    // Cek tipe asli file (bukan sekadar ekstensi)
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime]) || @getimagesize($file['tmp_name']) === false) {
        throw new RuntimeException('Format gambar harus JPG, PNG, atau WEBP.');
    }

    if (!is_dir(UPLOAD_PATH)) {
        mkdir(UPLOAD_PATH, 0755, true);
    }

    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], UPLOAD_PATH . $name)) {
        throw new RuntimeException('Gagal menyimpan gambar.');
    }
    return $name;
}

/** Format tanggal-waktu dari database ke tampilan Indonesia. */
function format_datetime(?string $value): string
{
    if (!$value) {
        return '-';
    }
    $t = strtotime($value);
    return $t ? date('d/m/Y H:i', $t) : '-';
}

function fulfillment_label(string $f): string
{
    return ['pickup' => 'Ambil di Toko', 'delivery' => 'Diantar'][$f] ?? $f;
}

function payment_method_label(string $m): string
{
    return ['cash' => 'Tunai', 'transfer' => 'Transfer Bank', 'qris' => 'QRIS'][$m] ?? $m;
}

/** URL gambar QRIS toko, atau null jika belum diunggah / file hilang. */
function qris_image_url(): ?string

{
    $f = get_setting('qris_image');
    if ($f !== '' && is_file(UPLOAD_PATH . basename($f))) {
        return UPLOAD_URL . rawurlencode(basename($f));
    }
    return null;
}

/** Ambil parameter GET sebagai string (dipotong dan di-trim). */
function get_str(string $key, int $maxLen = 60): string
{
    $v = $_GET[$key] ?? '';
    return is_string($v) ? mb_substr(trim($v), 0, $maxLen) : '';
}

/** Validasi tanggal berformat YYYY-MM-DD yang benar-benar ada di kalender. */
function valid_date_ymd(string $date): bool
{
    $d = DateTime::createFromFormat('!Y-m-d', $date);
    return $d !== false && $d->format('Y-m-d') === $date;
}

/** Tampilan nomor antrean, contoh: A-007. Tanda "-" untuk pesanan lama. */
function queue_label($number): string
{
    if ($number === null || $number === '' || (int) $number <= 0) {
        return '-';
    }
    return 'A-' . str_pad((string) (int) $number, 3, '0', STR_PAD_LEFT);
}

/**
 * Nomor antrean berikutnya untuk tanggal tertentu (Y-m-d).
 * WAJIB dipanggil di dalam transaksi: baris penghitung terkunci sampai commit.
 */
function next_queue_number(PDO $pdo, string $date): int
{
    $pdo->prepare('INSERT IGNORE INTO queue_counters (queue_date, last_number) VALUES (?, 0)')
        ->execute([$date]);
    $pdo->prepare('UPDATE queue_counters SET last_number = LAST_INSERT_ID(last_number + 1) WHERE queue_date = ?')
        ->execute([$date]);
    return (int) $pdo->query('SELECT LAST_INSERT_ID()')->fetchColumn();
}