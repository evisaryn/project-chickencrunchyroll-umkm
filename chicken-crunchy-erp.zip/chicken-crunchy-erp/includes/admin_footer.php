<?php
declare(strict_types=1);
$extraScripts = $extraScripts ?? [];
?>
    </main>
  </div>
</div>

<script src="<?= e(url('assets/js/script.js')) ?>"></script>
<script src="<?= e(url('assets/js/admin.js')) ?>"></script>
<?php foreach ($extraScripts as $js): ?>
  <script src="<?= e(url($js)) ?>"></script>
<?php endforeach; ?>
</body>
</html>