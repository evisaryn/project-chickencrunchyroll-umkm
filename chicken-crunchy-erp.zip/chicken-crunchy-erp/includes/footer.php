<?php
declare(strict_types=1);
$extraScripts = $extraScripts ?? [];
?>
</main>

<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <h4><?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?></h4>
        <p>Gulungan ayam crispy dengan pilihan saus celup, bubuk tabur, dan filling sesuai selera Anda.</p>
      </div>
      <div>
        <h4>Tautan</h4>
        <ul>
          <li><a href="<?= e(url('index.php')) ?>">Beranda</a></li>
          <li><a href="<?= e(url('user/menu.php')) ?>">Menu</a></li>
          <li><a href="<?= e(url('user/about.php')) ?>">Tentang Kami</a></li>
          <li><a href="<?= e(url('user/orders.php')) ?>">Pesanan Saya</a></li>
        </ul>
      </div>
      <div>
        <h4>Kontak</h4>
        <ul>
          <li>📍 <?= e(get_setting('business_address')) ?></li>
          <li>☎ <?= e(get_setting('business_phone')) ?></li>
          <li>✉ <?= e(get_setting('business_email')) ?></li>
          <li>🕒 <?= e(get_setting('business_hours')) ?></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      &copy; <?= date('Y') ?> <?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?>. Semua hak dilindungi.
    </div>
  </div>
</footer>

<script src="<?= e(url('assets/js/script.js')) ?>"></script>
<?php foreach ($extraScripts as $js): ?>
  <script src="<?= e(url($js)) ?>"></script>
<?php endforeach; ?>
</body>
</html>