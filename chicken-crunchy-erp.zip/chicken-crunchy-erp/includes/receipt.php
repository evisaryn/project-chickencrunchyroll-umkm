<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/**
 * Ambil data struk. Jika $userId diisi, pesanan harus milik user itu
 * (halaman pelanggan). Admin memanggil tanpa $userId.
 */
function receipt_load(int $orderId, ?int $userId = null): ?array
{
    $pdo    = db();
    $sql    = 'SELECT o.*, p.status AS pay_status, p.paid_at
               FROM orders o LEFT JOIN payments p ON p.order_id = o.id
               WHERE o.id = ?';
    $params = [$orderId];
    if ($userId !== null) {
        $sql .= ' AND o.user_id = ?';
        $params[] = $userId;
    }

    $st = $pdo->prepare($sql . ' LIMIT 1');
    $st->execute($params);
    $order = $st->fetch();
    if (!$order) {
        return null;
    }

    $st = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');
    $st->execute([$orderId]);
    $lines = $st->fetchAll();

    $addonMap = [];
    if ($lines) {
        $ids = array_map(static fn ($l) => (int) $l['id'], $lines);
        $in  = implode(',', array_fill(0, count($ids), '?'));
        $st  = $pdo->prepare(
            "SELECT order_item_id, addon_name, addon_group FROM order_item_addons
             WHERE order_item_id IN ($in)
             ORDER BY FIELD(addon_group, 'sauce', 'powder', 'filling'), addon_name"
        );
        $st->execute($ids);
        foreach ($st->fetchAll() as $a) {
            $addonMap[(int) $a['order_item_id']][(string) $a['addon_group']][] = (string) $a['addon_name'];
        }
    }

    foreach ($lines as &$line) {
        $line['addon_groups'] = $addonMap[(int) $line['id']] ?? [];
    }
    unset($line);

    return ['order' => $order, 'lines' => $lines];
}

/** Tampilkan halaman struk lengkap (HTML mandiri, tanpa header/footer situs). */
function receipt_render(array $data, string $backUrl): void
{
    $rc       = $data['order'];
    $rcRows   = $data['lines'];
    $paid     = ($rc['pay_status'] ?? '') === 'paid';
    $delivery = $rc['fulfillment'] === 'delivery'; // pesanan lama

    $cssFile = __DIR__ . '/../assets/css/receipt.css';
    $cssVer  = is_file($cssFile) ? filemtime($cssFile) : 1;
    $bizName = get_setting('business_name', 'Chicken Crunchy Roll');
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <title>Struk <?= e((string) $rc['order_number']) ?> | <?= e($bizName) ?></title>
  <link rel="icon" type="image/svg+xml" href="<?= e(url('assets/images/logo.jpg')) ?>">
  <link rel="stylesheet" href="<?= e(url('assets/css/receipt.css')) ?>?v=<?= (int) $cssVer ?>">
</head>
<body>

<div class="rc-actions no-print">
  <a class="rc-btn rc-btn-light" href="<?= e($backUrl) ?>">&larr; Kembali</a>
  <button type="button" class="rc-btn" onclick="window.print()">🖨 Cetak / Simpan PDF</button>
</div>

<main class="receipt">
  <header class="rc-head">
    <img src="<?= e(url('assets/images/logo.jpg')) ?>" alt="" class="rc-logo">
    <h1><?= e($bizName) ?></h1>
    <p><?= e(get_setting('business_address')) ?></p>
    <p>Telp: <?= e(get_setting('business_phone')) ?></p>
  </header>

  <hr class="rc-line">

  <?php if (!empty($rc['queue_number'])): ?>
    <div class="rc-queue">
      <small>NOMOR ANTREAN</small>
      <strong><?= e(queue_label($rc['queue_number'])) ?></strong>
    </div>
    <hr class="rc-line">
  <?php endif; ?>

  <dl class="rc-meta">
    <div><dt>No. Pesanan</dt><dd><?= e((string) $rc['order_number']) ?></dd></div>
    <div><dt>Tanggal</dt><dd><?= e(format_datetime($rc['created_at'])) ?></dd></div>
    <div><dt>Pelanggan</dt><dd><?= e((string) $rc['customer_name']) ?></dd></div>
    <div><dt>Telepon</dt><dd><?= e((string) $rc['customer_phone']) ?></dd></div>
    <div><dt>Pengambilan</dt><dd><?= e(fulfillment_label((string) $rc['fulfillment'])) ?></dd></div>
  </dl>
  <?php if ($delivery && $rc['address']): ?>
    <p class="rc-small">Alamat: <?= e((string) $rc['address']) ?></p>
  <?php endif; ?>

  <hr class="rc-line">

  <div class="rc-items">
    <?php foreach ($rcRows as $row): ?>
      <div class="rc-item">
        <div class="rc-item-name"><?= e((string) $row['product_name']) ?></div>
        <?php foreach ($row['addon_groups'] as $group => $names): ?>
          <div class="rc-small">+ <?= e(addon_group_label((string) $group)) ?>: <?= e(implode(', ', $names)) ?></div>
        <?php endforeach; ?>
        <div class="rc-item-line">
          <span><?= (int) $row['quantity'] ?> x <?= e(rupiah((float) $row['unit_price'] + (float) $row['addon_total'])) ?></span>
          <strong><?= e(rupiah($row['line_total'])) ?></strong>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <hr class="rc-line">

  <div class="rc-sum"><span>Subtotal</span><span><?= e(rupiah($rc['subtotal'])) ?></span></div>
  <?php if ((float) $rc['delivery_fee'] > 0): ?>
    <div class="rc-sum"><span>Ongkir</span><span><?= e(rupiah($rc['delivery_fee'])) ?></span></div>
  <?php endif; ?>
  <div class="rc-sum rc-total"><span>TOTAL</span><span><?= e(rupiah($rc['total'])) ?></span></div>

  <hr class="rc-line">

  <div class="rc-sum"><span>Metode bayar</span><span><?= e(payment_method_label((string) $rc['payment_method'])) ?></span></div>
  <?php if ($paid && $rc['paid_at']): ?>
    <div class="rc-sum"><span>Dibayar</span><span><?= e(format_datetime($rc['paid_at'])) ?></span></div>
  <?php endif; ?>

  <div class="rc-stamp <?= $paid ? 'rc-paid' : 'rc-unpaid' ?>"><?= $paid ? 'LUNAS' : 'BELUM LUNAS' ?></div>

  <?php if ($rc['notes']): ?>
    <p class="rc-small">Catatan: <?= e((string) $rc['notes']) ?></p>
  <?php endif; ?>

  <hr class="rc-line">

  <footer class="rc-foot">
    <p>Terima kasih sudah memesan!</p>
    <p class="rc-small">Tunjukkan nomor antrean saat mengambil pesanan.</p>
  </footer>
</main>

</body>
</html>
    <?php
}