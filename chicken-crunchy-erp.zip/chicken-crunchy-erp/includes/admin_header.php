<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';

require_admin(); // hanya admin/superadmin yang boleh sampai sini

$pageTitle  = $pageTitle  ?? 'Dashboard';
$activePage = $activePage ?? '';
$admin      = current_user();
$pdo        = db();

// Angka notifikasi di sidebar dan topbar
$pendingCount  = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$lowStockCount = (int) $pdo->query('SELECT COUNT(*) FROM products WHERE is_active = 1 AND stock <= min_stock')->fetchColumn();

$bizName = get_setting('business_name', 'Chicken Crunchy Roll');

// Menu sidebar: [kunci, label, ikon, file, badge, hanya superadmin]
$menuGroups = [
    'Utama' => [
        ['dashboard', 'Dashboard', '📊', 'admin/dashboard.php', 0, false],
    ],
    'Katalog & Stok' => [
        ['products',   'Produk',     '🍗', 'admin/products.php',   0,              false],
        ['categories', 'Kategori',   '🏷️', 'admin/categories.php', 0,              false],
        ['inventory',  'Inventaris', '📦', 'admin/inventory.php',  $lowStockCount, false],
        ['restocks',   'Restock',    '🚚', 'admin/restocks.php',   0,              false],
        ['suppliers',  'Pemasok',    '🏭', 'admin/suppliers.php',  0,              false],
    ],
    'Penjualan' => [
        ['orders',  'Pesanan', '🧾', 'admin/orders.php',  $pendingCount, false],
        ['reports', 'Laporan', '📈', 'admin/reports.php', 0,             false],
    ],
    'Pengguna & Sistem' => [
        ['customers', 'Pelanggan & Pengguna', '👥', 'admin/customers.php', 0, false],
        ['settings',  'Pengaturan',           '⚙️', 'admin/settings.php',  0, true],
    ],
];

$cssMain  = __DIR__ . '/../assets/css/style.css';
$cssAdmin = __DIR__ . '/../assets/css/admin.css';
$verMain  = is_file($cssMain)  ? filemtime($cssMain)  : 1;
$verAdmin = is_file($cssAdmin) ? filemtime($cssAdmin) : 1;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <title><?= e($pageTitle) ?> | Admin <?= e($bizName) ?></title>
  <meta name="theme-color" content="#B21807">
  <link rel="icon" type="image/svg+xml" href="<?= e(url('assets/images/logo.jpg')) ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>?v=<?= (int) $verMain ?>">
  <link rel="stylesheet" href="<?= e(url('assets/css/admin.css')) ?>?v=<?= (int) $verAdmin ?>">
</head>
<body class="admin-body">
<div class="admin-wrap">

  <aside class="admin-sidebar" id="adminSidebar" aria-label="Menu admin">
    <a class="side-brand" href="<?= e(url('admin/dashboard.php')) ?>">
      <img src="<?= e(url('assets/images/logo.jpg')) ?>" alt="Logo">
      <span><?= e($bizName) ?><small>ERP Admin</small></span>
    </a>

        <nav class="side-nav">
      <?php foreach ($menuGroups as $groupTitle => $menuItems): ?>
        <div class="side-title"><?= e($groupTitle) ?></div>
        <?php foreach ($menuItems as [$menuKey, $menuLabel, $menuIcon, $menuPath, $menuBadge, $menuSuperOnly]): ?>
          <?php if ($menuSuperOnly && !is_superadmin()) { continue; } ?>
          <a class="side-link<?= $menuKey === $activePage ? ' active' : '' ?>" href="<?= e(url($menuPath)) ?>">
            <span class="ico"><?= $menuIcon ?></span>
            <span><?= e($menuLabel) ?></span>
            <?php if ((int) $menuBadge > 0): ?><span class="side-badge"><?= (int) $menuBadge ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>

    <div class="side-foot">
      <div class="who">
        <strong><?= e($admin['name']) ?></strong>
        <small><?= e($admin['role'] === 'superadmin' ? 'Superadmin' : 'Admin') ?> &middot; <?= e($admin['email']) ?></small>
      </div>
      <a class="site-link" href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener">Lihat website pelanggan &#8599;</a>
      <form method="post" action="<?= e(url('auth/logout.php')) ?>">
        <?= csrf_field() ?>
        <button type="submit" class="btn btn-primary btn-sm">Logout</button>
      </form>
    </div>
  </aside>
  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <div class="admin-main">
    <header class="admin-topbar">
      <button type="button" class="sidebar-toggle" id="sidebarToggle" aria-label="Buka menu" aria-controls="adminSidebar">☰</button>
      <h1><?= e($pageTitle) ?></h1>
      <div class="top-alerts">
        <?php if ($pendingCount > 0): ?>
          <a class="top-alert" href="<?= e(url('admin/orders.php?status=pending')) ?>">🧾 <?= $pendingCount ?> pesanan baru</a>
        <?php endif; ?>
        <?php if ($lowStockCount > 0): ?>
          <a class="top-alert warn" href="<?= e(url('admin/inventory.php?filter=low')) ?>">⚠ <?= $lowStockCount ?> stok menipis</a>
        <?php endif; ?>
      </div>
    </header>

      <?php $flashes = get_flashes(); ?>
      <?php if ($flashes): ?>
        <div class="flash-wrap">
          <?php foreach ($flashes as $flashItem):
              $flashType = in_array($flashItem['type'], ['success', 'danger', 'warning', 'info'], true)
                  ? $flashItem['type']
                  : ($flashItem['type'] === 'error' ? 'danger' : 'info'); ?>
            <div class="alert alert-<?= e($flashType) ?>" role="alert">
              <div><?= e($flashItem['message']) ?></div>
              <button type="button" class="alert-close" aria-label="Tutup">&times;</button>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>