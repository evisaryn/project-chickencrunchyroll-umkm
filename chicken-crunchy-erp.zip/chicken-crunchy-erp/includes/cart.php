<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/** Batas pilihan add-on per grup untuk satu porsi roll. */
const ADDON_LIMITS = ['sauce' => 3, 'powder' => 1, 'filling' => 1];

/** Jumlah maksimal satu baris keranjang. */
const MAX_QTY_PER_LINE = 99;

/** Status stok untuk label di kartu produk. */
function stock_status(array $p): array
{
    $stock = (int) $p['stock'];
    $min   = (int) $p['min_stock'];

    if ($stock <= 0) {
        return ['class' => 'out', 'label' => 'Stok Habis'];
    }
    if ($stock <= $min) {
        return ['class' => 'low', 'label' => 'Sisa ' . $stock];
    }
    return ['class' => '', 'label' => 'Tersedia'];
}

/** Ambil id keranjang milik user; dibuat otomatis jika belum ada. */
function get_or_create_cart_id(int $userId): int
{
    $pdo = db();
    $st  = $pdo->prepare('SELECT id FROM carts WHERE user_id = ?');
    $st->execute([$userId]);
    $id = $st->fetchColumn();
    if ($id) {
        return (int) $id;
    }

    $pdo->prepare('INSERT IGNORE INTO carts (user_id) VALUES (?)')->execute([$userId]);
    $st->execute([$userId]);
    return (int) $st->fetchColumn();
}

/**
 * Isi keranjang lengkap dengan harga TERBARU dari tabel products.
 * Hasil: array berindeks id cart_item. Setiap baris memuat:
 * id, product_id, name, image, price, cost, quantity, stock, active,
 * addons[], addon_total, addon_cost, unit_total, line_total, issues[]
 */
function cart_lines(int $userId): array
{
    $pdo = db();

    $st = $pdo->prepare(
        'SELECT ci.id, ci.product_id, ci.quantity,
                p.name, p.image, p.price, p.cost_price, p.stock, p.is_active
         FROM carts c
         JOIN cart_items ci ON ci.cart_id = c.id
         JOIN products p    ON p.id = ci.product_id
         WHERE c.user_id = ?
         ORDER BY ci.id'
    );
    $st->execute([$userId]);

    $lines = [];
    foreach ($st->fetchAll() as $r) {
        $lines[(int) $r['id']] = [
            'id'         => (int) $r['id'],
            'product_id' => (int) $r['product_id'],
            'name'       => (string) $r['name'],
            'image'      => $r['image'],
            'price'      => (float) $r['price'],
            'cost'       => (float) $r['cost_price'],
            'quantity'   => (int) $r['quantity'],
            'stock'      => (int) $r['stock'],
            'active'     => (int) $r['is_active'] === 1,
            'addons'     => [],
            'issues'     => [],
        ];
    }
    if (!$lines) {
        return [];
    }

    // Add-on setiap baris
    $ids = array_keys($lines);
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $st  = $pdo->prepare(
        "SELECT cia.cart_item_id, a.id, a.name, a.addon_group, a.price, a.cost_price, a.stock, a.is_active
         FROM cart_item_addons cia
         JOIN products a ON a.id = cia.addon_product_id
         WHERE cia.cart_item_id IN ($in)
         ORDER BY FIELD(a.addon_group, 'sauce', 'powder', 'filling'), a.name"
    );
    $st->execute($ids);
    foreach ($st->fetchAll() as $a) {
        $lines[(int) $a['cart_item_id']]['addons'][] = [
            'id'     => (int) $a['id'],
            'name'   => (string) $a['name'],
            'group'  => (string) $a['addon_group'],
            'price'  => (float) $a['price'],
            'cost'   => (float) $a['cost_price'],
            'stock'  => (int) $a['stock'],
            'active' => (int) $a['is_active'] === 1,
        ];
    }

    // Total per baris
    foreach ($lines as &$l) {
        $l['addon_total'] = round(array_sum(array_column($l['addons'], 'price')), 2);
        $l['addon_cost']  = round(array_sum(array_column($l['addons'], 'cost')), 2);
        $l['unit_total']  = round($l['price'] + $l['addon_total'], 2);
        $l['line_total']  = round($l['unit_total'] * $l['quantity'], 2);
    }
    unset($l);

    // Masalah stok / ketersediaan
    $demand = cart_demand($lines);
    foreach ($lines as &$l) {
        $err = cart_stock_error(cart_line_stock_items($l), $demand, 0);
        if ($err !== null) {
            $l['issues'][] = $err;
        }
    }
    unset($l);

    return $lines;
}

/** Total kebutuhan stok per produk (produk utama + add-on) dari seluruh baris. */
function cart_demand(array $lines): array
{
    $demand = [];
    foreach ($lines as $l) {
        $demand[$l['product_id']] = ($demand[$l['product_id']] ?? 0) + $l['quantity'];
        foreach ($l['addons'] as $a) {
            $demand[$a['id']] = ($demand[$a['id']] ?? 0) + $l['quantity'];
        }
    }
    return $demand;
}

/** Daftar produk (utama + add-on) yang stoknya dipakai satu baris keranjang. */
function cart_line_stock_items(array $line): array
{
    $items = [[
        'id' => $line['product_id'], 'name' => $line['name'],
        'stock' => $line['stock'], 'active' => $line['active'],
    ]];
    foreach ($line['addons'] as $a) {
        $items[] = ['id' => $a['id'], 'name' => $a['name'], 'stock' => $a['stock'], 'active' => $a['active']];
    }
    return $items;
}

/**
 * Cek apakah (kebutuhan saat ini + tambahan $extra) masih cukup stok.
 * Mengembalikan pesan error pertama, atau null jika aman.
 */
function cart_stock_error(array $items, array $demand, int $extra): ?string
{
    foreach ($items as $it) {
        if (!$it['active']) {
            return $it['name'] . ' sudah tidak tersedia. Hapus dari keranjang.';
        }
        $current = $demand[$it['id']] ?? 0;
        if ($current + $extra > $it['stock']) {
            return 'Stok ' . $it['name'] . ' tidak mencukupi (tersisa ' . $it['stock']
                 . ', di keranjang ' . $current . ').';
        }
    }
    return null;
}

/** Ringkasan keranjang: jumlah item, subtotal, total modal, ada masalah atau tidak. */
function cart_totals(array $lines): array
{
    $count = 0;
    $subtotal = 0.0;
    $cost = 0.0;
    $hasIssues = false;

    foreach ($lines as $l) {
        $count    += $l['quantity'];
        $subtotal += $l['line_total'];
        $cost     += ($l['cost'] + $l['addon_cost']) * $l['quantity'];
        if ($l['issues']) {
            $hasIssues = true;
        }
    }
    return [
        'count'      => $count,
        'subtotal'   => round($subtotal, 2),
        'cost'       => round($cost, 2),
        'has_issues' => $hasIssues,
    ];
}