<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/** Error stok yang aman ditampilkan ke admin. */
class StockException extends RuntimeException
{
}

/**
 * Baca nominal rupiah bulat dari POST (hanya digit yang diambil).
 * Contoh: "15.000" atau "15000" menjadi 15000.0
 */
function post_rupiah(string $key): float
{
    $raw = $_POST[$key] ?? '';
    if (!is_scalar($raw)) {
        return 0.0;
    }
    $digits = (string) preg_replace('/[^0-9]/', '', (string) $raw);
    if ($digits === '') {
        return 0.0;
    }
    return (float) min((int) substr($digits, 0, 9), 999999999);
}

/**
 * SATU-SATUNYA pintu perubahan stok.
 * - WAJIB dipanggil di dalam transaksi (beginTransaction oleh pemanggil).
 * - Mengunci baris produk (FOR UPDATE), menolak stok negatif.
 * - Mencatat ke stock_movements (quantity selalu positif; arah dari $type).
 *
 * @param string $type    'in' atau 'out'
 * @param string $refType 'order' | 'order_cancel' | 'restock' | 'manual'
 * @return array{name:string,before:int,after:int}
 */
function apply_stock_change(
    PDO $pdo,
    int $productId,
    string $type,
    int $qty,
    string $refType,
    ?int $refId,
    ?string $notes,
    ?int $userId
): array {
    if (!$pdo->inTransaction()) {
        throw new LogicException('apply_stock_change harus dipanggil di dalam transaksi.');
    }
    if (!in_array($type, ['in', 'out'], true)) {
        throw new LogicException('Tipe pergerakan stok tidak valid.');
    }
    if ($qty <= 0) {
        throw new StockException('Jumlah harus lebih dari 0.');
    }

    $st = $pdo->prepare('SELECT id, name, stock FROM products WHERE id = ? FOR UPDATE');
    $st->execute([$productId]);
    $p = $st->fetch();
    if (!$p) {
        throw new StockException('Produk tidak ditemukan.');
    }

    $before = (int) $p['stock'];
    $after  = $type === 'in' ? $before + $qty : $before - $qty;

    if ($after < 0) {
        throw new StockException(
            'Stok ' . $p['name'] . ' tidak mencukupi (tersisa ' . $before . ', diminta ' . $qty . ').'
        );
    }

    $pdo->prepare('UPDATE products SET stock = ? WHERE id = ?')->execute([$after, $productId]);

    $pdo->prepare(
        'INSERT INTO stock_movements
           (product_id, movement_type, quantity, stock_before, stock_after,
            reference_type, reference_id, notes, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $productId, $type, $qty, $before, $after,
        $refType, $refId,
        $notes !== null && $notes !== '' ? mb_substr($notes, 0, 255) : null,
        $userId,
    ]);

    return ['name' => (string) $p['name'], 'before' => $before, 'after' => $after];
}

function movement_ref_label(string $refType): string
{
    return [
        'order'        => 'Pesanan',
        'order_cancel' => 'Pembatalan pesanan',
        'restock'      => 'Restock',
        'manual'       => 'Manual',
    ][$refType] ?? $refType;
}

/** Slug sederhana untuk kategori. */
function slugify(string $text): string
{
    $text = mb_strtolower($text);
    $text = (string) preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? $text : 'kategori';
}