<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/**
 * Definisi "penjualan sah" (alias tabel: o = orders, p = payments).
 * Dipakai dashboard dan laporan agar angkanya selalu konsisten.
 */
const SALE_VALID_SQL = "o.status <> 'cancelled' AND p.status = 'paid'";

/** Singkatan bulan Indonesia untuk label grafik. */
function month_short(int $m): string
{
    return ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'][$m - 1] ?? '';
}

/** Seluruh angka untuk kartu statistik dan ringkasan transaksi. */
function dashboard_stats(): array
{
    $pdo        = db();
    $todayStart = date('Y-m-d 00:00:00');
    $tomorrow   = date('Y-m-d 00:00:00', strtotime('+1 day'));
    $monthStart = date('Y-m-01 00:00:00');

    $from = 'FROM orders o JOIN payments p ON p.order_id = o.id WHERE ' . SALE_VALID_SQL;

    // Total sepanjang waktu
    $all = $pdo->query("SELECT COALESCE(SUM(o.total), 0) AS sales, COUNT(*) AS trx $from")->fetch();

    // Penjualan sah pada rentang waktu tertentu
    $period = static function (string $start, string $end) use ($pdo, $from): array {
        $st = $pdo->prepare(
            "SELECT COALESCE(SUM(o.total), 0)      AS sales,
                    COALESCE(SUM(o.subtotal), 0)   AS subtotal,
                    COALESCE(SUM(o.total_cost), 0) AS cost,
                    COUNT(*)                       AS trx
             $from AND o.created_at >= ? AND o.created_at < ?"
        );
        $st->execute([$start, $end]);
        return $st->fetch();
    };
    $today = $period($todayStart, $tomorrow);
    $month = $period($monthStart, $tomorrow);

    // Pesanan hari ini (tidak termasuk yang dibatalkan)
    $st = $pdo->prepare(
        "SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at < ? AND status <> 'cancelled'"
    );
    $st->execute([$todayStart, $tomorrow]);
    $ordersToday = (int) $st->fetchColumn();

    // Produk dan stok
    $mainCount  = (int) $pdo->query("SELECT COUNT(*) FROM products WHERE is_active = 1 AND product_type = 'main'")->fetchColumn();
    $addonCount = (int) $pdo->query("SELECT COUNT(*) FROM products WHERE is_active = 1 AND product_type = 'addon'")->fetchColumn();
    $lowStock   = (int) $pdo->query("SELECT COUNT(*) FROM products WHERE is_active = 1 AND stock <= min_stock")->fetchColumn();

    // Pelanggan
    $customers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

    // Jumlah pesanan per status
    $statusCounts = ['pending' => 0, 'processing' => 0, 'ready' => 0, 'completed' => 0, 'cancelled' => 0];
    foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM orders GROUP BY status')->fetchAll() as $r) {
        $statusCounts[(string) $r['status']] = (int) $r['n'];
    }

    // Pesanan aktif yang belum dibayar
    $unpaid = (int) $pdo->query(
        "SELECT COUNT(*) FROM orders o JOIN payments p ON p.order_id = o.id
         WHERE o.status <> 'cancelled' AND p.status = 'unpaid'"
    )->fetchColumn();

    return [
        'sales_total'   => (float) $all['sales'],
        'sales_trx'     => (int) $all['trx'],
        'sales_today'   => (float) $today['sales'],
        'trx_today'     => (int) $today['trx'],
        'sales_month'   => (float) $month['sales'],
        'cost_month'    => (float) $month['cost'],
        'profit_month'  => (float) $month['subtotal'] - (float) $month['cost'],
        'orders_today'  => $ordersToday,
        'products_main' => $mainCount,
        'products_addon' => $addonCount,
        'low_stock'     => $lowStock,
        'customers'     => $customers,
        'status_counts' => $statusCounts,
        'unpaid'        => $unpaid,
    ];
}

/**
 * Data grafik penjualan sah.
 * $range = 'daily' (14 hari terakhir) atau 'monthly' (12 bulan terakhir).
 * Hasil: [['label' => '13/10', 'value' => 125000.0, 'orders' => 3], ...] (hari/bulan kosong diisi 0)
 */
function sales_series(string $range): array
{
    $pdo = db();
    $buckets = [];

    if ($range === 'monthly') {
        for ($i = 11; $i >= 0; $i--) {
            $t = strtotime(date('Y-m-01') . " -$i month");
            $buckets[date('Y-m', $t)] = [
                'label' => month_short((int) date('n', $t)) . ' ' . date('y', $t),
                'value' => 0.0, 'orders' => 0,
            ];
        }
        $start = array_key_first($buckets) . '-01 00:00:00';
        $expr  = "DATE_FORMAT(o.created_at, '%Y-%m')";
    } else {
        for ($i = 13; $i >= 0; $i--) {
            $t = strtotime("-$i day");
            $buckets[date('Y-m-d', $t)] = ['label' => date('d/m', $t), 'value' => 0.0, 'orders' => 0];
        }
        $start = array_key_first($buckets) . ' 00:00:00';
        $expr  = 'DATE(o.created_at)';
    }

    $st = $pdo->prepare(
        "SELECT $expr AS k, SUM(o.total) AS sales, COUNT(*) AS trx
         FROM orders o JOIN payments p ON p.order_id = o.id
         WHERE " . SALE_VALID_SQL . " AND o.created_at >= ?
         GROUP BY k"
    );
    $st->execute([$start]);
    foreach ($st->fetchAll() as $r) {
        $key = (string) $r['k'];
        if (isset($buckets[$key])) {
            $buckets[$key]['value']  = (float) $r['sales'];
            $buckets[$key]['orders'] = (int) $r['trx'];
        }
    }

    return array_values($buckets);
}

/** Produk dengan stok paling kritis (habis lebih dulu, lalu yang paling tipis). */
function low_stock_items(int $limit = 6): array
{
    $st = db()->prepare(
        'SELECT id, name, stock, min_stock, product_type
         FROM products
         WHERE is_active = 1 AND stock <= min_stock
         ORDER BY stock ASC, name ASC
         LIMIT ' . max(1, $limit)
    );
    $st->execute();
    return $st->fetchAll();
}

/** Produk utama terlaris dari penjualan sah. */
function top_products(int $limit = 5): array
{
    $st = db()->prepare(
        'SELECT oi.product_name, SUM(oi.quantity) AS qty, SUM(oi.line_total) AS revenue
         FROM order_items oi
         JOIN orders o   ON o.id = oi.order_id
         JOIN payments p ON p.order_id = o.id
         WHERE ' . SALE_VALID_SQL . '
         GROUP BY oi.product_id, oi.product_name
         ORDER BY qty DESC
         LIMIT ' . max(1, $limit)
    );
    $st->execute();
    return $st->fetchAll();
}

/** Pesanan terbaru (semua status) untuk tabel dashboard. */
function recent_orders(int $limit = 8): array
{
    $st = db()->prepare(
        'SELECT o.id, o.order_number, o.customer_name, o.total, o.status, o.created_at,
                p.status AS pay_status
         FROM orders o
         LEFT JOIN payments p ON p.order_id = o.id
         ORDER BY o.created_at DESC, o.id DESC
         LIMIT ' . max(1, $limit)
    );
    $st->execute();
    return $st->fetchAll();
}