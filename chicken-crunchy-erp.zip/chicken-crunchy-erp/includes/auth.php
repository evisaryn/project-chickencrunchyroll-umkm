<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/** Mulai session dengan pengaturan cookie yang lebih aman. */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']),
    ]);
    session_start();
}

/** Ambil data user yang sedang login (selalu dicek ulang ke database). */
function current_user(): ?array
{
    static $user = false;

    if ($user !== false) {
        return $user;
    }
    if (empty($_SESSION['user_id'])) {
        return $user = null;
    }

    $stmt = db()->prepare(
        'SELECT id, name, email, phone, address, role, is_active, created_at
         FROM users WHERE id = ? LIMIT 1'
    );
    $stmt->execute([(int) $_SESSION['user_id']]);
    $row = $stmt->fetch();

    // Jika akun dihapus/dinonaktifkan, paksa logout
    if (!$row || (int) $row['is_active'] !== 1) {
        logout_user();
        return $user = null;
    }
    return $user = $row;
}

function is_logged_in(): bool
{
    return current_user() !== null;
}

function is_admin(): bool
{
    $u = current_user();
    return $u !== null && in_array($u['role'], ['admin', 'superadmin'], true);
}

function is_superadmin(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'superadmin';
}

/** Login: regenerasi session ID untuk mencegah session fixation. */
function login_user(int $userId): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    unset($_SESSION['csrf_token']); // token baru untuk sesi baru
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** Wajib login (pelanggan atau admin). */
function require_login(): void
{
    if (!is_logged_in()) {
        flash('warning', 'Silakan login terlebih dahulu.');
        redirect('auth/login.php');
    }
}

/** Wajib admin. Pelanggan biasa ditolak (403). Pakai di SETIAP halaman dan action admin. */
function require_admin(): void
{
    if (!is_logged_in()) {
        redirect('auth/login.php?admin=1');
    }
    if (!is_admin()) {
        http_response_code(403);
        exit('Akses ditolak. Halaman ini hanya untuk admin.');
    }
}

/** Wajib superadmin (mis. kelola akun admin dan pengaturan sensitif). */
function require_superadmin(): void
{
    require_admin();
    if (!is_superadmin()) {
        http_response_code(403);
        exit('Akses ditolak. Hanya superadmin yang berwenang.');
    }
}