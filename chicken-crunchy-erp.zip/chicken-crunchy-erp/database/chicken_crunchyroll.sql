-- =====================================================
-- Chicken Crunchy Roll ERP - Database Schema
-- Kompatibel: MySQL 5.7+/8.x dan MariaDB 10.4+ (XAMPP)
-- =====================================================
CREATE DATABASE IF NOT EXISTS chicken_crunchyroll
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE chicken_crunchyroll;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS payments, order_item_addons, order_items, orders,
  cart_item_addons, cart_items, carts,
  restock_items, restocks, suppliers,
  stock_movements, products, categories,
  business_settings, users;
SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------
-- users: akun pelanggan dan admin
-- role: customer | admin | superadmin
-- -----------------------------------------------------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL,
  phone         VARCHAR(20)  NULL,
  address       TEXT         NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('customer','admin','superadmin') NOT NULL DEFAULT 'customer',
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- categories: kategori produk (Roll, Saus, Bubuk, Filling)
-- -----------------------------------------------------
CREATE TABLE categories (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  slug       VARCHAR(120) NOT NULL,
  is_active  TINYINT(1)   NOT NULL DEFAULT 1,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_categories_slug (slug)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- products: produk utama (main) dan varian tambahan (addon)
-- price      = harga jual (untuk addon = harga tambahan per porsi)
-- cost_price = harga pokok/modal per unit
-- addon_group: sauce | powder | filling (hanya untuk addon)
-- -----------------------------------------------------
CREATE TABLE products (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id  INT UNSIGNED NOT NULL,
  name         VARCHAR(150) NOT NULL,
  description  TEXT NULL,
  image        VARCHAR(255) NULL,
  price        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  cost_price   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  stock        INT NOT NULL DEFAULT 0,
  min_stock    INT NOT NULL DEFAULT 5,
  product_type ENUM('main','addon') NOT NULL DEFAULT 'main',
  addon_group  ENUM('sauce','powder','filling') NULL,
  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_products_category (category_id),
  KEY idx_products_type_active (product_type, is_active),
  KEY idx_products_stock (stock, min_stock),
  CONSTRAINT fk_products_category FOREIGN KEY (category_id)
    REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- carts, cart_items, cart_item_addons: keranjang per akun
-- -----------------------------------------------------
CREATE TABLE carts (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_carts_user (user_id),
  CONSTRAINT fk_carts_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cart_items (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cart_id    INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity   INT UNSIGNED NOT NULL DEFAULT 1,
  addon_key  VARCHAR(64) NOT NULL DEFAULT '',  -- hash kombinasi addon, agar baris yang sama digabung
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cart_line (cart_id, product_id, addon_key),
  CONSTRAINT fk_cart_items_cart FOREIGN KEY (cart_id)
    REFERENCES carts(id) ON DELETE CASCADE,
  CONSTRAINT fk_cart_items_product FOREIGN KEY (product_id)
    REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cart_item_addons (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cart_item_id     INT UNSIGNED NOT NULL,
  addon_product_id INT UNSIGNED NOT NULL,
  CONSTRAINT fk_cia_item FOREIGN KEY (cart_item_id)
    REFERENCES cart_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_cia_addon FOREIGN KEY (addon_product_id)
    REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- orders: header pesanan
-- status: pending | processing | ready | completed | cancelled
-- stock_deducted: 1 jika stok sudah dikurangi (anti pengurangan ganda)
-- -----------------------------------------------------
CREATE TABLE orders (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number     VARCHAR(30) NOT NULL,
  user_id          INT UNSIGNED NOT NULL,
  customer_name    VARCHAR(100) NOT NULL,
  customer_phone   VARCHAR(20)  NOT NULL,
  address          TEXT NULL,
  fulfillment      ENUM('pickup','delivery') NOT NULL DEFAULT 'pickup',
  payment_method   ENUM('cash','transfer') NOT NULL DEFAULT 'cash',
  status           ENUM('pending','processing','ready','completed','cancelled') NOT NULL DEFAULT 'pending',
  subtotal         DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  delivery_fee     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total_cost       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  stock_deducted   TINYINT(1) NOT NULL DEFAULT 0,
  notes            TEXT NULL,
  cancel_reason    VARCHAR(255) NULL,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_orders_number (order_number),
  KEY idx_orders_user (user_id),
  KEY idx_orders_status (status),
  KEY idx_orders_created (created_at),
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- order_items: item pesanan (snapshot nama, harga, modal)
-- unit_price = harga produk utama; addon_total = total addon per unit
-- line_total = (unit_price + addon_total) * quantity
-- -----------------------------------------------------
CREATE TABLE order_items (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id     INT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  unit_price   DECIMAL(12,2) NOT NULL,
  unit_cost    DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  addon_total  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  addon_cost   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  quantity     INT UNSIGNED NOT NULL,
  line_total   DECIMAL(12,2) NOT NULL,
  KEY idx_oi_order (order_id),
  KEY idx_oi_product (product_id),
  CONSTRAINT fk_oi_order FOREIGN KEY (order_id)
    REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_oi_product FOREIGN KEY (product_id)
    REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE order_item_addons (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_item_id    INT UNSIGNED NOT NULL,
  addon_product_id INT UNSIGNED NOT NULL,
  addon_name       VARCHAR(150) NOT NULL,
  addon_group      VARCHAR(20)  NOT NULL,
  price            DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  cost             DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  KEY idx_oia_item (order_item_id),
  CONSTRAINT fk_oia_item FOREIGN KEY (order_item_id)
    REFERENCES order_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_oia_addon FOREIGN KEY (addon_product_id)
    REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- stock_movements: riwayat seluruh perubahan stok
-- quantity selalu positif; arah ditentukan movement_type
-- -----------------------------------------------------
CREATE TABLE stock_movements (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id     INT UNSIGNED NOT NULL,
  movement_type  ENUM('in','out') NOT NULL,
  quantity       INT UNSIGNED NOT NULL,
  stock_before   INT NOT NULL,
  stock_after    INT NOT NULL,
  reference_type ENUM('order','order_cancel','restock','manual') NOT NULL,
  reference_id   INT UNSIGNED NULL,
  notes          VARCHAR(255) NULL,
  created_by     INT UNSIGNED NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_sm_product (product_id),
  KEY idx_sm_created (created_at),
  KEY idx_sm_reference (reference_type, reference_id),
  CONSTRAINT fk_sm_product FOREIGN KEY (product_id)
    REFERENCES products(id) ON DELETE CASCADE,
  CONSTRAINT fk_sm_user FOREIGN KEY (created_by)
    REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- suppliers, restocks, restock_items: modul pembelian
-- -----------------------------------------------------
CREATE TABLE suppliers (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(150) NOT NULL,
  phone      VARCHAR(20) NULL,
  address    TEXT NULL,
  is_active  TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE restocks (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  supplier_id  INT UNSIGNED NULL,
  restock_date DATE NOT NULL,
  total_cost   DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes        VARCHAR(255) NULL,
  created_by   INT UNSIGNED NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_restocks_date (restock_date),
  CONSTRAINT fk_restocks_supplier FOREIGN KEY (supplier_id)
    REFERENCES suppliers(id) ON DELETE SET NULL,
  CONSTRAINT fk_restocks_user FOREIGN KEY (created_by)
    REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE restock_items (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  restock_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity   INT UNSIGNED NOT NULL,
  unit_cost  DECIMAL(12,2) NOT NULL,
  subtotal   DECIMAL(12,2) NOT NULL,
  KEY idx_ri_restock (restock_id),
  CONSTRAINT fk_ri_restock FOREIGN KEY (restock_id)
    REFERENCES restocks(id) ON DELETE CASCADE,
  CONSTRAINT fk_ri_product FOREIGN KEY (product_id)
    REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- payments: status pembayaran per pesanan
-- Transfer TIDAK otomatis lunas; admin harus verifikasi.
-- -----------------------------------------------------
CREATE TABLE payments (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id  INT UNSIGNED NOT NULL,
  method    ENUM('cash','transfer') NOT NULL,
  amount    DECIMAL(12,2) NOT NULL,
  status    ENUM('unpaid','paid','failed','refunded') NOT NULL DEFAULT 'unpaid',
  paid_at   DATETIME NULL,
  note      VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_payments_order (order_id),
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id)
    REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- business_settings: pengaturan (key-value)
-- -----------------------------------------------------
CREATE TABLE business_settings (
  setting_key   VARCHAR(60) NOT NULL PRIMARY KEY,
  setting_value TEXT NULL,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================
-- DATA CONTOH
-- =====================================================
INSERT INTO categories (id, name, slug) VALUES
 (1, 'Roll Utama',   'roll-utama'),
 (2, 'Saus Celup',   'saus-celup'),
 (3, 'Bubuk Tabur',  'bubuk-tabur'),
 (4, 'Filling',      'filling');

-- Produk utama
INSERT INTO products (category_id, name, description, image, price, cost_price, stock, min_stock, product_type, addon_group) VALUES
 (1, 'Chicken Crunchy Roll Original',
     'Gulungan ayam crispy renyah dengan isian gurih, digoreng hingga keemasan.',
     'chicken-roll-original.jpg', 15000, 8000, 50, 10, 'main', NULL);

-- Saus celup (addon group: sauce)
INSERT INTO products (category_id, name, description, price, cost_price, stock, min_stock, product_type, addon_group) VALUES
 (2, 'Saus Sadis',       'Saus pedas level sadis.',            2000, 800, 100, 15, 'addon', 'sauce'),
 (2, 'Saus BBQ Spicy',   'Saus BBQ dengan sensasi pedas.',     2000, 800, 100, 15, 'addon', 'sauce'),
 (2, 'Saus Teriyaki',    'Saus teriyaki manis gurih.',         2000, 800, 100, 15, 'addon', 'sauce'),
 (2, 'Saus Lada Hitam',  'Saus lada hitam yang kuat.',         2000, 800, 100, 15, 'addon', 'sauce'),
 (2, 'Saus Keju',        'Saus keju creamy.',                  2500, 1000, 100, 15, 'addon', 'sauce');

-- Bubuk tabur (addon group: powder)
INSERT INTO products (category_id, name, description, price, cost_price, stock, min_stock, product_type, addon_group) VALUES
 (3, 'Bubuk Tabur Keju',       'Bubuk keju gurih.',         1500, 500, 100, 15, 'addon', 'powder'),
 (3, 'Bubuk Tabur Balado',     'Bubuk balado pedas.',       1500, 500, 100, 15, 'addon', 'powder'),
 (3, 'Bubuk Tabur Sweet Corn', 'Bubuk jagung manis.',       1500, 500, 100, 15, 'addon', 'powder');

-- Filling (addon group: filling). "Tanpa filling" ditangani di UI (tidak memilih apa pun).
INSERT INTO products (category_id, name, description, price, cost_price, stock, min_stock, product_type, addon_group) VALUES
 (4, 'Filling Keju',    'Tambahan isian keju leleh.',        3000, 1500, 80, 10, 'addon', 'filling'),
 (4, 'Filling Garlic',  'Tambahan isian garlic cream.',      3000, 1400, 80, 10, 'addon', 'filling'),
 (4, 'Filling Mentai',  'Tambahan isian saus mentai.',       4000, 2000, 80, 10, 'addon', 'filling');

INSERT INTO suppliers (name, phone, address) VALUES
 ('Supplier Ayam Segar', '081200000001', 'Bekasi'),
 ('Supplier Bumbu & Saus', '081200000002', 'Jakarta');

INSERT INTO business_settings (setting_key, setting_value) VALUES
 ('business_name',     'Chicken Crunchy Roll'),
 ('business_phone',    '081234567890'),
 ('business_email',    'halo@chickencrunccyroll.test'),
 ('business_address',  'Bekasi, Jawa Barat'),
 ('business_hours',    '10.00 - 21.00 WIB'),
 ('default_min_stock', '10'),
 ('delivery_fee',      '5000'),
 ('bank_account',      'BCA 1234567890 a.n. Chicken Crunchy Roll');

-- CATATAN: Akun admin TIDAK dibuat di sini agar tidak ada password default
-- yang tersimpan. Buat dengan: php database/create_admin.php