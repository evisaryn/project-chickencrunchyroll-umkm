<?php
declare(strict_types=1);

/**
 * Membuat akun superadmin pertama.
 * Jalankan dari terminal:  php database/create_admin.php
 * Hanya bisa lewat CLI agar tidak dapat dipanggil dari browser.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Skrip ini hanya boleh dijalankan lewat command line.');
}

require_once __DIR__ . '/../config/database.php';

function ask(string $label, bool $hidden = false): string
{
    echo $label;
    $isWindows = stripos(PHP_OS, 'WIN') === 0;

    if ($hidden && !$isWindows) {
        system('stty -echo');
        $value = trim((string) fgets(STDIN));
        system('stty echo');
        echo PHP_EOL;
        return $value;
    }
    return trim((string) fgets(STDIN));
}

$pdo = db();

echo "=== Buat Akun Superadmin Chicken Crunchy Roll ===" . PHP_EOL;

$exists = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('admin','superadmin')")->fetchColumn();
if ($exists > 0) {
    echo "Sudah ada akun admin di database." . PHP_EOL;
    $yes = strtolower(ask('Tetap tambah admin baru? (ketik "ya" untuk lanjut): '));
    if ($yes !== 'ya') {
        exit("Dibatalkan." . PHP_EOL);
    }
}

$name  = ask('Nama lengkap     : ');
$email = strtolower(ask('Email           : '));

if (stripos(PHP_OS, 'WIN') === 0) {
    echo "(Catatan: di Windows password terlihat saat diketik. Tutup jendela CMD setelah selesai.)" . PHP_EOL;
}
$pass1 = ask('Password (min 10): ', true);
$pass2 = ask('Ulangi password  : ', true);

$errors = [];
if (mb_strlen($name) < 3)                              $errors[] = 'Nama minimal 3 karakter.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL))        $errors[] = 'Email tidak valid.';
if (strlen($pass1) < 10)                               $errors[] = 'Password minimal 10 karakter.';
if (!preg_match('/[A-Za-z]/', $pass1) || !preg_match('/[0-9]/', $pass1)) {
    $errors[] = 'Password harus mengandung huruf dan angka.';
}
if ($pass1 !== $pass2)                                 $errors[] = 'Konfirmasi password tidak sama.';

if ($errors) {
    echo PHP_EOL . "Gagal:" . PHP_EOL;
    foreach ($errors as $err) {
        echo " - $err" . PHP_EOL;
    }
    exit(1);
}

try {
    $stmt = $pdo->prepare(
        "INSERT INTO users (name, email, phone, password_hash, role)
         VALUES (?, ?, NULL, ?, 'superadmin')"
    );
    $stmt->execute([$name, $email, password_hash($pass1, PASSWORD_DEFAULT)]);
    echo PHP_EOL . "Berhasil! Superadmin dibuat untuk: $email" . PHP_EOL;
    echo "Login di: http://localhost" . BASE_URL . "/auth/login.php?admin=1" . PHP_EOL;
} catch (PDOException $ex) {
    if ($ex->getCode() === '23000') {
        echo "Email sudah terdaftar." . PHP_EOL;
    } else {
        echo "Error database: " . $ex->getMessage() . PHP_EOL;
    }
    exit(1);
}