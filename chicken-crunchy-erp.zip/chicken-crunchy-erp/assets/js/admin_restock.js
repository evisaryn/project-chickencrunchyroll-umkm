/* Form restock: tambah/hapus baris, hitung total (server tetap menghitung ulang) */
document.addEventListener('DOMContentLoaded', function () {
  var box     = document.getElementById('itemRows');
  var tpl     = document.getElementById('rowTemplate');
  var addBtn  = document.getElementById('addRow');
  var totalEl = document.getElementById('restockTotal');
  if (!box || !tpl || !addBtn || !totalEl) return;

  function rupiah(n) {
    return 'Rp ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  function recalc() {
    var total = 0;
    box.querySelectorAll('.item-row').forEach(function (row) {
      var q = parseInt(row.querySelector('.in-qty').value, 10) || 0;
      var c = parseInt(row.querySelector('.in-cost').value, 10) || 0;
      row.querySelector('.row-subtotal').textContent = rupiah(q * c);
      total += q * c;
    });
    totalEl.textContent = rupiah(total);
  }

  addBtn.addEventListener('click', function () {
    box.appendChild(tpl.content.firstElementChild.cloneNode(true));
    recalc();
  });

  box.addEventListener('click', function (ev) {
    var btn = ev.target.closest('.remove-row');
    if (!btn) return;
    if (box.querySelectorAll('.item-row').length > 1) {
      btn.closest('.item-row').remove();
      recalc();
    }
  });

  // Saat barang dipilih, isi harga beli dengan harga pokok saat ini (jika masih kosong)
  box.addEventListener('change', function (ev) {
    if (ev.target.classList.contains('in-product')) {
      var opt = ev.target.selectedOptions[0];
      var cost = opt ? opt.getAttribute('data-cost') : '';
      var costIn = ev.target.closest('.item-row').querySelector('.in-cost');
      if (cost && cost !== '0' && !costIn.value) costIn.value = cost;
    }
    recalc();
  });
  box.addEventListener('input', recalc);

  recalc();
});