/* Form produk admin: tampilkan grup varian dan pratinjau gambar */
document.addEventListener('DOMContentLoaded', function () {
  var type = document.getElementById('product_type');
  var wrap = document.getElementById('groupWrap');
  var group = document.getElementById('addon_group');

  if (type && wrap && group) {
    var sync = function () {
      var isAddon = type.value === 'addon';
      wrap.classList.toggle('hidden', !isAddon);
      group.required = isAddon && !type.disabled;
    };
    type.addEventListener('change', sync);
    sync();
  }

  var file = document.getElementById('image');
  var preview = document.getElementById('imgPreview');
  if (file && preview) {
    file.addEventListener('change', function () {
      if (file.files && file.files[0]) {
        preview.src = URL.createObjectURL(file.files[0]);
      }
    });
  }
});