/* Modal pilihan varian di halaman menu */
document.addEventListener('DOMContentLoaded', function () {
  var modal = document.getElementById('variantModal');
  if (!modal) return;

  var form      = modal.querySelector('form');
  var title     = document.getElementById('vmTitle');
  var idInput   = document.getElementById('vmProductId');
  var qtyInput  = document.getElementById('vmQty');
  var qtyText   = document.getElementById('vmQtyText');
  var totalEl   = document.getElementById('vmTotal');
  var basePrice = 0;
  var maxQty    = 1;

  function rupiah(n) {
    return 'Rp ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  // Batasi jumlah checkbox sesuai data-limit grup (mis. saus maksimal 3)
  function enforceLimits() {
    modal.querySelectorAll('.option-group[data-type="checkbox"]').forEach(function (group) {
      var limit = parseInt(group.getAttribute('data-limit'), 10);
      var boxes = group.querySelectorAll('input[type="checkbox"]');
      var checked = 0;
      boxes.forEach(function (b) { if (b.checked) checked++; });
      boxes.forEach(function (b) {
        var soldOut = b.getAttribute('data-soldout') === '1';
        b.disabled = soldOut || (!b.checked && checked >= limit);
        b.closest('.option').classList.toggle('disabled', b.disabled);
      });
    });
  }

  function recalc() {
    var addons = 0;
    modal.querySelectorAll('input[data-price]:checked').forEach(function (i) {
      addons += parseFloat(i.getAttribute('data-price')) || 0;
    });
    var qty = parseInt(qtyInput.value, 10) || 1;
    totalEl.textContent = rupiah((basePrice + addons) * qty);
    qtyText.textContent = qty;
  }

  function openModal(btn) {
    form.reset();
    idInput.value = btn.getAttribute('data-id');
    title.textContent = btn.getAttribute('data-name');
    basePrice = parseFloat(btn.getAttribute('data-price')) || 0;
    maxQty = Math.max(1, Math.min(99, parseInt(btn.getAttribute('data-stock'), 10) || 1));
    qtyInput.value = 1;
    enforceLimits();
    recalc();
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  document.querySelectorAll('.js-open-variant').forEach(function (btn) {
    btn.addEventListener('click', function () { openModal(btn); });
  });

  modal.addEventListener('click', function (ev) {
    if (ev.target === modal || ev.target.hasAttribute('data-close')) closeModal();
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && modal.classList.contains('open')) closeModal();
  });

  modal.querySelector('.js-qty-dec').addEventListener('click', function () {
    qtyInput.value = Math.max(1, (parseInt(qtyInput.value, 10) || 1) - 1);
    recalc();
  });
  modal.querySelector('.js-qty-inc').addEventListener('click', function () {
    qtyInput.value = Math.min(maxQty, (parseInt(qtyInput.value, 10) || 1) + 1);
    recalc();
  });

  form.addEventListener('change', function () { enforceLimits(); recalc(); });
});