/* Chicken Crunchy Roll - interaksi dasar (dipakai semua halaman pelanggan) */
document.addEventListener('DOMContentLoaded', function () {

  // Menu navigasi untuk layar kecil
  var toggle = document.querySelector('.nav-toggle');
  var menu = document.querySelector('.nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      var open = menu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Tutup notifikasi
  document.querySelectorAll('.alert-close').forEach(function (btn) {
    btn.addEventListener('click', function () {
      btn.closest('.alert').remove();
    });
  });
  // Notifikasi sukses hilang otomatis
  setTimeout(function () {
    document.querySelectorAll('.alert-success').forEach(function (el) {
      el.style.transition = 'opacity .5s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 500);
    });
  }, 5000);

  // Tampilkan/sembunyikan password
  document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-toggle-password'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Sembunyikan' : 'Lihat';
    });
  });

  // Konfirmasi sebelum aksi berbahaya: <form data-confirm="Yakin?">
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (!window.confirm(form.getAttribute('data-confirm'))) {
        ev.preventDefault();
      }
    });
  });

  // Cegah klik ganda pada tombol submit
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (ev.defaultPrevented) return;
      var btn = form.querySelector('button[type=submit][data-once]');
      if (btn) {
        setTimeout(function () { btn.disabled = true; }, 0);
      }
    });
  });
});