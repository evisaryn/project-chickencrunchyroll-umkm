/* Chicken Crunchy Roll - interaksi Admin ERP */
document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Sidebar (layar kecil) ---------- */
  var body = document.body;
  var toggle = document.getElementById('sidebarToggle');
  var overlay = document.getElementById('sidebarOverlay');
  var sidebar = document.getElementById('adminSidebar');

  function setSidebar(open) {
    body.classList.toggle('sidebar-open', open);
    if (toggle) toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  if (toggle) toggle.addEventListener('click', function () {
    setSidebar(!body.classList.contains('sidebar-open'));
  });
  if (overlay) overlay.addEventListener('click', function () { setSidebar(false); });
  if (sidebar) sidebar.addEventListener('click', function (ev) {
    if (ev.target.closest('a')) setSidebar(false);
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') setSidebar(false);
  });

  /* ---------- Grafik batang SVG ---------- */
  var NS = 'http://www.w3.org/2000/svg';

  function svgEl(name, attrs, text) {
    var node = document.createElementNS(NS, name);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function rupiah(n) {
    return 'Rp ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  function shortMoney(v) {
    var f = function (x) { return x.toLocaleString('id-ID', { maximumFractionDigits: 1 }); };
    if (v >= 1000000) return f(v / 1000000) + ' jt';
    if (v >= 1000) return f(v / 1000) + ' rb';
    return f(v);
  }

  function niceMax(v) {
    if (v <= 0) return 1;
    var exp = Math.pow(10, Math.floor(Math.log(v) / Math.LN10));
    var f = v / exp;
    var nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
    return nf * exp;
  }

  function drawChart(box) {
    var data = [];
    try { data = JSON.parse(box.getAttribute('data-points') || '[]'); } catch (e) { data = []; }
    if (!data.length) return;

    var W = 720, H = 300, pl = 58, pr = 12, pt = 16, pb = 40;
    var iw = W - pl - pr, ih = H - pt - pb;
    var maxVal = Math.max.apply(null, data.map(function (d) { return d.value; }));
    var top = niceMax(maxVal);
    var ticks = 4;

    var svg = svgEl('svg', {
      viewBox: '0 0 ' + W + ' ' + H, role: 'img',
      'aria-label': 'Grafik penjualan', preserveAspectRatio: 'xMidYMid meet'
    });

    // Garis bantu dan label sumbu Y
    for (var i = 0; i <= ticks; i++) {
      var y = pt + ih - (ih * i / ticks);
      svg.appendChild(svgEl('line', { x1: pl, x2: W - pr, y1: y, y2: y, 'class': i === 0 ? 'axis-line' : 'grid-line' }));
      svg.appendChild(svgEl('text', { x: pl - 8, y: y + 4, 'text-anchor': 'end', 'class': 'axis-text' }, shortMoney(top * i / ticks)));
    }

    // Batang
    var slot = iw / data.length;
    var bw = Math.min(46, slot * 0.62);
    data.forEach(function (d, idx) {
      var h = top > 0 ? (d.value / top) * ih : 0;
      var x = pl + slot * idx + (slot - bw) / 2;
      var y = pt + ih - h;

      var bar = svgEl('rect', {
        x: x, y: y, width: bw, height: Math.max(h, 0), rx: 4, 'class': 'bar'
      });
      bar.appendChild(svgEl('title', {}, d.label + ': ' + rupiah(d.value) + ' (' + d.orders + ' transaksi)'));
      svg.appendChild(bar);

      svg.appendChild(svgEl('text', {
        x: x + bw / 2, y: H - pb + 18, 'text-anchor': 'middle', 'class': 'axis-text'
      }, d.label));
    });

    if (maxVal <= 0) {
      svg.appendChild(svgEl('text', {
        x: W / 2, y: pt + ih / 2, 'text-anchor': 'middle', 'class': 'chart-empty'
      }, 'Belum ada penjualan pada periode ini'));
    }

    box.innerHTML = '';
    box.appendChild(svg);
  }

  document.querySelectorAll('.chart-box[data-points]').forEach(drawChart);
});