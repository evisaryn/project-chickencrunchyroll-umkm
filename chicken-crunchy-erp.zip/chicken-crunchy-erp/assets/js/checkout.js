/* Interaksi halaman checkout (hanya tampilan; server tetap menghitung ulang) */
document.addEventListener('DOMContentLoaded', function () {
  var box = document.getElementById('checkoutBox');
  if (!box) return;

  var bankInfo = document.getElementById('bankInfo');
  var qrisInfo = document.getElementById('qrisInfo');

  function refresh() {
    var p = box.querySelector('input[name="payment_method"]:checked');
    var method = p ? p.value : '';
    if (bankInfo) bankInfo.classList.toggle('hidden', method !== 'transfer');
    if (qrisInfo) qrisInfo.classList.toggle('hidden', method !== 'qris');
  }

  box.addEventListener('change', refresh);
  refresh();
});