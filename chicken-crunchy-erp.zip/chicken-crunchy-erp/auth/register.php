<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

if (is_logged_in()) {
    redirect(is_admin() ? 'admin/dashboard.php' : 'index.php');
}

$errors = [];
$old    = ['name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $old['name']  = post_str('name', 100);
    $old['email'] = mb_strtolower(post_str('email', 150));
    $old['phone'] = post_str('phone', 20);
    $password     = (string) ($_POST['password'] ?? '');
    $confirm      = (string) ($_POST['password_confirm'] ?? '');

    if (mb_strlen($old['name']) < 3) {
        $errors[] = 'Nama minimal 3 karakter.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }
    if (!valid_phone($old['phone'])) {
        $errors[] = 'Nomor telepon tidak valid (8-20 digit, boleh diawali +).';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password minimal 8 karakter.';
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password harus mengandung huruf dan angka.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Konfirmasi password tidak sama.';
    }

    if (!$errors) {
        try {
            $stmt = db()->prepare(
                "INSERT INTO users (name, email, phone, password_hash, role)
                 VALUES (?, ?, ?, ?, 'customer')"
            );
            $stmt->execute([
                $old['name'],
                $old['email'],
                $old['phone'],
                password_hash($password, PASSWORD_DEFAULT),
            ]);
            $newId = (int) db()->lastInsertId();

            login_user($newId);
            flash('success', 'Registrasi berhasil. Selamat datang, ' . $old['name'] . '!');
            redirect('user/menu.php');
        } catch (PDOException $ex) {
            // 23000 = pelanggaran UNIQUE (email sudah terdaftar)
            if ($ex->getCode() === '23000') {
                $errors[] = 'Email sudah terdaftar. Silakan login.';
            } else {
                error_log('Register error: ' . $ex->getMessage());
                $errors[] = 'Terjadi kesalahan. Silakan coba lagi.';
            }
        }
    }
}

$pageTitle  = 'Daftar Akun';
$activePage = 'login';
require __DIR__ . '/../includes/header.php';
?>

<section class="auth-page">
  <div class="card auth-card">
    <img class="auth-logo" src="<?= e(url('assets/images/logo.jpg')) ?>" alt="Logo">
    <h1>Buat Akun Baru</h1>
    <p class="sub">Daftar untuk memesan dan melacak pesanan Anda.</p>

    <?php if ($errors): ?>
      <div class="alert alert-danger" role="alert">
        <ul>
          <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" action="<?= e(url('auth/register.php')) ?>" autocomplete="on">
      <?= csrf_field() ?>

      <div class="form-group">
        <label for="name">Nama Lengkap</label>
        <input class="form-control" type="text" id="name" name="name"
               value="<?= e($old['name']) ?>" required maxlength="100" autocomplete="name">
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input class="form-control" type="email" id="email" name="email"
               value="<?= e($old['email']) ?>" required maxlength="150" autocomplete="email">
      </div>

      <div class="form-group">
        <label for="phone">Nomor Telepon / WhatsApp</label>
        <input class="form-control" type="tel" id="phone" name="phone"
               value="<?= e($old['phone']) ?>" required maxlength="20" autocomplete="tel">
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <div class="input-wrap">
          <input class="form-control" type="password" id="password" name="password"
                 required minlength="8" autocomplete="new-password">
          <button type="button" class="toggle-pass" data-toggle-password="password">Lihat</button>
        </div>
        <div class="form-hint">Minimal 8 karakter, kombinasi huruf dan angka.</div>
      </div>

      <div class="form-group">
        <label for="password_confirm">Ulangi Password</label>
        <input class="form-control" type="password" id="password_confirm" name="password_confirm"
               required minlength="8" autocomplete="new-password">
      </div>

      <button type="submit" class="btn btn-primary btn-block" data-once>Daftar</button>
    </form>

    <p class="auth-foot">Sudah punya akun? <a href="<?= e(url('auth/login.php')) ?>">Login</a></p>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>