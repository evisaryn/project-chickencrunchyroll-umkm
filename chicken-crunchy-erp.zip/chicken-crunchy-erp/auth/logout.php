<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_post();
csrf_verify();
logout_user();

header('Location: ' . url('auth/login.php?logged_out=1'));
exit;