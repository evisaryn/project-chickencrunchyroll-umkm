<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

$adminMode = isset($_GET['admin']) || isset($_POST['admin']);

// Sudah login: arahkan sesuai peran
if (is_logged_in()) {
    redirect(is_admin() ? 'admin/dashboard.php' : 'index.php');
}

/** Terima hanya path internal sederhana (cegah open redirect). */
function safe_next(string $next): string
{
    $next = trim($next);
    if ($next === '' || str_contains($next, '..') || $next[0] === '/') {
        return '';
    }
    return preg_match('/^[a-z0-9_\-\/]+\.php(\?[a-zA-Z0-9=&_\-]*)?$/i', $next) ? $next : '';
}

if (isset($_GET['logged_out'])) {
    flash('info', 'Anda sudah logout.');
}

$next  = safe_next((string) ($_GET['next'] ?? $_POST['next'] ?? ''));
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $email    = mb_strtolower(post_str('email', 150));
    $password = (string) ($_POST['password'] ?? '');

    // Pembatasan percobaan login
    $lockUntil = (int) ($_SESSION['login_lock_until'] ?? 0);
    if ($lockUntil > time()) {
        $minutes = (int) ceil(($lockUntil - time()) / 60);
        flash('danger', "Terlalu banyak percobaan gagal. Coba lagi dalam {$minutes} menit.");
    } else {
        $stmt = db()->prepare(
            'SELECT id, password_hash, role, is_active FROM users WHERE email = ? LIMIT 1'
        );
        $stmt->execute([$email]);
        $row = $stmt->fetch();

        // Tetap jalankan verifikasi walau email tidak ada (waktu respons relatif sama)
        $hash  = $row ? $row['password_hash'] : password_hash('dummy-password', PASSWORD_DEFAULT);
        $valid = password_verify($password, $hash) && $row;

        if (!$valid || (int) $row['is_active'] !== 1) {
            $_SESSION['login_fail'] = (int) ($_SESSION['login_fail'] ?? 0) + 1;
            if ($_SESSION['login_fail'] >= 5) {
                $_SESSION['login_lock_until'] = time() + 300;
                $_SESSION['login_fail'] = 0;
            }
            flash('danger', 'Email atau password salah.');
        } elseif ($adminMode && $row['role'] === 'customer') {
            flash('danger', 'Akun ini bukan akun admin.');
        } else {
            // Perbarui hash jika algoritma default PHP sudah berubah
            if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
                $up = db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
                $up->execute([password_hash($password, PASSWORD_DEFAULT), (int) $row['id']]);
            }

            unset($_SESSION['login_fail'], $_SESSION['login_lock_until']);
            login_user((int) $row['id']);

            if (in_array($row['role'], ['admin', 'superadmin'], true)) {
                redirect('admin/dashboard.php');
            }
            redirect($next !== '' ? $next : 'index.php');
        }
    }
}

$pageTitle  = $adminMode ? 'Login Admin ERP' : 'Login';
$activePage = 'login';
require __DIR__ . '/../includes/header.php';
?>

<section class="auth-page">
  <div class="card auth-card">
    <img class="auth-logo" src="<?= e(url('assets/images/logo.jpg')) ?>" alt="Logo">
    <h1><?= $adminMode ? 'Login Admin ERP' : 'Selamat Datang Kembali' ?></h1>
    <p class="sub">
      <?= $adminMode ? 'Masuk untuk mengelola produk, stok, dan pesanan.' : 'Login untuk mulai memesan Chicken Crunchy Roll.' ?>
    </p>

    <form method="post" action="<?= e(url('auth/login.php')) ?>" autocomplete="on">
      <?= csrf_field() ?>
      <?php if ($adminMode): ?><input type="hidden" name="admin" value="1"><?php endif; ?>
      <input type="hidden" name="next" value="<?= e($next) ?>">

      <div class="form-group">
        <label for="email">Email</label>
        <input class="form-control" type="email" id="email" name="email"
               value="<?= e($email) ?>" required maxlength="150" autocomplete="email">
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <div class="input-wrap">
          <input class="form-control" type="password" id="password" name="password"
                 required autocomplete="current-password">
          <button type="button" class="toggle-pass" data-toggle-password="password">Lihat</button>
        </div>
      </div>

      <button type="submit" class="btn btn-primary btn-block" data-once>Login</button>
    </form>

    <?php if (!$adminMode): ?>
      <p class="auth-foot">Belum punya akun? <a href="<?= e(url('auth/register.php')) ?>">Daftar sekarang</a></p>
    <?php else: ?>
      <p class="auth-foot"><a href="<?= e(url('index.php')) ?>">&larr; Kembali ke website</a></p>
    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>