<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

$pageTitle  = 'Tentang Kami';
$activePage = 'about';
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">Tentang <span><?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?></span></h1>
    <p class="section-sub">Gulungan ayam crispy dengan rasa yang bisa kamu atur sendiri.</p>

    <div class="card mb-2">
      <h3>Cerita Kami</h3>
      <p class="mt-1">
        Chicken Crunchy Roll adalah usaha makanan yang menyajikan gulungan ayam renyah dengan isian gurih.
        Kami ingin setiap pelanggan bisa menikmati roll sesuai seleranya, dengan pilihan saus celup, bubuk tabur,
        dan filling tambahan.
      </p>
    </div> <br>

    <div class="card mb-2">
        <h3>Visi</h3>
        <p class="mt-1">
           - Produk Unggulan dan Terjangkau. Menjadi camilan kekinian berbahan dasar ayam yang unggul, lezat, dan ramah di kantong masyarakat.
           - Pemberdayaan Pengusaha Baru. Membuka peluang kemitraan seluas-luasnya bagi masyarakat yang ingin memiliki sumber penghasilan mandiri dengan modal yang terjangkau.
        </p>
    </div> <br>

    <div class="card mb-2">
        <h3>Misi</h3>
        <p class="mt-1">
          - Menjaga Kualitas dan Kebersihan. Memastikan seluruh bahan baku tetap segar dengan standar kebersihan produksi yang terjamin. <br>
          - Menetapkan Harga Terjangkau. Memberikan harga jual yang ramah bagi semua kalangan, terutama pelajar dan mahasiswa.<br>
          - Melakukan Inovasi Rasa. Terus mengembangkan variasi menu, bumbu tabur, dan saus celup kekinian sesuai selera pasar.<br>
          - Memberikan Pelayanan Terbaik. Melayani pelanggan dengan ramah serta memberikan pelatihan dan pendampingan penuh bagi para mitra usaha tanpa sistem yang rumit.
        </p>
    </div>  <br><br>


    <div class="features mb-2">
      <div class="feature"><div class="ico">⭐</div><h3>Rasa Utama</h3><p>Ayam crispy digoreng hingga keemasan.</p></div>
      <div class="feature"><div class="ico">🎛️</div><h3>Fleksibel</h3><p>Kombinasi varian sesuai seleramu.</p></div>
      <div class="feature"><div class="ico">🤝</div><h3>Pelayanan</h3><p>Pesanan dipantau sampai selesai.</p></div>
    </div>


    <h1 class="section-title" style="text-align: center;">Pertanyaan Seputar <span><?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?></span></h1>
    <p class="section-sub" style="text-align: center;">Gulungan ayam crispy dengan rasa yang bisa kamu atur sendiri.</p>
    
    <div style="display: flex; flex-direction: column; gap: 1.25rem;" data-astro-cid-lcdefpme="">
      <details style="background: #ffffff; border-radius: 16px; border: 1px solid #fde68a; padding: 1.25rem 1.5rem; box-shadow: 0 4px 15px rgba(120, 53, 15, 0.04);" data-astro-cid-lcdefpme=""> 
        <summary style="font-size: 1.1rem; font-weight: 800; color: #451a03; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center;" data-astro-cid-lcdefpme=""> 
          <span data-astro-cid-lcdefpme="">Apakah kemitraan Chicken Crunchy Roll dikenakan royalty fee?</span> 
          <span style="color: #dc2626; font-size: 1.4rem;" data-astro-cid-lcdefpme="">+</span> 
        </summary> <p style="margin-top: 1rem; color: #78350f; line-height: 1.7; font-size: 0.975rem;" data-astro-cid-lcdefpme="">
          Tidak. Kemitraan Chicken Crunchy Roll menggunakan lisensi brand tanpa royalty fee atau bagi hasil dengan pengelola brand. Mitra tetap menanggung biaya bahan baku dan operasional usaha.
      </p> 
    </details> 
    
    <details style="background: #ffffff; border-radius: 16px; border: 1px solid #fde68a; padding: 1.25rem 1.5rem; box-shadow: 0 4px 15px rgba(120, 53, 15, 0.04);" data-astro-cid-lcdefpme=""> 
      <summary style="font-size: 1.1rem; font-weight: 800; color: #451a03; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center;" data-astro-cid-lcdefpme=""> 
        <span data-astro-cid-lcdefpme="">Berapa harga paket kemitraan dan apakah sudah termasuk booth?</span> 
        <span style="color: #dc2626; font-size: 1.4rem;" data-astro-cid-lcdefpme="">+</span> 
      </summary> 
      <p style="margin-top: 1rem; color: #78350f; line-height: 1.7; font-size: 0.975rem;" data-astro-cid-lcdefpme="">
      Paket Bronze Rp3,3 juta tidak termasuk booth; isinya mencakup lisensi brand, resep dan SOP, materi promosi digital, akses bahan baku, serta training. Paket Silver Rp4,2 juta dan Gold Rp4,9 juta mencakup booth, peralatan, serta bahan baku awal sesuai daftar paket. Hubungi CS untuk rincian perlengkapan dan biaya pengiriman.
      </p> 
    </details> 
    
    <details style="background: #ffffff; border-radius: 16px; border: 1px solid #fde68a; padding: 1.25rem 1.5rem; box-shadow: 0 4px 15px rgba(120, 53, 15, 0.04);" data-astro-cid-lcdefpme=""> 
      <summary style="font-size: 1.1rem; font-weight: 800; color: #451a03; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center;" data-astro-cid-lcdefpme=""> 
        <span data-astro-cid-lcdefpme="">Apakah mitra mendapat training dan SOP pembuatan chicken roll?</span> 
        <span style="color: #dc2626; font-size: 1.4rem;" data-astro-cid-lcdefpme="">+</span> 
      </summary> 
      <p style="margin-top: 1rem; color: #78350f; line-height: 1.7; font-size: 0.975rem;" data-astro-cid-lcdefpme="">
        Ya. Paket kemitraan mencakup training dan SOP pengolahan produk sebagai panduan membuat serta menyajikan chicken roll. Koordinasikan jadwal dan pelaksanaan pelatihan dengan tim MKI saat pendaftaran.
      </p> 
    </details>  

    <details style="background: #ffffff; border-radius: 16px; border: 1px solid #fde68a; padding: 1.25rem 1.5rem; box-shadow: 0 4px 15px rgba(120, 53, 15, 0.04);" data-astro-cid-lcdefpme=""> 
      <summary style="font-size: 1.1rem; font-weight: 800; color: #451a03; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center;" data-astro-cid-lcdefpme=""> 
      <span data-astro-cid-lcdefpme="">Bagaimana cara memesan ulang bahan baku dan kemasan?</span> 
      <span style="color: #dc2626; font-size: 1.4rem;" data-astro-cid-lcdefpme="">+</span> 
    </summary> <p style="margin-top: 1rem; color: #78350f; line-height: 1.7; font-size: 0.975rem;" data-astro-cid-lcdefpme="">
        Mitra dapat memesan ulang bahan baku dan kemasan melalui tim supply PT Master Kuliner Indonesia (MKI). Hubungi tim untuk informasi ketersediaan, harga, ketentuan pemesanan, dan pengiriman ke lokasi usaha Anda.
    </p> 
    </details> 
    </div> <br>

    <div class="card">
      <h3>Informasi Toko</h3>
      <ul style="list-style:none;margin-top:10px">
        <li>📍 <?= e(get_setting('business_address')) ?></li>
        <li>🕒 <?= e(get_setting('business_hours')) ?></li>
        <li>☎ <?= e(get_setting('business_phone')) ?></li>
        <li>✉ <?= e(get_setting('business_email')) ?></li>
      </ul>
      <a class="btn btn-primary mt-2" href="<?= e(url('user/menu.php')) ?>">Lihat Menu</a>
    </div> <br> <br>

    
    <h1 class="section-title" style="text-align: center;">Testimoni Pelanggan <span><?= e(get_setting('business_name', 'Chicken Crunchy Roll')) ?></span></h1>

    
    
    

  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>