<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_login();
$user = current_user();
$pdo  = db();

$statuses = ['pending', 'processing', 'ready', 'completed', 'cancelled'];
$filter   = (string) ($_GET['status'] ?? '');
if (!in_array($filter, $statuses, true)) {
    $filter = '';
}

$sql = 'SELECT o.id, o.order_number, o.queue_number, o.status, o.total, o.fulfillment, o.payment_method, o.created_at,
               (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count,
               (SELECT p.status FROM payments p WHERE p.order_id = o.id) AS pay_status
        FROM orders o
        WHERE o.user_id = ?';
$params = [(int) $user['id']];
if ($filter !== '') {
    $sql .= ' AND o.status = ?';
    $params[] = $filter;
}
$sql .= ' ORDER BY o.created_at DESC, o.id DESC LIMIT 100';

$st = $pdo->prepare($sql);
$st->execute($params);
$orders = $st->fetchAll();

$pageTitle  = 'Pesanan Saya';
$activePage = 'orders';
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">Pesanan <span>Saya</span></h1>
    <p class="section-sub">Riwayat dan status pesananmu.</p>

    <div class="chips mb-2">
      <a class="chip<?= $filter === '' ? ' active' : '' ?>" href="<?= e(url('user/orders.php')) ?>">Semua</a>
      <?php foreach ($statuses as $s): ?>
        <a class="chip<?= $filter === $s ? ' active' : '' ?>"
           href="<?= e(url('user/orders.php?status=' . $s)) ?>"><?= e(order_status_label($s)) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if (!$orders): ?>
      <div class="card empty-state">
        <div style="font-size:3rem">🧾</div>
        <p>Belum ada pesanan<?= $filter !== '' ? ' dengan status ini' : '' ?>.</p>
        <a class="btn btn-primary mt-2" href="<?= e(url('user/menu.php')) ?>">Pesan Sekarang</a>
      </div>
    <?php else: ?>
      <?php foreach ($orders as $o): ?>
        <div class="order-card">
          <div class="order-head">
            <span class="order-no"><?= e($o['order_number']) ?>
              <?php if (!empty($o['queue_number'])): ?><span class="queue-chip"><?= e(queue_label($o['queue_number'])) ?></span><?php endif; ?>
            </span>
          </div>
          <div class="text-muted" style="font-size:.88rem">
            <?= e(format_datetime($o['created_at'])) ?> &middot;
            <?= (int) $o['item_count'] ?> item &middot;
            <?= e(fulfillment_label($o['fulfillment'])) ?> &middot;
            <?= e(payment_method_label($o['payment_method'])) ?>
          </div>
          <div class="order-head mt-1">
            <span class="price"><?= e(rupiah($o['total'])) ?></span>
            <a class="btn btn-outline btn-sm" href="<?= e(url('user/order_detail.php?id=' . (int) $o['id'])) ?>">Lihat Detail</a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>