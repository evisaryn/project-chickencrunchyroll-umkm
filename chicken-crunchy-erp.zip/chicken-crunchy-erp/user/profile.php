<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_login();
$user = current_user();
$pdo  = db();

$profileErrors  = [];
$passwordErrors = [];
$form = [
    'name'    => (string) $user['name'],
    'phone'   => (string) ($user['phone'] ?? ''),
    'address' => (string) ($user['address'] ?? ''),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $type = post_str('form_type', 20);

    if ($type === 'profile') {
        $form['name']    = post_str('name', 100);
        $form['phone']   = post_str('phone', 20);
        $form['address'] = post_str('address', 500);

        if (mb_strlen($form['name']) < 3) {
            $profileErrors[] = 'Nama minimal 3 karakter.';
        }
        if (!valid_phone($form['phone'])) {
            $profileErrors[] = 'Nomor telepon tidak valid.';
        }

        if (!$profileErrors) {
            $pdo->prepare('UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?')
                ->execute([
                    $form['name'],
                    $form['phone'],
                    $form['address'] !== '' ? $form['address'] : null,
                    (int) $user['id'],
                ]);
            flash('success', 'Profil berhasil diperbarui.');
            redirect('user/profile.php');
        }
    }

    if ($type === 'password') {
        $current = (string) ($_POST['current_password'] ?? '');
        $new     = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['new_password_confirm'] ?? '');

        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $st->execute([(int) $user['id']]);
        $hash = (string) $st->fetchColumn();

        if (!password_verify($current, $hash)) {
            $passwordErrors[] = 'Password saat ini salah.';
        }
        if (strlen($new) < 8) {
            $passwordErrors[] = 'Password baru minimal 8 karakter.';
        } elseif (!preg_match('/[A-Za-z]/', $new) || !preg_match('/[0-9]/', $new)) {
            $passwordErrors[] = 'Password baru harus mengandung huruf dan angka.';
        }
        if ($new !== $confirm) {
            $passwordErrors[] = 'Konfirmasi password baru tidak sama.';
        }

        if (!$passwordErrors) {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), (int) $user['id']]);
            session_regenerate_id(true);
            flash('success', 'Password berhasil diganti.');
            redirect('user/profile.php');
        }
    }
}

$pageTitle  = 'Profil Saya';
$activePage = 'profile';
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">Profil <span>Saya</span></h1>
    <p class="section-sub">Kelola data akun dan keamananmu.</p>

    <div class="form-grid" style="align-items:start">
      <div class="card">
        <h3 class="mb-2">Data Akun</h3>

        <?php if ($profileErrors): ?>
          <div class="alert alert-danger"><ul><?php foreach ($profileErrors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div>
        <?php endif; ?>

        <form method="post" action="<?= e(url('user/profile.php')) ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="form_type" value="profile">

          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" type="email" id="email" value="<?= e($user['email']) ?>" disabled>
            <div class="form-hint">Email tidak dapat diubah.</div>
          </div>
          <div class="form-group">
            <label for="name">Nama Lengkap</label>
            <input class="form-control" type="text" id="name" name="name" value="<?= e($form['name']) ?>" required maxlength="100">
          </div>
          <div class="form-group">
            <label for="phone">Nomor Telepon / WhatsApp</label>
            <input class="form-control" type="tel" id="phone" name="phone" value="<?= e($form['phone']) ?>" required maxlength="20">
          </div>
          <div class="form-group">
            <label for="address">Alamat (opsional)</label>
            <textarea class="form-control" id="address" name="address" maxlength="500"><?= e($form['address']) ?></textarea>
          </div>
          <p class="form-hint mb-2">Terdaftar sejak <?= e(format_datetime($user['created_at'])) ?></p>
          <button type="submit" class="btn btn-primary" data-once>Simpan Profil</button>
        </form>
      </div>

      <div class="card">
        <h3 class="mb-2">Ganti Password</h3>

        <?php if ($passwordErrors): ?>
          <div class="alert alert-danger"><ul><?php foreach ($passwordErrors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div>
        <?php endif; ?>

        <form method="post" action="<?= e(url('user/profile.php')) ?>" autocomplete="off">
          <?= csrf_field() ?>
          <input type="hidden" name="form_type" value="password">

          <div class="form-group">
            <label for="current_password">Password Saat Ini</label>
            <input class="form-control" type="password" id="current_password" name="current_password" required autocomplete="current-password">
          </div>
          <div class="form-group">
            <label for="new_password">Password Baru</label>
            <input class="form-control" type="password" id="new_password" name="new_password" required minlength="8" autocomplete="new-password">
            <div class="form-hint">Minimal 8 karakter, kombinasi huruf dan angka.</div>
          </div>
          <div class="form-group">
            <label for="new_password_confirm">Ulangi Password Baru</label>
            <input class="form-control" type="password" id="new_password_confirm" name="new_password_confirm" required minlength="8" autocomplete="new-password">
          </div>
          <button type="submit" class="btn btn-dark" data-once>Ganti Password</button>
        </form>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>