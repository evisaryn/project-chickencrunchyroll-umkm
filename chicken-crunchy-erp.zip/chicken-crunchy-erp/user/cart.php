<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/cart.php';

require_login();
$user   = current_user();
$lines  = cart_lines((int) $user['id']);
$totals = cart_totals($lines);

$actionUrl = url('actions/cart_action.php');

$pageTitle  = 'Keranjang Belanja';
$activePage = 'cart';
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">Keranjang <span>Belanja</span></h1>
    <p class="section-sub">Periksa pesananmu sebelum checkout.</p>

    <?php if (!$lines): ?>
      <div class="card empty-state">
        <div style="font-size:3rem">🛒</div>
        <p>Keranjangmu masih kosong.</p>
        <a class="btn btn-primary mt-2" href="<?= e(url('user/menu.php')) ?>">Lihat Menu</a>
      </div>
    <?php else: ?>
      <div class="cart-layout">
        <div class="card">
          <?php foreach ($lines as $l):
              // Kelompokkan add-on per grup untuk ditampilkan
              $byGroup = [];
              foreach ($l['addons'] as $a) {
                  $byGroup[$a['group']][] = $a['name'];
              } ?>
            <div class="cart-item">
              <img src="<?= e(product_image_url($l['image'])) ?>" alt="<?= e($l['name']) ?>">

              <div>
                <h4><?= e($l['name']) ?></h4>
                <?php foreach ($byGroup as $group => $names): ?>
                  <div class="addons"><?= e(addon_group_label((string) $group)) ?>: <?= e(implode(', ', $names)) ?></div>
                <?php endforeach; ?>
                <div class="addons"><?= e(rupiah($l['unit_total'])) ?> / porsi</div>

                <form method="post" action="<?= e($actionUrl) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="item_id" value="<?= (int) $l['id'] ?>">
                  <input type="hidden" name="return_to" value="user/cart.php">
                  <div class="qty-control">
                    <button type="submit" name="op" value="dec" aria-label="Kurangi">&minus;</button>
                    <span><?= (int) $l['quantity'] ?></span>
                    <button type="submit" name="op" value="inc" aria-label="Tambah">+</button>
                  </div>
                </form>

                <?php foreach ($l['issues'] as $issue): ?>
                  <div class="text-red" style="font-size:.82rem;margin-top:6px">⚠ <?= e($issue) ?></div>
                <?php endforeach; ?>
              </div>

              <div class="line-price">
                <?= e(rupiah($l['line_total'])) ?>
                <form method="post" action="<?= e($actionUrl) ?>" data-confirm="Hapus item ini dari keranjang?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="remove">
                  <input type="hidden" name="item_id" value="<?= (int) $l['id'] ?>">
                  <input type="hidden" name="return_to" value="user/cart.php">
                  <button type="submit" class="link-danger">Hapus</button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>

          <form method="post" action="<?= e($actionUrl) ?>" class="mt-2" data-confirm="Kosongkan seluruh keranjang?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="clear">
            <input type="hidden" name="return_to" value="user/cart.php">
            <button type="submit" class="link-danger">Kosongkan keranjang</button>
          </form>
        </div>

        <aside class="card summary-card">
          <h3 class="mb-2">Ringkasan</h3>
          <div class="summary-row"><span>Jumlah item</span><span><?= (int) $totals['count'] ?></span></div>
          <div class="summary-row"><span>Subtotal</span><span><?= e(rupiah($totals['subtotal'])) ?></span></div>
          <div class="summary-row total"><span>Total</span><span><?= e(rupiah($totals['subtotal'])) ?></span></div>

          <?php if ($totals['has_issues']): ?>
            <div class="alert alert-warning mt-2">
              <div>Ada item yang stoknya bermasalah. Perbaiki dulu sebelum checkout.</div>
            </div>
          <?php endif; ?>

          <a class="btn btn-primary btn-block mt-2<?= $totals['has_issues'] ? ' disabled' : '' ?>"
             href="<?= e(url('user/checkout.php')) ?>">Lanjut ke Checkout</a>
          <a class="btn btn-outline btn-block mt-1" href="<?= e(url('user/menu.php')) ?>">Tambah Menu Lain</a>
        </aside>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>