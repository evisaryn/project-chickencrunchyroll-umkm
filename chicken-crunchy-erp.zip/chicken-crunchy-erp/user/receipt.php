<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/receipt.php';

require_login();
$rcUser  = current_user();
$orderId = get_int('id');

// Hanya pesanan milik sendiri; milik orang lain menghasilkan 404
$rcData = receipt_load($orderId, (int) $rcUser['id']);
if ($rcData === null) {
    http_response_code(404);
    exit('Pesanan tidak ditemukan.');
}

if ($rcData['order']['status'] === 'cancelled') {
    flash('warning', 'Pesanan yang dibatalkan tidak memiliki struk.');
    redirect('user/order_detail.php?id=' . $orderId);
}

receipt_render($rcData, url('user/order_detail.php?id=' . $orderId));