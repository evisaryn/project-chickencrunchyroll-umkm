<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/cart.php';

require_login();
$user   = current_user();
$lines  = cart_lines((int) $user['id']);
$totals = cart_totals($lines);

if (!$lines) {
    flash('warning', 'Keranjang masih kosong.');
    redirect('user/menu.php');
}
if ($totals['has_issues']) {
    flash('warning', 'Ada item dengan masalah stok. Perbaiki keranjang terlebih dahulu.');
    redirect('user/cart.php');
}

// Nilai awal form (atau nilai sebelumnya jika validasi gagal)
$old = $_SESSION['checkout_old'] ?? [
    'name'           => (string) $user['name'],
    'phone'          => (string) ($user['phone'] ?? ''),
    'payment_method' => 'cash',
    'notes'          => '',
];
unset($_SESSION['checkout_old']);

$qrisUrl = qris_image_url(); // null jika QRIS belum disiapkan admin
if ($old['payment_method'] === 'qris' && $qrisUrl === null) {
    $old['payment_method'] = 'cash';
}

$pageTitle  = 'Checkout';
$activePage = 'cart';
$extraScripts = ['assets/js/checkout.js'];
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">Check<span>out</span></h1>
    <p class="section-sub">Lengkapi data pesananmu. Pesanan diambil di toko.</p>

    <form method="post" action="<?= e(url('actions/order_action.php')) ?>" class="checkout-layout" id="checkoutBox">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="place">

      <div class="card">
        <h3 class="mb-2">Data Pemesan</h3>
        <div class="form-grid">
          <div class="form-group">
            <label for="customer_name">Nama</label>
            <input class="form-control" type="text" id="customer_name" name="customer_name"
                   value="<?= e((string) $old['name']) ?>" required maxlength="100">
          </div>
          <div class="form-group">
            <label for="customer_phone">Nomor Telepon / WhatsApp</label>
            <input class="form-control" type="tel" id="customer_phone" name="customer_phone"
                   value="<?= e((string) $old['phone']) ?>" required maxlength="20">
          </div>
        </div>

        <div class="alert alert-info">
          <div>
            <strong>Ambil di toko</strong><br>
            <?= e(get_setting('business_address')) ?><br>
            Jam buka: <?= e(get_setting('business_hours')) ?>
          </div>
        </div>

        <div class="form-group">
          <span class="form-label">Metode Pembayaran</span>
          <div class="radio-cards">
            <label class="radio-card">
              <input type="radio" name="payment_method" value="cash" <?= $old['payment_method'] === 'cash' ? 'checked' : '' ?>>
              <span><strong>Tunai</strong><small>Bayar saat ambil di toko</small></span>
            </label>
            <label class="radio-card">
              <input type="radio" name="payment_method" value="transfer" <?= $old['payment_method'] === 'transfer' ? 'checked' : '' ?>>
              <span><strong>Transfer Bank</strong><small>Diverifikasi admin</small></span>
            </label>
            <?php if ($qrisUrl !== null): ?>
            <label class="radio-card">
              <input type="radio" name="payment_method" value="qris" <?= $old['payment_method'] === 'qris' ? 'checked' : '' ?>>
              <span><strong>QRIS</strong><small>E-wallet / m-banking, diverifikasi admin</small></span>
            </label>
            <?php endif; ?>
          </div>
        </div>

        <div class="alert alert-info<?= $old['payment_method'] === 'transfer' ? '' : ' hidden' ?>" id="bankInfo">
          <div>
            Transfer ke: <strong><?= e(get_setting('bank_account')) ?></strong><br>
            Pesanan dianggap lunas setelah admin memverifikasi pembayaranmu.
          </div>
        </div>

        <?php if ($qrisUrl !== null): ?>
        <div class="card qris-box<?= $old['payment_method'] === 'qris' ? '' : ' hidden' ?>" id="qrisInfo">
          <strong>Bayar dengan QRIS</strong>
          <img src="<?= e($qrisUrl) ?>" alt="QRIS <?= e(get_setting('qris_name')) ?>">
          <div class="text-muted">a.n. <?= e(get_setting('qris_name')) ?></div>
          <p class="form-hint mt-1">Pesanan dibuat dulu. Scan QRIS ini lalu masukkan nominal sesuai total pesanan.
            QRIS juga tampil di halaman detail pesananmu. Pesanan dianggap lunas setelah admin memverifikasi.</p>
        </div>
        <?php endif; ?>

        <div class="form-group">
          <label for="notes">Catatan (opsional)</label>
          <textarea class="form-control" id="notes" name="notes" maxlength="255"
                    placeholder="Contoh: jangan terlalu pedas"><?= e((string) $old['notes']) ?></textarea>
        </div>
      </div>

      <aside class="card summary-card">
        <h3 class="mb-2">Ringkasan Pesanan</h3>

        <?php foreach ($lines as $l):
            $names = array_column($l['addons'], 'name'); ?>
          <div class="mini-item">
            <div>
              <strong><?= (int) $l['quantity'] ?>&times; <?= e($l['name']) ?></strong>
              <?php if ($names): ?><br><small class="text-muted"><?= e(implode(', ', $names)) ?></small><?php endif; ?>
            </div>
            <span><?= e(rupiah($l['line_total'])) ?></span>
          </div>
        <?php endforeach; ?>

        <div class="summary-row mt-2"><span>Subtotal</span><span><?= e(rupiah($totals['subtotal'])) ?></span></div>
        <div class="summary-row total"><span>Total</span><span><?= e(rupiah($totals['subtotal'])) ?></span></div>

        <button type="submit" class="btn btn-primary btn-block mt-2" data-once>Konfirmasi Pesanan</button>
        <a class="btn btn-outline btn-block mt-1" href="<?= e(url('user/cart.php')) ?>">Kembali ke Keranjang</a>
        <p class="form-hint mt-1">Total akhir dihitung ulang oleh server dengan harga dan stok terbaru.</p>
      </aside>
    </form>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>