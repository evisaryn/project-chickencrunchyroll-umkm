<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/cart.php';

$user = current_user();
$pdo  = db();

$q       = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 60);
$catSlug = (string) ($_GET['cat'] ?? '');

$categories = $pdo->query('SELECT id, name, slug FROM categories WHERE is_active = 1 ORDER BY id')->fetchAll();
$activeCat  = null;
foreach ($categories as $c) {
    if ($c['slug'] === $catSlug) {
        $activeCat = $c;
    }
}

// Daftar produk sesuai pencarian dan filter
$sql = "SELECT p.id, p.name, p.description, p.image, p.price, p.stock, p.min_stock,
               p.product_type, p.addon_group, c.name AS category_name
        FROM products p
        JOIN categories c ON c.id = p.category_id
        WHERE p.is_active = 1 AND c.is_active = 1";
$params = [];
if ($activeCat) {
    $sql .= ' AND p.category_id = ?';
    $params[] = (int) $activeCat['id'];
}
if ($q !== '') {
    $sql .= ' AND (p.name LIKE ? OR p.description LIKE ?)';
    $like = '%' . addcslashes($q, '%_\\') . '%';
    $params[] = $like;
    $params[] = $like;
}
$sql .= ' ORDER BY p.category_id, p.id';

$st = $pdo->prepare($sql);
$st->execute($params);

$mains = [];
$addonCards = [];
foreach ($st->fetchAll() as $p) {
    if ($p['product_type'] === 'main') {
        $mains[] = $p;
    } else {
        $addonCards[] = $p;
    }
}

// Semua add-on aktif untuk isi modal (tidak terpengaruh filter)
$addonsByGroup = ['sauce' => [], 'powder' => [], 'filling' => []];
$rows = $pdo->query(
    "SELECT id, name, price, stock, addon_group FROM products
     WHERE product_type = 'addon' AND is_active = 1 ORDER BY id"
)->fetchAll();
foreach ($rows as $r) {
    if (isset($addonsByGroup[(string) $r['addon_group']])) {
        $addonsByGroup[$r['addon_group']][] = $r;
    }
}

$groupMeta = [
    'sauce'   => ['title' => 'Saus Celup',   'type' => 'checkbox', 'name' => 'sauce[]', 'none' => null],
    'powder'  => ['title' => 'Bubuk Tabur',  'type' => 'radio',    'name' => 'powder',  'none' => 'Tanpa bubuk tabur'],
    'filling' => ['title' => 'Filling',      'type' => 'radio',    'name' => 'filling', 'none' => 'Tanpa filling'],
];

function menu_link(string $cat, string $q): string
{
    $query = array_filter(['cat' => $cat, 'q' => $q], static fn ($v) => $v !== '');
    return url('user/menu.php') . ($query ? '?' . http_build_query($query) : '');
}

$loginLink = url('auth/login.php?next=user/menu.php');

$pageTitle  = 'Menu';
$activePage = 'menu';
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <h1 class="section-title">Menu <span>Kami</span></h1>
    <p class="section-sub">Pilih roll favoritmu, lalu racik dengan saus, bubuk tabur, dan filling.</p>

    <form class="filter-bar" method="get" action="<?= e(url('user/menu.php')) ?>">
      <input class="form-control" type="search" name="q" value="<?= e($q) ?>"
             placeholder="Cari menu..." maxlength="60" aria-label="Cari menu">
      <?php if ($activeCat): ?><input type="hidden" name="cat" value="<?= e($activeCat['slug']) ?>"><?php endif; ?>
      <button type="submit" class="btn btn-primary">Cari</button>
      <?php if ($q !== '' || $activeCat): ?>
        <a class="btn btn-outline" href="<?= e(url('user/menu.php')) ?>">Reset</a>
      <?php endif; ?>
    </form>

    <div class="chips mb-2">
      <a class="chip<?= $activeCat ? '' : ' active' ?>" href="<?= e(menu_link('', $q)) ?>">Semua</a>
      <?php foreach ($categories as $c): ?>
        <a class="chip<?= ($activeCat && $activeCat['id'] === $c['id']) ? ' active' : '' ?>"
           href="<?= e(menu_link($c['slug'], $q)) ?>"><?= e($c['name']) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if (!$mains && !$addonCards): ?>
      <div class="empty-state">
        <p>Tidak ada menu yang cocok<?= $q !== '' ? ' dengan "' . e($q) . '"' : '' ?>.</p>
        <a class="btn btn-outline mt-2" href="<?= e(url('user/menu.php')) ?>">Tampilkan semua menu</a>
      </div>
    <?php endif; ?>

    <?php if ($mains): ?>
      <h2 class="mb-2" style="font-size:1.3rem">Menu Utama</h2>
      <div class="product-grid">
        <?php foreach ($mains as $p):
            $s = stock_status($p);
            $out = (int) $p['stock'] <= 0; ?>
          <article class="product-card<?= $out ? ' sold-out' : '' ?>">
            <div class="product-thumb">
              <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
              <span class="stock-tag <?= e($s['class']) ?>"><?= e($s['label']) ?></span>
            </div>
            <div class="product-body">
              <span class="product-cat"><?= e($p['category_name']) ?></span>
              <h3 class="product-name"><?= e($p['name']) ?></h3>
              <p class="product-desc"><?= e($p['description']) ?></p>
              <div class="product-foot">
                <span class="price"><?= e(rupiah($p['price'])) ?></span>
                <?php if ($out): ?>
                  <button class="btn btn-primary btn-sm" type="button" disabled>Stok Habis</button>
                <?php elseif (!$user): ?>
                  <a class="btn btn-primary btn-sm" href="<?= e($loginLink) ?>">Tambah ke Keranjang</a>
                <?php else: ?>
                  <button class="btn btn-primary btn-sm js-open-variant" type="button"
                          data-id="<?= (int) $p['id'] ?>"
                          data-name="<?= e($p['name']) ?>"
                          data-price="<?= e((string) (float) $p['price']) ?>"
                          data-stock="<?= (int) $p['stock'] ?>">🛒 Tambah ke Keranjang</button>
                <?php endif; ?>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($addonCards): ?>
      <h2 class="mt-3 mb-2" style="font-size:1.3rem">Pilihan Saus, Bubuk Tabur &amp; Filling</h2>
      <div class="product-grid">
        <?php foreach ($addonCards as $p):
            $s = stock_status($p);
            $out = (int) $p['stock'] <= 0; ?>
          <article class="product-card<?= $out ? ' sold-out' : '' ?>">
            <div class="product-thumb">
              <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
              <span class="stock-tag <?= e($s['class']) ?>"><?= e($s['label']) ?></span>
            </div>
            <div class="product-body">
              <span class="product-cat"><?= e($p['category_name']) ?></span>
              <h3 class="product-name"><?= e($p['name']) ?></h3>
              <p class="product-desc"><?= e($p['description']) ?></p>
              <div class="product-foot">
                <span class="price"><?= (float) $p['price'] > 0 ? '+' . e(rupiah($p['price'])) : 'Gratis' ?></span>
                <small class="text-muted">Dipilih saat memesan roll</small>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php if ($user): ?>
<!-- Modal pilihan varian -->
<div class="modal-backdrop" id="variantModal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="vmTitle">
    <form method="post" action="<?= e(url('actions/cart_action.php')) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <input type="hidden" name="return_to" value="user/menu.php">
      <input type="hidden" name="product_id" id="vmProductId" value="">

      <div class="modal-head">
        <h3 id="vmTitle">Pilih Varian</h3>
        <button type="button" class="modal-close" data-close aria-label="Tutup">&times;</button>
      </div>

      <div class="modal-body">
        <?php foreach ($groupMeta as $group => $meta):
            if (!$addonsByGroup[$group]) { continue; }
            $limit = ADDON_LIMITS[$group]; ?>
          <div class="option-group" data-type="<?= e($meta['type']) ?>" data-limit="<?= (int) $limit ?>">
            <h4><?= e($meta['title']) ?>
              <small>
                <?= $meta['type'] === 'checkbox' ? '(pilih maksimal ' . (int) $limit . ', opsional)' : '(pilih 1, opsional)' ?>
              </small>
            </h4>
            <div class="option-list">
              <?php if ($meta['none'] !== null): ?>
                <label class="option">
                  <input type="radio" name="<?= e($meta['name']) ?>" value="" data-price="0" checked>
                  <span><?= e($meta['none']) ?></span>
                </label>
              <?php endif; ?>

              <?php foreach ($addonsByGroup[$group] as $a):
                  $sold = (int) $a['stock'] <= 0; ?>
                <label class="option<?= $sold ? ' disabled' : '' ?>">
                  <input type="<?= e($meta['type']) ?>" name="<?= e($meta['name']) ?>"
                         value="<?= (int) $a['id'] ?>"
                         data-price="<?= e((string) (float) $a['price']) ?>"
                         data-soldout="<?= $sold ? '1' : '0' ?>"
                         <?= $sold ? 'disabled' : '' ?>>
                  <span><?= e($a['name']) ?></span>
                  <span class="opt-price">
                    <?php if ($sold): ?>Habis
                    <?php elseif ((float) $a['price'] > 0): ?>+<?= e(rupiah($a['price'])) ?>
                    <?php else: ?>Gratis<?php endif; ?>
                  </span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>

        <div class="option-group">
          <h4>Jumlah</h4>
          <div class="qty-control">
            <button type="button" class="js-qty-dec" aria-label="Kurangi">&minus;</button>
            <span id="vmQtyText">1</span>
            <button type="button" class="js-qty-inc" aria-label="Tambah">+</button>
          </div>
          <input type="hidden" name="quantity" id="vmQty" value="1">
        </div>
      </div>

      <div class="modal-foot">
        <div>
          <small class="text-muted">Total</small>
          <div class="price" id="vmTotal">Rp 0</div>
        </div>
        <button type="submit" class="btn btn-primary">Masukkan Keranjang</button>
      </div>
    </form>
  </div>
</div>
<?php $extraScripts = ['assets/js/menu.js']; endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>