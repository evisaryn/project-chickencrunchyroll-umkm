<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_login();
$user = current_user();
$pdo  = db();

$orderId = get_int('id');

$st = $pdo->prepare(
    'SELECT o.*, p.status AS pay_status, p.paid_at
     FROM orders o
     LEFT JOIN payments p ON p.order_id = o.id
     WHERE o.id = ? AND o.user_id = ?
     LIMIT 1'
);
$st->execute([$orderId, (int) $user['id']]);
$order = $st->fetch();

if (!$order) {
    http_response_code(404);
    $pageTitle  = 'Pesanan Tidak Ditemukan';
    $activePage = 'orders';
    require __DIR__ . '/../includes/header.php';
    echo '<section class="section"><div class="container"><div class="card empty-state">'
       . '<p>Pesanan tidak ditemukan.</p>'
       . '<a class="btn btn-primary mt-2" href="' . e(url('user/orders.php')) . '">Kembali ke Pesanan Saya</a>'
       . '</div></div></section>';
    require __DIR__ . '/../includes/footer.php';
    exit;
}

// Item pesanan
$st = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');
$st->execute([$orderId]);
$items = $st->fetchAll();

// Add-on per item
$addons = [];
if ($items) {
    $itemIds = array_map(static fn ($i) => (int) $i['id'], $items);
    $in = implode(',', array_fill(0, count($itemIds), '?'));
    $st = $pdo->prepare(
        "SELECT order_item_id, addon_name, addon_group FROM order_item_addons
         WHERE order_item_id IN ($in)
         ORDER BY FIELD(addon_group, 'sauce', 'powder', 'filling'), addon_name"
    );
    $st->execute($itemIds);
    foreach ($st->fetchAll() as $a) {
        $addons[(int) $a['order_item_id']][(string) $a['addon_group']][] = (string) $a['addon_name'];
    }
}

// Linimasa status
$flow       = ['pending', 'processing', 'ready', 'completed'];
$currentIdx = array_search($order['status'], $flow, true);
$cancelled  = $order['status'] === 'cancelled';

$canCancel = $order['status'] === 'pending'
    && (int) $order['stock_deducted'] === 0
    && $order['pay_status'] !== 'paid';

$pageTitle  = 'Detail Pesanan ' . $order['order_number'];
$activePage = 'orders';
require __DIR__ . '/../includes/header.php';
?>

<section class="section">
  <div class="container">
    <p class="mb-2"><a href="<?= e(url('user/orders.php')) ?>">&larr; Semua pesanan</a></p>
    <h1 class="section-title">Pesanan <span><?= e($order['order_number']) ?></span></h1>
    <p class="section-sub">Dibuat pada <?= e(format_datetime($order['created_at'])) ?></p>

    <?php if (!empty($order['queue_number']) && !$cancelled): ?>
      <div class="queue-card">
        <small>Nomor Antrean Anda</small>
        <div class="queue-no"><?= e(queue_label($order['queue_number'])) ?></div>
        <small>Tunjukkan nomor ini saat mengambil pesanan</small>
      </div>
    <?php endif; ?>

    <?php if ($cancelled): ?>
      <div class="alert alert-danger">
        <div>
          <strong>Pesanan dibatalkan.</strong>
          <?php if ($order['cancel_reason']): ?> Alasan: <?= e($order['cancel_reason']) ?><?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <div class="timeline">
        <?php foreach ($flow as $i => $s): ?>
          <div class="step<?= ($currentIdx !== false && $i <= $currentIdx) ? ' done' : '' ?>">
            <?= e($s === 'ready'
                ? ($order['fulfillment'] === 'delivery' ? 'Siap Dikirim' : 'Siap Diambil')
                : order_status_label($s)) ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="cart-layout">
      <div class="card">
        <h3 class="mb-2">Item Pesanan</h3>
        <div class="table-wrap">
          <table class="table">
            <thead>
              <tr><th>Item</th><th class="text-right">Jumlah</th><th class="text-right">Harga/porsi</th><th class="text-right">Subtotal</th></tr>
            </thead>
            <tbody>
              <?php foreach ($items as $it): ?>
                <tr>
                  <td>
                    <strong><?= e($it['product_name']) ?></strong>
                    <?php foreach ($addons[(int) $it['id']] ?? [] as $group => $names): ?>
                      <br><small class="text-muted"><?= e(addon_group_label((string) $group)) ?>: <?= e(implode(', ', $names)) ?></small>
                    <?php endforeach; ?>
                  </td>
                  <td class="text-right"><?= (int) $it['quantity'] ?></td>
                  <td class="text-right"><?= e(rupiah((float) $it['unit_price'] + (float) $it['addon_total'])) ?></td>
                  <td class="text-right"><?= e(rupiah($it['line_total'])) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <?php if ($order['notes']): ?>
          <p class="mt-2"><strong>Catatan:</strong> <?= e($order['notes']) ?></p>
        <?php endif; ?>
      </div>

      <aside class="card summary-card">
        <h3 class="mb-2">Ringkasan</h3>
        <div class="summary-row"><span>Status</span>
          <span class="badge badge-<?= e($order['status']) ?>"><?= e(order_status_label($order['status'])) ?></span></div>
        <div class="summary-row"><span>Pembayaran</span>
          <span class="badge badge-<?= e((string) $order['pay_status']) ?>"><?= e(payment_status_label((string) $order['pay_status'])) ?></span></div>
        <div class="summary-row"><span>Metode</span><span><?= e(payment_method_label($order['payment_method'])) ?></span></div>
        <div class="summary-row"><span>Pengambilan</span><span><?= e(fulfillment_label($order['fulfillment'])) ?></span></div>
        <div class="summary-row"><span>Subtotal</span><span><?= e(rupiah($order['subtotal'])) ?></span></div>
        <div class="summary-row total"><span>Total</span><span><?= e(rupiah($order['total'])) ?></span></div>

        <?php if (!$cancelled): ?>
          <a class="btn btn-outline btn-block mt-2" href="<?= e(url('user/receipt.php?id=' . (int) $order['id'])) ?>" target="_blank" rel="noopener">🧾 Lihat / Cetak Struk</a>
        <?php endif; ?>

        <hr style="border:0;border-top:1px dashed var(--line);margin:14px 0">
        <p><strong><?= e($order['customer_name']) ?></strong><br>
           <?= e($order['customer_phone']) ?></p>
        <?php if ($order['fulfillment'] === 'delivery'): ?>
          <p class="mt-1"><?= nl2br(e($order['address'])) ?></p>
        <?php endif; ?>

        <?php if ($order['payment_method'] === 'transfer' && $order['pay_status'] === 'unpaid' && !$cancelled): ?>
          <div class="alert alert-info mt-2">
            <div>Transfer ke: <strong><?= e(get_setting('bank_account')) ?></strong><br>
            Admin akan memverifikasi pembayaranmu.</div>
          </div>
        <?php endif; ?>

        <?php $qrisUrl = qris_image_url();
        if ($order['payment_method'] === 'qris' && $order['pay_status'] === 'unpaid' && !$cancelled && $qrisUrl !== null): ?>
          <div class="card qris-box mt-2">
            <strong>Bayar dengan QRIS</strong>
            <img src="<?= e($qrisUrl) ?>" alt="QRIS">
            <div class="text-muted">a.n. <?= e(get_setting('qris_name')) ?></div>
            <div class="qris-total"><?= e(rupiah($order['total'])) ?></div>
            <p class="form-hint">Masukkan nominal tepat sesuai total. Admin akan memverifikasi pembayaranmu.</p>
          </div>
        <?php endif; ?>

        <?php if ($canCancel): ?>
          <form method="post" action="<?= e(url('actions/order_action.php')) ?>"
                data-confirm="Yakin ingin membatalkan pesanan ini?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="cancel">
            <input type="hidden" name="order_id" value="<?= (int) $order['id'] ?>">
            <button type="submit" class="btn btn-outline btn-block mt-2">Batalkan Pesanan</button>
          </form>
        <?php endif; ?>
      </aside>
    </div>
  </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>