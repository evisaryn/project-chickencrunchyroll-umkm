<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/cart.php';

$pdo = db();

// Menu populer: produk utama terlaris (pesanan tidak dibatalkan). Jika belum ada penjualan, urut id.
$popular = $pdo->query(
    "SELECT p.id, p.name, p.description, p.image, p.price, p.stock, p.min_stock,
            COALESCE(s.sold, 0) AS sold
     FROM products p
     LEFT JOIN (
         SELECT oi.product_id, SUM(oi.quantity) AS sold
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         WHERE o.status <> 'cancelled'
         GROUP BY oi.product_id
     ) s ON s.product_id = p.id
     WHERE p.product_type = 'main' AND p.is_active = 1
     ORDER BY sold DESC, p.id ASC
     LIMIT 4"
)->fetchAll();

// Jumlah pilihan varian per grup (dari database)
$variantCount = ['sauce' => 0, 'powder' => 0, 'filling' => 0];
$rows = $pdo->query(
    "SELECT addon_group, COUNT(*) AS n FROM products
     WHERE product_type = 'addon' AND is_active = 1 AND addon_group IS NOT NULL
     GROUP BY addon_group"
)->fetchAll();
foreach ($rows as $r) {
    $variantCount[$r['addon_group']] = (int) $r['n'];
}

$heroImg = is_file(__DIR__ . '/assets/images/hero.jpg')
    ? 'assets/images/hero.jpg'
    : 'assets/images/hero.jpeg';

$pageTitle  = 'Beranda';
$activePage = 'home';
require __DIR__ . '/includes/header.php';
?>

<section class="hero">
  <div class="container">
    <div>
      <span class="promo-tag">🔥 Gulungan Ayam Crispy</span>
      <h1>Renyah di Luar, <em>Nagih</em> di Dalam</h1>
      <p>Racik Chicken Crunchy Roll favoritmu: pilih saus celup, bubuk tabur, dan filling sesuai selera. Dibuat saat dipesan, siap diambil di toko.</p>
      <div class="hero-actions">
        <a class="btn btn-light" href="<?= e(url('user/menu.php')) ?>">Pesan Sekarang</a>
        <a class="btn btn-outline" style="color:var(--cream);border-color:var(--cream)" href="<?= e(url('user/about.php')) ?>">Tentang Kami</a>
      </div>
    </div>
    <img class="hero-img" src="<?= e(url($heroImg)) ?>" alt="Chicken Crunchy Roll">
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="features">
      <div class="feature"><div class="ico">🍗</div><h3>Dibuat Saat Dipesan</h3><p>Digoreng setelah pesananmu diproses.</p></div>
      <div class="feature"><div class="ico">🎨</div><h3>Racik Sendiri</h3><p>Pilih saus, bubuk tabur, dan filling.</p></div>
      <div class="feature"><div class="ico">🏪</div><h3>Ambil di Toko </h3><p>Pesan online, ambil tanpa antre.</p></div>
      <div class="feature"><div class="ico">💳</div><h3>Bayar Fleksibel</h3><p>Tunai, transfer, atau QRIS.</p></div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <h2 class="section-title">Menu <span>Populer</span></h2>
    <p class="section-sub">Favorit pelanggan Chicken Crunchy Roll.</p>

    <?php if (!$popular): ?>
      <div class="empty-state">Menu belum tersedia. Silakan kembali lagi nanti.</div>
    <?php else: ?>
      <div class="product-grid">
        <?php foreach ($popular as $p): $s = stock_status($p); $out = (int) $p['stock'] <= 0; ?>
          <article class="product-card<?= $out ? ' sold-out' : '' ?>">
            <div class="product-thumb">
              <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
              <span class="stock-tag <?= e($s['class']) ?>"><?= e($s['label']) ?></span>
            </div>
            <div class="product-body">
              <h3 class="product-name"><?= e($p['name']) ?></h3>
              <p class="product-desc"><?= e($p['description']) ?></p>
              <div class="product-foot">
                <span class="price"><?= e(rupiah($p['price'])) ?></span>
                <?php if ($out): ?>
                  <span class="btn btn-primary btn-sm disabled">Stok Habis</span>
                <?php else: ?>
                  <a class="btn btn-primary btn-sm" href="<?= e(url('user/menu.php')) ?>">Pesan</a>
                <?php endif; ?>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="text-center mt-3">
      <a class="btn btn-outline" href="<?= e(url('user/menu.php')) ?>">Lihat Semua Menu</a>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="card">
      <h2 class="section-title">Pilih <span>Varianmu</span></h2>
      <p class="section-sub">Satu roll, banyak kombinasi rasa.</p>
      <div class="features">
        <div class="feature"><div class="ico">🥫</div><h3>Saus Celup</h3><p><?= (int) $variantCount['sauce'] ?> pilihan saus</p></div>
        <div class="feature"><div class="ico">🧂</div><h3>Bubuk Tabur</h3><p><?= (int) $variantCount['powder'] ?> pilihan bubuk</p></div>
        <div class="feature"><div class="ico">🧀</div><h3>Filling</h3><p><?= (int) $variantCount['filling'] ?> pilihan filling, atau tanpa filling</p></div>
      </div>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0">
  <div class="container">
    <div class="card text-center" style="background:var(--red);color:var(--cream);border:0">
      <h2 class="section-title" style="color:var(--cream)">Lapar? Pesan Sekarang!</h2>
      <p style="margin-bottom:16px">Buka <?= e(get_setting('business_hours')) ?>. Hubungi kami di <?= e(get_setting('business_phone')) ?>.</p>
      <a class="btn btn-light" href="<?= e(url('user/menu.php')) ?>">Pesan Sekarang</a>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>