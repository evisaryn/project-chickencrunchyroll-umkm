<?php
declare(strict_types=1);

/**
 * Konfigurasi aplikasi dan koneksi database (PDO).
 * Sesuaikan DB_USER dan DB_PASS jika XAMPP Anda memakai password MySQL.
 */

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'chicken_crunchyroll');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// URL dasar aplikasi (tanpa slash di akhir). Sesuaikan dengan nama folder di htdocs.
define('BASE_URL', '/chicken-crunchy-erp');

// Lokasi upload gambar produk
define('UPLOAD_PATH', dirname(__DIR__) . '/assets/images/products/');
define('UPLOAD_URL', BASE_URL . '/assets/images/products/');
define('MAX_UPLOAD_BYTES', 2 * 1024 * 1024); // 2 MB

date_default_timezone_set('Asia/Jakarta');

/**
 * Mengembalikan satu koneksi PDO yang dipakai ulang (singleton).
 */
function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // prepared statement asli
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            $pdo->exec("SET time_zone = '+07:00'");
        } catch (PDOException $e) {
            // Jangan tampilkan detail error ke pengunjung
            error_log('DB connection error: ' . $e->getMessage());
            http_response_code(500);
            exit('Koneksi database gagal. Periksa config/database.php dan pastikan MySQL menyala.');
        }
    }

    return $pdo;
}